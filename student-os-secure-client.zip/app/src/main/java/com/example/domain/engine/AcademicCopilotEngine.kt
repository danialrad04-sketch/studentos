package com.example.domain.engine

import com.example.data.local.entity.AttendanceEntity
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.GradeEntity
import com.example.data.local.entity.StudentProfileEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.seed.CurriculumSeedData
import com.example.domain.model.ActionImpactType
import com.example.domain.model.CopilotActionProposal
import com.example.domain.model.CopilotMessage
import com.example.domain.model.CopilotPayload
import com.example.domain.model.CopilotSender
import com.example.ui.models.ExamItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object AcademicCopilotEngine {

    fun generateWelcomeMessage(
        profile: StudentProfileEntity,
        courses: List<CourseEntity>,
        attendanceList: List<AttendanceEntity>,
        grades: List<GradeEntity>,
        tasks: List<TaskEntity>
    ): CopilotMessage {
        val totalActiveUnits = courses.sumOf { it.units }.coerceAtLeast(profile.activeUnits)
        val passedUnits = profile.passedUnits
        val totalRequired = 140
        val remainingUnits = (totalRequired - passedUnits - totalActiveUnits).coerceAtLeast(0)
        val gpa = computeGpa(grades, profile.declaredGpa)

        val criticalAbsences = attendanceList.count { it.absentCount >= it.maxAllowed && it.maxAllowed > 0 }
        val pendingTasks = tasks.count { !it.isCompleted }

        val greeting = buildString {
            append("سلام ${profile.name} عزیز! من Academic Copilot (دستیار تحصیلی هوشمند) شما هستم.\n\n")
            append("📊 **شناسنامه زنده و تحلیل وضعیت:**\n")
            append("• **رشته تحصیلی:** ${profile.major} (${profile.university})\n")
            append("• **ترم جاری:** ترم ${profile.currentSemester} (ورودی ${profile.entryYear})\n")
            append("• **واحدهای فعال این ترم:** $totalActiveUnits واحد (${courses.size} درس فعال)\n")
            append("• **واحدهای گذرانده:** $passedUnits از $totalRequired واحد ($remainingUnits واحد تا فارغ‌التحصیلی)\n")
            append("• **معدل کل:** ${String.format(Locale.US, "%.2f", gpa)}\n")

            if (criticalAbsences > 0) {
                append("• 🚨 **هشدار قانون 3/16:** $criticalAbsences درس در لبه سقف غیبت قرار دارد!\n")
            }
            if (pendingTasks > 0) {
                append("• 📋 **تکالیف فعال:** $pendingTasks تکلیف باقی‌مانده\n")
            }
            append("\nمن بر تمام چارت مصوب ${profile.major}، قوانین آموزشی وزارت علوم، رادار غیبت‌ها و شبیه‌سازی معدل مسلط هستم. چه سوالی دارید؟")
        }

        return CopilotMessage(
            id = UUID.randomUUID().toString(),
            sender = CopilotSender.COPILOT,
            text = greeting,
            timestamp = currentTimeString(),
            suggestedQuickReplies = listOf(
                "تحلیل سقف غیبت‌های 3/16",
                "پیش‌نیازها و دروس ترم بعد",
                "محاسبه هدف معدل الف (بالای 17)",
                "برنامه کلاس‌ها و زمان‌بندی امروز",
                "بررسی تقویم امتحانات پایان‌ترم"
            ),
            confidenceBadge = "تحلیل رسمی چارت ${profile.major}"
        )
    }

    fun processUserQuery(
        query: String,
        profile: StudentProfileEntity,
        courses: List<CourseEntity>,
        attendanceList: List<AttendanceEntity>,
        grades: List<GradeEntity>,
        tasks: List<TaskEntity>,
        exams: List<ExamItem>
    ): CopilotMessage {
        val cleanQuery = query.trim().lowercase(Locale.ROOT)
        val gpa = computeGpa(grades, profile.declaredGpa)
        val totalActiveUnits = courses.sumOf { it.units }
        val majorCurriculum = CurriculumSeedData.getCoursesForMajor(profile.major)

        return when {
            // Emergency Course Drop (حذف اضطراری / تک‌درس)
            cleanQuery.contains("حذف اضطراری") || cleanQuery.contains("حذف تکدرس") || cleanQuery.contains("حذف تک درس") || cleanQuery.contains("حذف درس") -> {
                val canDrop = totalActiveUnits > 14 // 14 - 3 = 11 -> dropped below 12
                val text = buildString {
                    append("🛑 **آیین‌نامه حذف اضطراری (تک‌درس) طبق مقررات وزارت علوم:**\n\n")
                    append("• **مهلت زمانی:** تا ۵ هفته قبل از شروع امتحانات پایان‌ترم (با تأیید استاد درس و آموزش دانشکده).\n")
                    append("• **شرط کف واحد:** مجموع واحدهای باقی‌مانده پس از حذف نباید از **۱۲ واحد** کمتر شود.\n")
                    append("• **وضعیت شما در این ترم:** هم‌اکنون دارای **$totalActiveUnits واحد فعال** هستید.\n\n")
                    if (totalActiveUnits - 3 < 12) {
                        append("⚠️ **اخطار کف واحد:** با حذف یک درس ۳ واحدی، تعداد واحدهای شما به ${totalActiveUnits - 3} واحد می‌رسد که کمتر از کف قانونی (۱۲ واحد) است و به صورت سیستمی در گلستان تأیید نخواهد شد (مگر با مجوز کمیسیون موارد خاص).\n")
                    } else {
                        append("✅ **مجوز سیستمی:** با داشتن $totalActiveUnits واحد، می‌توانید ۱ درس (تا سقف ${totalActiveUnits - 12} واحد) را بدون نگرانی از کف واحد حذف اضطراری نمایید.\n")
                    }
                    append("• **نکته کارنامه:** درس حذف اضطراری در معدل کل و نیم‌سال محاسبه نمی‌شود و غیبت‌های آن حذف می‌گردد.")
                }

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    suggestedQuickReplies = listOf("کف و سقف واحد در ترم", "تحلیل سقف غیبت‌ها", "شبیه‌ساز کارنامه")
                )
            }

            // Academic Probation & Dismissal Rules (مشروطی و اخراج آموزشی)
            cleanQuery.contains("مشروط") || cleanQuery.contains("اخراج") || cleanQuery.contains("معدل زیر ۱۲") || cleanQuery.contains("معدل زیر 12") || cleanQuery.contains("کمیسیون") -> {
                val text = buildString {
                    append("⚖️ **قوانین مشروطی و اخطار آموزشی (آیین‌نامه یکپارچه وزارت علوم):**\n\n")
                    append("• **حدنصاب مشروطی:** چنانچه معدل نیم‌سال دانشجو کمتر از **۱۲.۰۰** باشد، آن ترم مشروط محاسبه می‌شود.\n")
                    append("• **سقف واحد ترم بعد:** دانشجوی مشروط در ترم بعد مجاز به اخذ حداکثر **۱۴ واحد** است.\n")
                    append("• **حداکثر دفعات مشروطی:**\n")
                    append("  - مقطع کارشناسی پیوسته: حداکثر **۳ نیم‌سال متوالی** یا **۴ نیم‌سال متناوب** مجاز به مشروطی است و پس از آن پرونده به کمیسیون موارد خاص دانشگاه ارجاع می‌شود.\n")
                    append("• **حداقل نمره قبولی هر درس:** نمره **۱۰.۰۰** برای دروس کارشناسی.\n\n")
                    append("💡 **راهکار جبران:** با تنظیم نمرات در شبیه‌ساز کارنامه Student OS می‌توانید استراتژی رسیدن به معدل بالای ۱۲ و خروج از وضعیت مشروطی را ترسیم کنید.")
                }

                val proposal = CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "ورود به شبیه‌ساز کارنامه و معدل",
                    description = "تغییر نمرات پیش‌بینی شده برای محاسبه آنی معدل ترم و کل",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("GRADES"),
                    buttonLabel = "شبیه‌ساز زنده نمرات"
                )

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    proposedAction = proposal,
                    suggestedQuickReplies = listOf("شبیه‌ساز کارنامه", "سقف و کف انتخاب واحد", "تکالیف باقی‌مانده")
                )
            }

            // Leave of Absence & Maximum Study Duration (مرخصی تحصیلی و سنوات مجاز)
            cleanQuery.contains("مرخصی") || cleanQuery.contains("سنوات") || cleanQuery.contains("نظام وظیفه") || cleanQuery.contains("معافیت") -> {
                val text = buildString {
                    append("📜 **مقررات مرخصی تحصیلی و سنوات مجاز مقطع کارشناسی:**\n\n")
                    append("• **سنوات مجاز کارشناسی پیوسته:** حداکثر **۵ سال (۱۰ نیم‌سال تحصیلی)** طبق آیین‌نامه جدید.\n")
                    append("• **سقف مرخصی تحصیلی:** حداکثر **۲ نیم‌سال** در طول دوره تحصیل با موافقت دانشکده (با احتساب در سنوات).\n")
                    append("• **مرخصی بدون احتساب سنوات:** زایمان، بیماری حاد با تأیید پزشک معتمد دانشگاه و کمیسیون موارد خاص.\n")
                    append("• **معافیت تحصیلی نظام وظیفه:** برادران ملزم به اتمام دوره در سقف مصوب سازمان وظیفه عمومی (۱۰ ترم اولیه + ۲ ترم تمدید سنوات با مجوز کمیسیون) می‌باشند.")
                }

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    suggestedQuickReplies = listOf("مشاهده شناسنامه تحصیلی", "پیش‌نیازهای دروس", "برنامه هفتگی")
                )
            }

            // Introduction to Professor / Taking last courses (معرفی به استاد و فارغ‌التحصیلی)
            cleanQuery.contains("معرفی به استاد") || cleanQuery.contains("تک درس") || cleanQuery.contains("فارغ التحصیل") || cleanQuery.contains("فارغ‌التحصیل") -> {
                val remainingUnits = (140 - (profile.passedUnits + totalActiveUnits)).coerceAtLeast(0)
                val text = buildString {
                    append("🎓 **شرایط اخذ درس به صورت معرفی به استاد (تک‌درس پایان دوره):**\n\n")
                    append("• **شرط اصلی:** دانشجو برای فراغت از تحصیل حداکثر **۲ درس نظری (تا سقف ۴ واحد)** باقی‌مانده داشته باشد و تمامی دروس دیگر را با نمره قبولی گذرانده باشد.\n")
                    append("• **دروس عملی/کارگاهی:** دروس صرفاً عملی قابل اخذ به عنوان معرفی به استاد نیستند (مگر با موافقت شورای آموزشی).\n")
                    append("• **زمان امتحان:** خارج از تقویم رسمی و با هماهنگی استاد درس و اداره آموزش برگزار می‌شود.\n\n")
                    append("• **واحدهای باقی‌مانده تقریبی شما تا فارغ‌التحصیلی:** حدود **$remainingUnits واحد**.")
                }

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    suggestedQuickReplies = listOf("چارت کامل تحصیلی", "محاسبه معدل الف", "شناسنامه تحصیلی")
                )
            }

            // Fix / check semester
            cleanQuery.contains("ترم من") || cleanQuery.contains("ترم چندم") || cleanQuery.contains("اصلاح ترم") || cleanQuery.contains("تغییر ترم") -> {
                val text = buildString {
                    append("🎓 **بررسی و تعیین دقیق ترم تحصیلی:**\n\n")
                    append("• ترم ثبت‌شده برای شما در سیستم: **ترم ${profile.currentSemester}** (${profile.major})\n")
                    append("• سال ورود: **${profile.entryYear}**\n")
                    append("• واحدهای گذرانده تاکنون: **${profile.passedUnits} واحد**\n\n")
                    append("✅ سیستم به صورت مستقیم عدد ترم شما را محاسبه می‌کند (بدون هیچ خطای اندیس‌گذاری).\n")
                    append("اگر مایلید ترم خود را تغییر دهید یا سوابق تحصیلی گذشته را ویرایش کنید، از دکمه زیر اقدام فرمایید:")
                }

                val proposal = CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "ویرایش مشخصات تحصیلی و ترم",
                    description = "تنظیم دستی شماره ترم، سال ورود و تعداد واحدهای پاس‌شده",
                    impactType = ActionImpactType.REQUIRES_CONFIRMATION,
                    payload = CopilotPayload.NavigateToTab("PASSPORT"),
                    buttonLabel = "ورود به شناسنامه تحصیلی"
                )

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    proposedAction = proposal,
                    suggestedQuickReplies = listOf("پیش‌نیازها و دروس ترم بعد", "تحلیل سقف غیبت‌ها", "برنامه هفتگی من")
                )
            }

            // Attendance & 3/16 law analysis
            cleanQuery.contains("غیبت") || cleanQuery.contains("حضور") || cleanQuery.contains("رادار") || cleanQuery.contains("3/16") || cleanQuery.contains("۳/۱۶") -> {
                val dangerous = attendanceList.filter { it.absentCount >= it.maxAllowed && it.maxAllowed > 0 }
                val warning = attendanceList.filter { it.absentCount == it.maxAllowed - 1 && it.maxAllowed > 0 }
                val safe = attendanceList.filter { it.absentCount < it.maxAllowed - 1 }

                val text = buildString {
                    append("🛡️ **تحلیل رادار هوشمند غیبت‌ها (قانون ۳/۱۶ وزارت علوم - ماده ۳۵):**\n\n")
                    if (dangerous.isNotEmpty()) {
                        append("🚨 **دروس در وضعیت بحرانی (رسیده به سقف حذف ماده ۳۵):**\n")
                        dangerous.forEach {
                            append("• **${it.courseName}**: ${it.absentCount} غیبت از سقف مجاز ${it.maxAllowed} جلسه\n")
                        }
                        append("\n⚠️ **توصیه فوری:** در این دروس نباید حتی ۱ جلسه دیگر غیبت داشته باشید تا مشمول حذف آموزشی نشوید.\n\n")
                    }
                    if (warning.isNotEmpty()) {
                        append("⚠️ **دروس در آستانه خطر (تنها ۱ جلسه تا سقف مجاز):**\n")
                        warning.forEach {
                            append("• **${it.courseName}**: ${it.absentCount} غیبت (سقف مجاز: ${it.maxAllowed} جلسه)\n")
                        }
                        append("\n")
                    }
                    if (safe.isNotEmpty()) {
                        append("✅ **دروس در حاشیه امن:**\n")
                        safe.take(4).forEach {
                            val remainingSafe = (it.maxAllowed - it.absentCount).coerceAtLeast(0)
                            append("• **${it.courseName}**: ${it.absentCount} غیبت (حاشیه امن: $remainingSafe جلسه دیگر)\n")
                        }
                    }
                    if (attendanceList.isEmpty()) {
                        append("هنوز کلاسی در رادار حضور و غیاب ثبت نشده است.")
                    }
                }

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    suggestedQuickReplies = listOf("مشاهده رادار کامل غیبت‌ها", "امتحانات پایان‌ترم", "برنامه هفتگی")
                )
            }

            // Schedule & Today's classes
            cleanQuery.contains("کلاس") || cleanQuery.contains("برنامه") || cleanQuery.contains("استاد") || cleanQuery.contains("امروز") || cleanQuery.contains("ساعت") -> {
                val text = buildString {
                    append("📅 **تحلیل برنامه هفتگی و زمان‌بندی کلاس‌ها:**\n\n")
                    if (courses.isNotEmpty()) {
                        val sortedCourses = courses.sortedBy { it.name }
                        sortedCourses.forEach { c ->
                            append("• **${c.name}** (${c.units} واحد)\n")
                            if (c.professor.isNotBlank() && c.professor != "استاد دانشکده") {
                                append("  👨‍🏫 مدرس: ${c.professor}\n")
                            }
                            if (c.examDate.isNotBlank()) {
                                append("  📝 امتحان: تاریخ ${c.examDate} ساعت ${c.examTime}\n")
                            }
                        }
                    } else {
                        append("در حال حاضر درسی در برنامه هفتگی شما اضافه نشده است.")
                    }
                }

                val proposal = CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "انتقال به برنامه هفتگی کامل",
                    description = "مشاهده تقویم هفتگی کلاسی با تفکیک روزها و تداخل‌سنجی",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("SCHEDULE"),
                    buttonLabel = "ورود به برنامه هفتگی"
                )

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    proposedAction = proposal,
                    suggestedQuickReplies = listOf("رادار غیبت‌های کلاس‌ها", "امتحانات پایان‌ترم", "پیش‌نیازهای ترم بعد")
                )
            }

            // Next semester & Prerequisite tree analysis
            cleanQuery.contains("پیش‌نیاز") || cleanQuery.contains("ترم بعد") || cleanQuery.contains("انتخاب واحد") || cleanQuery.contains("چارت") || cleanQuery.contains("واحد") -> {
                val nextSemester = (profile.currentSemester + 1).coerceAtMost(8)
                val nextSemCourses = majorCurriculum.filter { it.recommendedSemester == nextSemester }
                val currentSemCourses = majorCurriculum.filter { it.recommendedSemester == profile.currentSemester }

                val text = buildString {
                    append("🗺️ **تحلیل تخصصی چارت ${profile.major} و پیش‌نیازها برای ترم $nextSemester:**\n\n")

                    if (nextSemCourses.isNotEmpty()) {
                        append("دروس مصوب ترم $nextSemester در چارت دانشگاه:\n")
                        nextSemCourses.forEach { c ->
                            val preReqInfo = if (c.prerequisites.isNotBlank()) " | پیش‌نیاز: ${c.prerequisites}" else " | بدون پیش‌نیاز"
                            val coReqInfo = if (c.coRequisites.isNotBlank()) " | هم‌نیاز: ${c.coRequisites}" else ""
                            append("• **${c.name}** (${c.units} واحد - نوع: ${c.courseType})$preReqInfo$coReqInfo\n")
                        }
                    } else {
                        append("دروس پایانی شامل پروژه کارشناسی، کارآموزی صنعتی و دروس اختیاری تخصصی هستند.\n")
                    }

                    append("\n📌 **توصیه استراتژیک آموزشی:**\n")
                    if (currentSemCourses.isNotEmpty()) {
                        val criticalPreReqs = currentSemCourses.take(2).map { it.name }.joinToString(" و ")
                        append("پاس کردن دروس «$criticalPreReqs» در ترم جاری شرط اساسی برای اخذ بدون مانع دروس ترم $nextSemester خواهد بود.\n")
                    }
                    val creditCeiling = if (gpa >= 17.0) 24 else if (gpa < 12.0) 14 else 20
                    append("با توجه به معدل فعلی شما (${String.format(Locale.US, "%.2f", gpa)})، سقف مجاز انتخاب واحد شما در ترم آینده **$creditCeiling واحد** است.")
                }

                val proposal = CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "مشاهده درخت کامل چارت و پیش‌نیازها",
                    description = "نمایش ماتریس ترم‌های 1 تا 8 و گراف وابستگی دروس",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("CURRICULUM"),
                    buttonLabel = "ورود به چارت تحصیلی"
                )

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    proposedAction = proposal,
                    suggestedQuickReplies = listOf("مشاهده چارت کامل", "چند واحد تا فارغ‌التحصیلی مانده؟", "شبیه‌ساز معدل الف")
                )
            }

            // Exam schedules & Stress management
            cleanQuery.contains("امتحان") || cleanQuery.contains("فرجه") || cleanQuery.contains("پایان‌ترم") || cleanQuery.contains("تاریخ") || cleanQuery.contains("استرس") -> {
                val text = buildString {
                    append("🎯 **تحلیل تقویم امتحانات پایان‌ترم و استراتژی فرجه‌ها:**\n\n")
                    if (exams.isNotEmpty()) {
                        append("لیست امتحانات ثبت‌شده شما:\n")
                        exams.sortedBy { it.solarDate }.forEach { exam ->
                            append("• **${exam.courseName}**: تاریخ ${exam.solarDate} ساعت ${exam.time} (${exam.location})\n")
                        }
                        val firstExam = exams.first()
                        append("\n💡 **توصیه زمان‌بندی:** اولین امتحان شما «${firstExam.courseName}» در تاریخ ${firstExam.solarDate} است. پیشنهاد می‌شود مرور متمرکز را با تکنیک پومودورو (بازه ۲۵ دقیقه مطالعه + ۵ دقیقه استراحت) آغاز کنید.")
                    } else {
                        append("هنوز هیچ تاریخی برای امتحانات ثبت نشده است. می‌توانید تاریخ امتحانات را در کارت‌های برنامه کلاسی وارد کنید.")
                    }
                }

                val proposal = CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "شروع جلسه مطالعه پومودورو",
                    description = "یک بازه ۲۵ دقیقه‌ای تمرکز عمیق برای آمادگی امتحانات",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("POMODORO"),
                    buttonLabel = "ورود به تایمر تمرکز"
                )

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    proposedAction = proposal,
                    suggestedQuickReplies = listOf("لیست کامل امتحانات", "برنامه هفتگی", "تکالیف باقی‌مانده")
                )
            }

            // GPA Target simulation & A-Grade criteria
            cleanQuery.contains("معدل") || cleanQuery.contains("الف") || cleanQuery.contains("شبیه‌ساز") || cleanQuery.contains("نمره") || cleanQuery.contains("کارنامه") -> {
                val currentGpa = gpa
                val neededFor17 = if (currentGpa < 17.0) {
                    val targetUnits = profile.passedUnits + totalActiveUnits
                    val targetScore = 17.0 * targetUnits
                    val currentScore = currentGpa * profile.passedUnits
                    val needed = (targetScore - currentScore) / totalActiveUnits.coerceAtLeast(1)
                    needed.coerceIn(0.0, 20.0)
                } else 17.0
                val formattedNeeded = String.format(Locale.US, "%.2f", neededFor17)

                val text = buildString {
                    append("📈 **تحلیل و شبیه‌سازی ارتقای معدل کل:**\n\n")
                    append("• **معدل کل فعلی:** ${String.format(Locale.US, "%.2f", currentGpa)}\n")
                    append("• **واحدهای فعال این ترم:** $totalActiveUnits واحد\n")
                    append("• **واحدهای پاس‌شده قبلی:** ${profile.passedUnits} واحد\n\n")

                    if (currentGpa >= 17.0) {
                        append("🌟 وضعیت شما در محدوده **دانشجوی ممتاز (رتبه الف)** قرار دارد! با حفظ معدل بالای ۱۷ در این نیم‌سال، سقف انتخاب واحد شما در ترم بعد تا ۲۴ واحد آزاد خواهد بود.\n")
                    } else {
                        append("🎯 برای رساندن معدل کل به **۱۷.۰۰ (رتبه الف)**، میانگین نمرات مورد نیاز شما در دروس این ترم برابر با **$formattedNeeded** از ۲۰ است.\n")
                        append("• تمرکز ویژه روی دروس ۳ واحدی بالاترین ضریب رشد معدل را برای شما خواهد داشت.")
                    }
                }

                val proposal = CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "باز کردن شبیه‌ساز زنده نمرات و کارنامه",
                    description = "تغییر نمرات میان‌ترم و پایان‌ترم برای مشاهده اثر آنی روی معدل",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("GRADES"),
                    buttonLabel = "ورود به شبیه‌ساز کارنامه"
                )

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    proposedAction = proposal,
                    suggestedQuickReplies = listOf("ورود به شبیه‌ساز کارنامه", "بررسی پیش‌نیازها", "تحلیل سقف غیبت‌ها")
                )
            }

            // Tasks & Deadlines
            cleanQuery.contains("تکلیف") || cleanQuery.contains("پروژه") || cleanQuery.contains("تسک") || cleanQuery.contains("تمرین") -> {
                val pending = tasks.filter { !it.isCompleted }
                val text = buildString {
                    append("📋 **وضعیت تکالیف و پروژه‌های درسی:**\n\n")
                    if (pending.isNotEmpty()) {
                        append("تکالیف فعال شما:\n")
                        pending.forEach {
                            append("• **${it.title}** (درس: ${it.courseName}) — موعد: ${it.dueDate}\n")
                        }
                    } else {
                        append("🎉 فوق‌العاده است! تمام تکالیف شما تکمیل شده‌اند و هیچ تسک معوقه‌ای ندارید.\n")
                    }
                }

                val firstPending = pending.firstOrNull()
                val proposal = if (firstPending != null) {
                    CopilotActionProposal(
                        id = UUID.randomUUID().toString(),
                        title = "تکمیل تکلیف: ${firstPending.title}",
                        description = "علامت‌گذاری این تکلیف به عنوان انجام‌شده",
                        impactType = ActionImpactType.REQUIRES_CONFIRMATION,
                        payload = CopilotPayload.CompleteTask(firstPending.id.toString(), firstPending.title),
                        buttonLabel = "علامت‌گذاری به عنوان انجام‌شده"
                    )
                } else null

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    proposedAction = proposal,
                    suggestedQuickReplies = listOf("افزودن تکلیف جدید", "برنامه هفتگی", "امتحانات")
                )
            }

            // Gamification & Badges
            cleanQuery.contains("مدال") || cleanQuery.contains("استریک") || cleanQuery.contains("دستاورد") || cleanQuery.contains("امتیاز") || cleanQuery.contains("xp") -> {
                val completedTasksCount = tasks.count { it.isCompleted }
                val zeroAbsenceCount = attendanceList.count { it.absentCount == 0 }

                val text = buildString {
                    append("🏆 **سامانه دستاوردها و لول آکادمیک:**\n\n")
                    append("• **استریک مطالعه پیوسته:** 🔥 ۴ روز متوالی\n")
                    append("• **تکالیف تکمیل‌شده:** $completedTasksCount مورد به موقع\n")
                    append("• **سپر غیبت صفر:** $zeroAbsenceCount درس با حضور کامل ۱۰۰%\n\n")
                    append("با ادامه تمرکز در پومودورو، ثبت به موقع تکالیف و مدیریت غیبت‌ها امتیاز تجربه (XP) کسب کرده و مدال‌های آکادمیک را آنلاک کنید!")
                }

                val proposal = CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "مشاهده تالار افتخارات و مدال‌ها",
                    description = "بررسی لول آکادمیک، استریک روزانه و وضعیت مدال‌ها",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("GAMIFICATION"),
                    buttonLabel = "ورود به بخش مدال‌ها"
                )

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    proposedAction = proposal,
                    suggestedQuickReplies = listOf("وضعیت مدال‌ها و استریک", "تحلیل سقف غیبت‌های من", "محاسبه معدل الف")
                )
            }

            // Default intelligent response
            else -> {
                val text = buildString {
                    append("💡 در پاسخ به پرسش شما درباره «$query»:\n\n")
                    append("به عنوان دستیار تحصیلی هوشمند دانشگاه، من روی بخش‌های زیر آماده خدمت‌رسانی هستم:\n")
                    append("1. **تحلیل غیبت‌ها و سقف مجاز ۳/۱۶** برای تمام دروس (ماده ۳۵)\n")
                    append("2. **چارت مصوب ${profile.major}**، پیش‌نیازها و هم‌نیازها (ترم ۱ تا ۸)\n")
                    append("3. **سقف و کف واحدهای مجاز (۱۲ تا ۲۴ واحد) و حذف اضطراری**\n")
                    append("4. **زمان‌بندی کلاس‌ها و تداخل‌سنجی برنامه هفتگی**\n")
                    append("5. **شبیه‌سازی نمرات و محاسبه معدل الف (بالای ۱۷)**\n")
                    append("6. **تقویم امتحانات پایان‌ترم و تایمر پومودورو**\n\n")
                    append("می‌توانید یکی از گزینه‌های زیر را لمس کنید یا سوال مشخص‌تری مطرح نمایید:")
                }

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    suggestedQuickReplies = listOf(
                        "تحلیل سقف غیبت‌های من",
                        "قوانین حذف اضطراری تک‌درس",
                        "پیش‌نیازهای دروس ترم بعد",
                        "محاسبه معدل الف",
                        "برنامه هفتگی من",
                        "برنامه امتحانات"
                    )
                )
            }
        }
    }

    suspend fun processUserQueryAsync(
        query: String,
        profile: StudentProfileEntity,
        courses: List<CourseEntity>,
        attendanceList: List<AttendanceEntity>,
        grades: List<GradeEntity>,
        tasks: List<TaskEntity>,
        exams: List<ExamItem>,
        conversationHistory: List<CopilotMessage> = emptyList(),
        customApiKey: String? = null
    ): CopilotMessage {
        val studentContext = buildString {
            append("نام: ${profile.name}\n")
            append("دانشگاه: ${profile.university}\n")
            append("رشته: ${profile.major}\n")
            append("ترم تحصیلی: ترم ${profile.currentSemester} (ورودی ${profile.entryYear})\n")
            append("واحدهای گذرانده: ${profile.passedUnits}\n")
            append("معدل کل اعلام‌شده/محاسبه‌شده: ${String.format(Locale.US, "%.2f", computeGpa(grades, profile.declaredGpa))}\n")
            append("دروس فعال این ترم (${courses.size} درس):\n")
            courses.forEach { c ->
                val att = attendanceList.find { it.courseId == c.id || it.courseName == c.name }
                append("- ${c.name} (${c.units} واحد) | استاد: ${c.professor} | غیبت: ${att?.absentCount ?: 0}/${att?.maxAllowed ?: 3}\n")
            }
            if (exams.isNotEmpty()) {
                append("امتحانات پیش‌رو:\n")
                exams.forEach { e ->
                    append("- ${e.courseName}: تاریخ ${e.solarDate} ساعت ${e.time} (${e.location})\n")
                }
            }
            val pendingTasks = tasks.filter { !it.isCompleted }
            if (pendingTasks.isNotEmpty()) {
                append("تکالیف باقی‌مانده:\n")
                pendingTasks.take(5).forEach { t ->
                    append("- ${t.title} (درس: ${t.courseName} | موعد: ${t.dueDate})\n")
                }
            }
        }

        // Format recent conversation history (last 6 turns)
        val historyTurns = conversationHistory.takeLast(6).map { msg ->
            val role = if (msg.sender == CopilotSender.USER) "user" else "model"
            Pair(role, msg.text)
        }

        // 1. Try real Gemini API via Firebase AI Logic / REST first
        val geminiResult = com.example.data.api.GeminiApiClient.generateAcademicAdvice(
            prompt = query,
            studentContext = studentContext,
            history = historyTurns,
            customApiKey = customApiKey
        )

        if (geminiResult.isSuccess) {
            val geminiText = geminiResult.getOrNull()
            if (!geminiText.isNullOrBlank()) {
                val activeModel = com.example.data.api.GeminiApiClient.getActiveModelName()
                val detectedAction = detectActionProposal(query, geminiText, tasks, courses, profile)
                val dynamicQuickReplies = generateDynamicQuickReplies(query, geminiText)

                return CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = geminiText,
                    timestamp = currentTimeString(),
                    confidenceBadge = "پاسخ زنده هوش مصنوعی $activeModel ✦",
                    proposedAction = detectedAction,
                    suggestedQuickReplies = dynamicQuickReplies
                )
            }
        }

        // 2. Offline heuristic fallback with visible non-alarming badge
        val fallbackMsg = processUserQuery(query, profile, courses, attendanceList, grades, tasks, exams)
        return fallbackMsg.copy(
            confidenceBadge = "پاسخ آفلاین آکادمیک (موتور تحلیلی محلی)"
        )
    }

    private fun detectActionProposal(
        query: String,
        aiText: String,
        tasks: List<TaskEntity>,
        courses: List<CourseEntity>,
        profile: StudentProfileEntity
    ): CopilotActionProposal? {
        val q = query.lowercase(Locale.ROOT)
        val t = aiText.lowercase(Locale.ROOT)

        return when {
            q.contains("کارنامه") || q.contains("معدل") || t.contains("شبیه‌ساز نمرات") || q.contains("نمره") -> {
                CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "ورود به شبیه‌ساز کارنامه و معدل",
                    description = "تغییر نمرات میان‌ترم و پایان‌ترم برای محاسبه بلادرنگ معدل",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("GRADES"),
                    buttonLabel = "شبیه‌ساز کارنامه"
                )
            }
            q.contains("چارت") || q.contains("پیش‌نیاز") || q.contains("ترم بعد") || t.contains("پیش‌نیاز") -> {
                CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "مشاهده درخت پیش‌نیازها و چارت",
                    description = "نمایش ماتریس ترم‌های ۱ تا ۸ و دروس مجاز انتخاب واحد",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("CURRICULUM"),
                    buttonLabel = "چارت تحصیلی"
                )
            }
            q.contains("پومودورو") || q.contains("تمرکز") || q.contains("مطالعه") || t.contains("پومودورو") || q.contains("امتحان") -> {
                CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "شروع جلسه تمرکز عمیق (پومودورو)",
                    description = "تنظیم بازه ۲۵ دقیقه‌ای مطالعه همراه با موسیقی آرامش‌بخش",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("POMODORO"),
                    buttonLabel = "تایمر تمرکز"
                )
            }
            q.contains("غیبت") || q.contains("حضور") || t.contains("رادار غیبت") -> {
                CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "مشاهده رادار غیبت‌های کلاسی",
                    description = "بررسی وضعیت قانون ۳/۱۶ و حاشیه امن حضور در جلسات",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("ATTENDANCE"),
                    buttonLabel = "رادار غیبت‌ها"
                )
            }
            q.contains("برنامه") || q.contains("کلاس") || q.contains("ساعت") -> {
                CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "مشاهده تقویم و برنامه هفتگی",
                    description = "بررسی زمان‌بندی روزانه کلاس‌ها و تداخل‌سنجی",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("SCHEDULE"),
                    buttonLabel = "برنامه هفتگی"
                )
            }
            q.contains("تکلیف") || q.contains("پروژه") || q.contains("تسک") -> {
                val pending = tasks.firstOrNull { !it.isCompleted }
                if (pending != null) {
                    CopilotActionProposal(
                        id = UUID.randomUUID().toString(),
                        title = "تکمیل تکلیف «${pending.title}»",
                        description = "علامت‌گذاری این تسک به عنوان انجام‌شده",
                        impactType = ActionImpactType.REQUIRES_CONFIRMATION,
                        payload = CopilotPayload.CompleteTask(pending.id.toString(), pending.title),
                        buttonLabel = "تکمیل تکلیف"
                    )
                } else null
            }
            else -> null
        }
    }

    private fun generateDynamicQuickReplies(query: String, aiText: String): List<String> {
        val q = query.lowercase(Locale.ROOT)
        return when {
            q.contains("غیبت") || q.contains("حضور") -> listOf(
                "قوانین حذف اضطراری تک‌درس",
                "سقف غیبت در دروس آزمایشگاهی",
                "چطور غیبت موجه بگیرم؟"
            )
            q.contains("معدل") || q.contains("مشروط") -> listOf(
                "شرایط دانشجوی ممتاز (معدل الف)",
                "سقف انتخاب واحد در ترم بعد",
                "راهکارهای خروج از مشروطی"
            )
            q.contains("پیش‌نیاز") || q.contains("ترم بعد") || q.contains("چارت") -> listOf(
                "هم‌نیازی و اخذ همزمان دو درس",
                "چند واحد تا فارغ‌التحصیلی مانده؟",
                "معرفی به استاد چگونه است؟"
            )
            q.contains("امتحان") || q.contains("استرس") -> listOf(
                "تایمر پومودورو برای مطالعه",
                "برنامه‌ریزی مرور در فرجه‌ها",
                "تاریخ امتحانات بعدی من"
            )
            else -> listOf(
                "تحلیل سقف غیبت‌های من",
                "پیش‌نیازهای دروس ترم بعد",
                "محاسبه معدل الف"
            )
        }
    }

    fun computeGpa(grades: List<GradeEntity>, declaredGpa: Double? = null): Double {
        return if (grades.isNotEmpty() && grades.sumOf { it.units } > 0) {
            val totalWeighted = grades.sumOf { ((it.midtermGrade + it.finalGrade) / 2.0) * it.units }
            val totalU = grades.sumOf { it.units }
            val computedGpa = totalWeighted / totalU
            computedGpa.coerceIn(0.0, 20.0)
        } else {
            (declaredGpa?.takeIf { it > 0.0 } ?: 16.5).coerceIn(0.0, 20.0)
        }
    }

    private fun currentTimeString(): String {
        return SimpleDateFormat("HH:mm", Locale.US).format(Date())
    }
}
