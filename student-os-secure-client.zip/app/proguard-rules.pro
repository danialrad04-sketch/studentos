# ═══════════════════════════════════════════════════════════════════════
# Student OS — hardened R8/ProGuard rules for release builds.
#
# Goal: fully obfuscate and shrink our own app code (so the backend's auth
# flow, token handling, and business logic can't be trivially read back out
# of a decompiled APK), while keeping the handful of classes that MUST keep
# their original names/fields because something reads them via reflection
# (Moshi JSON parsing, Cloud Firestore's POJO mapping) or the app would
# crash at runtime with cryptic (de)serialization errors.
# ═══════════════════════════════════════════════════════════════════════

# Keep line numbers for readable crash reports in Crashlytics, but hide the
# real source file name so a stack trace alone doesn't reveal project layout.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Keep annotations and generic signatures — required for Retrofit/Moshi's
# reflection-based type resolution to keep working after obfuscation.
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod

# ── Kotlin metadata (needed by Moshi's reflection-based adapter to see
#    Kotlin default values / nullability / data class components) ─────────
-keep class kotlin.Metadata { *; }
-keepclassmembers class kotlin.Metadata { *; }
-dontwarn kotlin.**

# ── Moshi ──────────────────────────────────────────────────────────────
-keep class com.squareup.moshi.** { *; }
-dontwarn com.squareup.moshi.**
-keep @com.squareup.moshi.JsonQualifier interface *
# Keep every data class field name+type intact for any model Moshi ever
# (de)serializes: local Room entities exported/imported as JSON backups,
# our own backend's request/response DTOs, and Gemini API payloads.
-keepclassmembers class com.example.data.local.entity.** { <fields>; <init>(...); }
-keepclassmembers class com.example.data.api.backend.** { <fields>; <init>(...); }
-keepclassmembers class com.example.data.backup.** { <fields>; <init>(...); }
-keepclassmembers class com.example.domain.model.** { <fields>; <init>(...); }

# ── Retrofit / OkHttp ──────────────────────────────────────────────────
-keepattributes Exceptions
-keep class retrofit2.** { *; }
-dontwarn retrofit2.**
-dontwarn okhttp3.**
-dontwarn okio.**
-keepclasseswithmembers interface com.example.data.api.backend.BackendApi { *; }

# ── Firebase (Auth, Firestore, Remote Config, App Check, Crashlytics, AI) ─
# Firebase ships most of its own consumer rules, but Firestore's automatic
# POJO<->document mapping uses reflection on our own entity classes, so
# those must additionally survive obfuscation (covered by the entity rule
# above). This keeps Firebase's own internal classes untouched as well.
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.android.gms.**

# ── Room ────────────────────────────────────────────────────────────────
-keep class androidx.room.** { *; }
-dontwarn androidx.room.**

# ── Jetpack Security (EncryptedSharedPreferences) ─────────────────────
-keep class androidx.security.crypto.** { *; }
-dontwarn androidx.security.crypto.**

# ── Coroutines ──────────────────────────────────────────────────────────
-keepclassmembernames class kotlinx.** {
    volatile <fields>;
}
-dontwarn kotlinx.coroutines.**

# ── Common noisy/optional-dependency warnings safe to ignore ───────────
-dontwarn javax.annotation.**
-dontwarn org.checkerframework.**
-dontwarn org.codehaus.mojo.animal_sniffer.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# Everything else (our own app code not covered above: ViewModels,
# Repositories, UI Composables, the domain engines) is fully eligible for
# renaming/obfuscation and unused-code removal — that's the whole point of
# turning minification on. Do not blanket-keep the rest of the app.
