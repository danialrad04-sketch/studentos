package com.example.domain.engine

import com.example.data.local.entity.CourseEntity
import com.example.data.parser.ParsedCourseDraft
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ConflictDetectionEngineTest {

    @Test
    fun testClassClassOverlapDetection() {
        val course1 = CourseEntity(
            id = "c1",
            name = "ریاضی عمومی ۱",
            day = 0, // شنبه
            start = "08:00",
            end = "10:00",
            location = "۱۰۱",
            colorHex = "#3B82F6",
            units = 3
        )

        val overlappingCourse = CourseEntity(
            id = "c2",
            name = "فیزیک ۱",
            day = 0, // شنبه
            start = "09:00",
            end = "11:00",
            location = "۱۰۲",
            colorHex = "#EF4444",
            units = 3
        )

        val conflicts = ConflictDetectionEngine.checkCourseConflicts(overlappingCourse, listOf(course1))
        val overlapConflict = conflicts.find { it.type == ConflictType.CLASS_CLASS_OVERLAP }

        assertTrue("Expected class overlap conflict", overlapConflict != null)
        assertEquals(ConflictSeverity.ERROR, overlapConflict?.severity)
    }

    @Test
    fun testExamExamOverlapDetection() {
        val course1 = CourseEntity(
            id = "c1",
            name = "ترمودینامیک ۱",
            day = 1,
            start = "10:00",
            end = "12:00",
            location = "۱۰۳",
            colorHex = "#3B82F6",
            units = 3,
            examDate = "1403/10/22",
            examTime = "09:00"
        )

        val course2 = CourseEntity(
            id = "c2",
            name = "مکانیک سیالات",
            day = 2,
            start = "14:00",
            end = "16:00",
            location = "۱۰۴",
            colorHex = "#EF4444",
            units = 3,
            examDate = "1403/10/22",
            examTime = "09:00"
        )

        val conflicts = ConflictDetectionEngine.checkAllConflicts(listOf(course1, course2))
        val examConflict = conflicts.find { it.type == ConflictType.EXAM_EXAM_OVERLAP }

        assertTrue("Expected exam overlap conflict", examConflict != null)
    }

    @Test
    fun testDuplicateCourseCodeDetection() {
        val course1 = CourseEntity(
            id = "c1",
            name = "شیمی آلی ۱",
            day = 0,
            start = "08:00",
            end = "10:00",
            location = "۱۰۱",
            colorHex = "#3B82F6",
            units = 3,
            courseCode = "CH101"
        )

        val duplicateCodeCourse = CourseEntity(
            id = "c2",
            name = "شیمی آلی - گروه ۲",
            day = 3,
            start = "13:00",
            end = "15:00",
            location = "۱۰۲",
            colorHex = "#EF4444",
            units = 3,
            courseCode = "CH101"
        )

        val conflicts = ConflictDetectionEngine.checkAllConflicts(listOf(course1, duplicateCodeCourse))
        val dupConflict = conflicts.find { it.type == ConflictType.DUPLICATE_COURSE_CODE }

        assertTrue("Expected duplicate course code conflict", dupConflict != null)
    }

    @Test
    fun testInvalidTimeRangeDetection() {
        val invalidCourse = CourseEntity(
            id = "c1",
            name = "درس تست",
            day = 0,
            start = "12:00",
            end = "10:00", // Invalid: end before start
            location = "۱۰۱",
            colorHex = "#3B82F6",
            units = 3
        )

        val conflicts = ConflictDetectionEngine.checkCourseConflicts(invalidCourse, emptyList())
        val timeConflict = conflicts.find { it.type == ConflictType.INVALID_TIME_RANGE }

        assertTrue("Expected invalid time range conflict", timeConflict != null)
        assertEquals(ConflictSeverity.ERROR, timeConflict?.severity)
    }

    @Test
    fun testValidDraftPassesWithoutError() {
        val draft = ParsedCourseDraft(
            name = "آمار و احتمالات مهندسی",
            units = 3,
            dayOfWeek = 2,
            startTime = "10:00",
            endTime = "12:00",
            location = "کلاس ۱۰۵"
        )

        val existing = listOf(
            CourseEntity(
                id = "c0",
                name = "فیزیک ۲",
                day = 0, // Different day
                start = "10:00",
                end = "12:00",
                location = "۱۰۱",
                colorHex = "#3B82F6",
                units = 3
            )
        )

        val conflicts = ConflictDetectionEngine.validateDraft(draft, existing)
        val errors = conflicts.filter { it.severity == ConflictSeverity.ERROR }
        assertTrue("No error conflicts should occur for valid draft", errors.isEmpty())
    }
}
