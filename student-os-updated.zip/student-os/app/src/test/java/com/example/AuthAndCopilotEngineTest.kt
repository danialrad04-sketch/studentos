package com.example

import com.example.data.local.entity.AttendanceEntity
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.GradeEntity
import com.example.data.local.entity.StudentProfileEntity
import com.example.data.local.entity.TaskEntity
import com.example.domain.engine.AcademicCopilotEngine
import com.example.domain.model.SubscriptionDetails
import com.example.domain.model.SubscriptionTier
import com.example.domain.model.UserAccount
import com.example.ui.models.ExamItem
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class AuthAndCopilotEngineTest {

    @Test
    fun testSubscriptionTierPermissions() {
        val freeTier = SubscriptionTier.FREE
        val proTier = SubscriptionTier.PRO
        val ultraTier = SubscriptionTier.ULTRA

        assertEquals(5, freeTier.maxAiQueriesPerDay)
        assertEquals(8, freeTier.maxCourses)
        assertFalse(freeTier.allowsCloudSync)
        assertFalse(freeTier.allowsPdfExport)

        assertEquals(50, proTier.maxAiQueriesPerDay)
        assertEquals(25, proTier.maxCourses)
        assertTrue(proTier.allowsCloudSync)
        assertTrue(proTier.allowsPdfExport)

        assertEquals(999, ultraTier.maxAiQueriesPerDay)
        assertEquals(99, ultraTier.maxCourses)
        assertTrue(ultraTier.allowsCloudSync)
        assertTrue(ultraTier.allowsPdfExport)
    }

    @Test
    fun testUserAccountProGating() {
        val guestUser = UserAccount(
            uid = "guest_123",
            email = "",
            displayName = "مهمان",
            isGuest = true,
            subscription = SubscriptionDetails(tier = SubscriptionTier.FREE)
        )
        assertFalse(guestUser.isProOrHigher)

        val proUser = UserAccount(
            uid = "user_456",
            email = "student@aut.ac.ir",
            displayName = "امیرحسین",
            isGuest = false,
            subscription = SubscriptionDetails(tier = SubscriptionTier.PRO)
        )
        assertTrue(proUser.isProOrHigher)

        val ultraUser = UserAccount(
            uid = "user_789",
            email = "elite@aut.ac.ir",
            displayName = "سارا",
            isGuest = false,
            subscription = SubscriptionDetails(tier = SubscriptionTier.ULTRA)
        )
        assertTrue(ultraUser.isProOrHigher)
    }

    @Test
    fun testAcademicCopilotWelcomeAndProcessQuery() {
        val sampleProfile = StudentProfileEntity(
            id = 1,
            name = "امیرحسین",
            studentId = "40112345",
            major = "مهندسی شیمی",
            university = "دانشگاه صنعتی امیرکبیر",
            entryYear = 1401,
            currentSemester = 6,
            passedUnits = 85,
            activeUnits = 18,
            declaredGpa = 17.2,
            term = "ترم ۶"
        )

        val sampleCourses = listOf(
            CourseEntity(id = "c1", name = "انتقال حرارت ۱", professor = "دکتر نوری", location = "۱۰۲", day = 0, start = "08:00", end = "10:00", units = 3, colorHex = "#3B82F6"),
            CourseEntity(id = "c2", name = "مکانیک سیالات", professor = "دکتر رضایی", location = "۱۰۴", day = 2, start = "10:30", end = "12:30", units = 3, colorHex = "#10B981")
        )

        val sampleAttendance = listOf(
            AttendanceEntity(courseId = "c1", courseName = "انتقال حرارت ۱", absentCount = 2, maxAllowed = 3),
            AttendanceEntity(courseId = "c2", courseName = "مکانیک سیالات", absentCount = 0, maxAllowed = 3)
        )

        val sampleGrades = listOf(
            GradeEntity(id = 1, courseName = "انتقال حرارت ۱", units = 3, midtermGrade = 7.5, finalGrade = 9.0, courseId = "c1"),
            GradeEntity(id = 2, courseName = "مکانیک سیالات", units = 3, midtermGrade = 8.0, finalGrade = 9.5, courseId = "c2")
        )

        val sampleTasks = listOf(
            TaskEntity(id = 1, title = "پروژه شبیه‌سازی سیالات", dueDate = "1404/09/25", isCompleted = false, courseId = "c2")
        )

        val sampleExams = listOf(
            ExamItem(id = "e1", courseName = "انتقال حرارت ۱", solarDate = "1404/10/15", time = "09:00", location = "تالار ۱", units = 3)
        )

        val welcome = AcademicCopilotEngine.generateWelcomeMessage(
            profile = sampleProfile,
            courses = sampleCourses,
            attendanceList = sampleAttendance,
            grades = sampleGrades,
            tasks = sampleTasks
        )

        assertNotNull(welcome)
        assertTrue(welcome.text.isNotBlank())
        assertTrue(welcome.text.contains("امیرحسین"))

        val queryResponse = AcademicCopilotEngine.processUserQuery(
            query = "غیبت های من چطوره؟",
            profile = sampleProfile,
            courses = sampleCourses,
            attendanceList = sampleAttendance,
            grades = sampleGrades,
            tasks = sampleTasks,
            exams = sampleExams
        )

        assertNotNull(queryResponse)
        assertTrue(queryResponse.text.contains("غیبت") || queryResponse.text.contains("قانون"))
    }

    @Test
    fun testAcademicCopilotAsyncQueryFallback() = runBlocking {
        val sampleProfile = StudentProfileEntity(
            id = 1,
            name = "امیرحسین",
            studentId = "40112345",
            major = "مهندسی شیمی",
            university = "دانشگاه صنعتی امیرکبیر",
            entryYear = 1401,
            currentSemester = 6,
            passedUnits = 85,
            activeUnits = 18,
            declaredGpa = 17.2,
            term = "ترم ۶"
        )

        val message = AcademicCopilotEngine.processUserQueryAsync(
            query = "برای فارغ‌التحصیلی چند واحد دیگه نیاز دارم؟",
            profile = sampleProfile,
            courses = emptyList(),
            attendanceList = emptyList(),
            grades = emptyList(),
            tasks = emptyList(),
            exams = emptyList(),
            customApiKey = null
        )

        assertNotNull(message)
        assertTrue(message.text.isNotBlank())
    }
}
