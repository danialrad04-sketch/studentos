package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.backup.LocalDataBackupManager
import com.example.data.local.AppDatabase
import com.example.data.local.dao.CurriculumDao
import com.example.data.local.dao.StudentDao
import com.example.data.local.entity.AttendanceEntity
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.CurriculumCourseEntity
import com.example.data.local.entity.ExamEntity
import com.example.data.local.entity.GradeEntity
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.ProfessorEntity
import com.example.data.local.entity.SemesterEntity
import com.example.data.local.entity.StudentCourseAttemptEntity
import com.example.data.local.entity.StudentProfileEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.parser.ParsedCourseDraft
import com.example.data.seed.CurriculumSeedData
import com.example.domain.usecase.NewSemesterRequest
import com.example.domain.usecase.SemesterTransitionResult
import com.example.domain.usecase.SemesterTransitionUseCase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * StudentRepository serving as the single Source of Truth for Student OS.
 * All relational operations rely on stable IDs (courseId, semesterId, professorId).
 */
class StudentRepository(
    private val dao: StudentDao,
    private val curriculumDao: CurriculumDao? = null,
    private val database: AppDatabase? = null
) {
    // Reactive Streams from Room
    val semesters: Flow<List<SemesterEntity>> = dao.getAllSemesters()
    val archivedSemesters: Flow<List<SemesterEntity>> = dao.getArchivedSemesters()
    val currentSemester: Flow<SemesterEntity?> = dao.getCurrentSemester()
    val courses: Flow<List<CourseEntity>> = dao.getCurrentSemesterCourses()
    val allCourses: Flow<List<CourseEntity>> = dao.getAllCourses()
    val allCoursesIncludingArchived: Flow<List<CourseEntity>> = dao.getAllCoursesIncludingArchived()
    val attendance: Flow<List<AttendanceEntity>> = dao.getAllAttendance()
    val grades: Flow<List<GradeEntity>> = dao.getAllGrades()
    val tasks: Flow<List<TaskEntity>> = dao.getAllTasks()
    val professors: Flow<List<ProfessorEntity>> = dao.getAllProfessors()
    val exams: Flow<List<ExamEntity>> = dao.getAllExams()
    val notes: Flow<List<NoteEntity>> = dao.getAllNotes()
    val profile: Flow<StudentProfileEntity?> = dao.getProfile()
    val curriculumCourses: Flow<List<CurriculumCourseEntity>>? = curriculumDao?.getAllCurriculumCourses()
    val studentAttempts: Flow<List<StudentCourseAttemptEntity>> = dao.getStudentAttempts(1)

    // ==========================================
    // Semester Lifecycle & History
    // ==========================================
    suspend fun getCurrentSemesterSync(): SemesterEntity? = withContext(Dispatchers.IO) {
        dao.getCurrentSemesterSync()
    }

    suspend fun saveSemester(semester: SemesterEntity) = withContext(Dispatchers.IO) {
        dao.insertSemester(semester.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun createNewSemester(
        title: String,
        academicYear: Int,
        termNumber: Int,
        setAsCurrent: Boolean = true
    ): SemesterEntity = withContext(Dispatchers.IO) {
        if (setAsCurrent) {
            dao.clearCurrentSemesterFlag()
        }
        val newSemester = SemesterEntity(
            id = "sem_${academicYear}_${termNumber}_${UUID.randomUUID().toString().take(6)}",
            title = title,
            year = academicYear,
            academicYear = academicYear,
            semesterNumber = termNumber,
            termNumber = termNumber,
            isCurrent = setAsCurrent,
            isArchived = false,
            status = if (setAsCurrent) "ACTIVE" else "UPCOMING",
            totalUnits = 0,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        dao.insertSemester(newSemester)
        newSemester
    }

    suspend fun archiveSemester(semesterId: String) = withContext(Dispatchers.IO) {
        val sem = dao.getSemesterById(semesterId)
        if (sem != null) {
            dao.updateSemester(
                sem.copy(
                    isArchived = true,
                    isCurrent = false,
                    status = "ARCHIVED",
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun startNewSemester(request: NewSemesterRequest): SemesterTransitionResult = withContext(Dispatchers.IO) {
        if (database != null) {
            val useCase = SemesterTransitionUseCase(database, dao)
            useCase.startNewSemester(request)
        } else {
            // Fallback manual transition
            val current = dao.getCurrentSemesterSync()
            if (current != null) {
                dao.updateSemester(current.copy(isCurrent = false, isArchived = true, status = "ARCHIVED"))
            }
            dao.clearCurrentSemesterFlag()
            val created = createNewSemester(request.title, request.academicYear, request.termNumber, true)
            SemesterTransitionResult(current, created, 0, 0)
        }
    }

    fun getCoursesForSemester(semesterId: String): Flow<List<CourseEntity>> =
        dao.getCoursesBySemester(semesterId)

    suspend fun getCoursesForSemesterSync(semesterId: String): List<CourseEntity> = withContext(Dispatchers.IO) {
        dao.getCoursesBySemesterSync(semesterId)
    }

    // ==========================================
    // Course Operations with Stable IDs & Duplicate Prevention
    // ==========================================
    suspend fun isDuplicateCourse(course: CourseEntity): Boolean = withContext(Dispatchers.IO) {
        val existingInSemester = dao.getCoursesBySemesterSync(course.semesterId)
        existingInSemester.any { existing ->
            existing.id != course.id && (
                (course.courseCode.isNotBlank() && existing.courseCode.isNotBlank() &&
                    existing.courseCode.trim().equals(course.courseCode.trim(), ignoreCase = true)) ||
                (existing.name.trim().equals(course.name.trim(), ignoreCase = true) &&
                    existing.day == course.day && existing.start == course.start)
            )
        }
    }

    suspend fun saveCourse(course: CourseEntity) = withContext(Dispatchers.IO) {
        val courseId = if (course.id.isNotBlank()) course.id else "c_${UUID.randomUUID().toString().take(8)}"
        val entity = course.copy(id = courseId)
        dao.insertCourse(entity)

        // Ensure Attendance record with courseId as primary key
        val existingAtt = dao.getAttendanceByCourseId(courseId)
        if (existingAtt == null) {
            dao.insertAttendance(
                AttendanceEntity(
                    courseId = courseId,
                    courseName = entity.name,
                    absentCount = 0,
                    maxAllowed = if (entity.name.contains("آزمایشگاه") || entity.name.contains("کارگاه")) 2 else 3
                )
            )
        } else if (existingAtt.courseName != entity.name) {
            dao.updateAttendance(existingAtt.copy(courseName = entity.name))
        }

        // Ensure Grade record with courseId relation
        val existingGrade = dao.getGradeByCourseId(courseId)
        if (existingGrade == null) {
            dao.insertGrade(
                GradeEntity(
                    courseId = courseId,
                    courseName = entity.name,
                    units = entity.units,
                    midtermGrade = 0.0,
                    finalGrade = 0.0
                )
            )
        } else if (existingGrade.courseName != entity.name || existingGrade.units != entity.units) {
            dao.updateGrade(existingGrade.copy(courseName = entity.name, units = entity.units))
        }

        // Sync Exam record if exam details are provided
        if (entity.examDate.isNotBlank() || entity.examTime.isNotBlank()) {
            dao.insertExam(
                ExamEntity(
                    id = "exam_$courseId",
                    courseId = courseId,
                    courseName = entity.name,
                    date = entity.examDate,
                    time = entity.examTime,
                    location = entity.examLocation
                )
            )
        }
    }

    suspend fun deleteCourse(courseId: String) = withContext(Dispatchers.IO) {
        val course = dao.getCourseById(courseId)
        dao.deleteCourseById(courseId)
        dao.deleteAttendanceByCourseId(courseId)
        dao.deleteGradeByCourseId(courseId)
        dao.deleteTasksByCourseId(courseId)
        dao.deleteExamByCourseId(courseId)
        if (course != null) {
            dao.deleteAttendanceForCourse(course.name, courseId)
            dao.deleteGradeForCourse(course.name, courseId)
            dao.deleteTasksForCourse(courseId, course.name)
        }
        dao.cleanupOrphans()
    }

    suspend fun archiveCourse(courseId: String) = withContext(Dispatchers.IO) {
        val course = dao.getCourseById(courseId)
        if (course != null) {
            dao.updateCourse(course.copy(isArchived = true))
        }
    }

    suspend fun restoreCourse(courseId: String) = withContext(Dispatchers.IO) {
        val course = dao.getCourseById(courseId)
        if (course != null) {
            dao.updateCourse(course.copy(isArchived = false))
        }
    }

    // ==========================================
    // Attendance & Grades
    // ==========================================
    suspend fun updateAttendance(attendanceEntity: AttendanceEntity) = withContext(Dispatchers.IO) {
        dao.insertAttendance(attendanceEntity)
    }

    suspend fun updateGrade(grade: GradeEntity) = withContext(Dispatchers.IO) {
        dao.updateGrade(grade)
    }

    // ==========================================
    // Tasks
    // ==========================================
    suspend fun saveTask(task: TaskEntity) = withContext(Dispatchers.IO) {
        dao.insertTask(task)
    }

    suspend fun toggleTaskCompletion(task: TaskEntity) = withContext(Dispatchers.IO) {
        dao.updateTask(task.copy(isCompleted = !task.isCompleted))
    }

    suspend fun deleteTask(task: TaskEntity) = withContext(Dispatchers.IO) {
        dao.deleteTask(task)
    }

    // ==========================================
    // Exams & Notes & Professors
    // ==========================================
    suspend fun saveExam(exam: ExamEntity) = withContext(Dispatchers.IO) {
        dao.insertExam(exam)
    }

    suspend fun deleteExam(courseId: String) = withContext(Dispatchers.IO) {
        dao.deleteExamByCourseId(courseId)
    }

    suspend fun saveNote(note: NoteEntity) = withContext(Dispatchers.IO) {
        dao.insertNote(note.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteNote(id: String) = withContext(Dispatchers.IO) {
        dao.deleteNote(id)
    }

    suspend fun saveProfessor(professor: ProfessorEntity) = withContext(Dispatchers.IO) {
        dao.insertProfessor(professor)
    }

    // ==========================================
    // Profile & Transcript Attempts
    // ==========================================
    suspend fun getProfileSync(): StudentProfileEntity? = withContext(Dispatchers.IO) {
        dao.getProfileSync()
    }

    suspend fun updateProfile(profile: StudentProfileEntity) = withContext(Dispatchers.IO) {
        dao.insertProfile(profile)
    }

    suspend fun setOnboardingCompleted(
        completed: Boolean,
        name: String = "",
        studentId: String = "",
        university: String = "",
        major: String = "",
        entryYear: Int = 1403,
        currentSemester: Int = 1,
        passedCredits: Int = 0,
        declaredGpa: Double = 0.0
    ) = withContext(Dispatchers.IO) {
        val current = dao.getProfileSync() ?: StudentProfileEntity()
        val updated = current.copy(
            isOnboardingCompleted = completed,
            name = if (name.isNotBlank()) name else current.name,
            studentId = if (studentId.isNotBlank()) studentId else current.studentId,
            university = if (university.isNotBlank()) university else current.university,
            major = if (major.isNotBlank()) major else current.major,
            entryYear = if (entryYear > 0) entryYear else current.entryYear,
            currentSemester = if (currentSemester > 0) currentSemester else current.currentSemester,
            passedUnits = if (passedCredits > 0) passedCredits else current.passedUnits,
            declaredPassedCredits = if (passedCredits > 0) passedCredits else current.declaredPassedCredits,
            declaredGpa = if (declaredGpa > 0.0) declaredGpa else current.declaredGpa,
            term = if (currentSemester > 0 && major.isNotBlank()) "ترم $currentSemester $major" else current.term
        )
        dao.insertProfile(updated)
    }

    suspend fun saveStudentAttempt(attempt: StudentCourseAttemptEntity) = withContext(Dispatchers.IO) {
        dao.insertStudentAttempt(attempt)
    }

    suspend fun deleteStudentAttempt(attemptId: String) = withContext(Dispatchers.IO) {
        dao.deleteStudentAttempt(attemptId)
    }

    suspend fun clearStudentAttempts() = withContext(Dispatchers.IO) {
        dao.clearStudentAttempts(1)
    }

    // ==========================================
    // Database Backup & Restore Delegation
    // ==========================================
    suspend fun exportFullBackupJson(): String = withContext(Dispatchers.IO) {
        LocalDataBackupManager.exportCompleteDatabaseJson(dao, curriculumDao)
    }

    suspend fun restoreFullBackupJson(jsonString: String): Result<Int> = withContext(Dispatchers.IO) {
        LocalDataBackupManager.restoreDatabaseFromJson(jsonString, dao, curriculumDao)
    }

    // ==========================================
    // Bulk Course Import (Atomic Transaction)
    // ==========================================
    suspend fun importParsedCourses(
        drafts: List<ParsedCourseDraft>,
        semesterId: String = "current",
        clearExisting: Boolean = false,
        studentName: String = "",
        studentId: String = "",
        university: String = "",
        major: String = "",
        entryYear: Int = 1403,
        currentSemester: Int = 1
    ) {
        val performImport = suspend {
            if (clearExisting) {
                dao.clearCourses()
                dao.clearAttendance()
                dao.clearGrades()
                dao.clearExams()
            }

            val colors = listOf("#10B981", "#3B82F6", "#F59E0B", "#EF4444", "#8B5CF6", "#0EA5E9", "#6366F1")
            drafts.forEachIndexed { index, draft ->
                val id = UUID.randomUUID().toString()
                val itemSemId = if (draft.targetSemester > 0) "sem_${draft.targetSemester}" else semesterId
                val entity = CourseEntity(
                    id = id,
                    name = draft.name.trim(),
                    day = draft.dayOfWeek,
                    start = draft.startTime,
                    end = draft.endTime,
                    location = draft.location,
                    colorHex = colors[index % colors.size],
                    units = draft.units,
                    semesterId = itemSemId,
                    courseCode = draft.courseCode,
                    professor = draft.instructor,
                    examDate = draft.examDate,
                    examTime = draft.examTime,
                    examLocation = draft.examLocation,
                    notes = draft.notes
                )
                dao.insertCourse(entity)

                // Attendance with courseId as primary key
                dao.insertAttendance(
                    AttendanceEntity(
                        courseId = id,
                        courseName = draft.name.trim(),
                        absentCount = 0,
                        maxAllowed = if (draft.name.contains("آزمایشگاه") || draft.name.contains("کارگاه")) 2 else 3
                    )
                )

                // Grade with courseId foreign key
                dao.insertGrade(
                    GradeEntity(
                        courseId = id,
                        courseName = draft.name.trim(),
                        units = draft.units,
                        midtermGrade = 0.0,
                        finalGrade = 0.0
                    )
                )

                // Exam if date/time present
                if (draft.examDate.isNotBlank() || draft.examTime.isNotBlank()) {
                    dao.insertExam(
                        ExamEntity(
                            id = "exam_$id",
                            courseId = id,
                            courseName = draft.name.trim(),
                            date = draft.examDate,
                            time = draft.examTime,
                            location = draft.examLocation
                        )
                    )
                }
            }

            val current = dao.getProfileSync()
            if (current != null) {
                val totalUnits = drafts.sumOf { it.units }
                val detectedMaxSem = drafts.map { it.targetSemester }.filter { it > 0 }.maxOrNull() ?: current.currentSemester
                val resolvedSemester = if (currentSemester > 0) currentSemester else if (detectedMaxSem > 0) detectedMaxSem else current.currentSemester
                val resolvedMajor = if (major.isNotBlank()) major else current.major
                dao.insertProfile(
                    current.copy(
                        name = if (studentName.isNotBlank()) studentName else current.name,
                        studentId = if (studentId.isNotBlank()) studentId else current.studentId,
                        university = if (university.isNotBlank()) university else current.university,
                        major = resolvedMajor,
                        entryYear = if (entryYear > 0) entryYear else current.entryYear,
                        activeUnits = totalUnits,
                        currentSemester = resolvedSemester,
                        term = "ترم $resolvedSemester $resolvedMajor",
                        faculty = "دانشکده $resolvedMajor · $totalUnits واحد فعال",
                        isOnboardingCompleted = true
                    )
                )
            }
        }

        if (database != null) {
            database.withTransaction { performImport() }
        } else {
            performImport()
        }
    }

    suspend fun completeQuickAcademicSetup(
        name: String = "دانشجو",
        studentId: String = "",
        university: String,
        major: String,
        entryYear: Int,
        currentSemester: Int,
        passedCredits: Int,
        currentGpa: Double,
        selectedCourses: List<CurriculumCourseEntity>
    ) = withContext(Dispatchers.IO) {
        val totalActiveUnits = selectedCourses.sumOf { it.units }
        val activeSemesterId = "sem_$currentSemester"
        val calculatedAcademicYear = entryYear + ((currentSemester - 1) / 2)

        val performSetup: suspend () -> Unit = {
            // 1. Seed complete curriculum catalog for this major if needed
            val fullCurriculum = CurriculumSeedData.getCoursesForMajor(major)
            if (fullCurriculum.isNotEmpty()) {
                curriculumDao?.insertCurriculumCourses(fullCurriculum)
            }

            // 2. Mark existing semesters as non-current and insert active current semester
            dao.clearCurrentSemesterFlag()
            dao.insertSemester(
                SemesterEntity(
                    id = activeSemesterId,
                    title = "ترم $currentSemester ($major)",
                    year = calculatedAcademicYear,
                    academicYear = calculatedAcademicYear,
                    semesterNumber = currentSemester,
                    termNumber = currentSemester,
                    isCurrent = true,
                    isArchived = false,
                    totalUnits = totalActiveUnits
                )
            )

            // 3. Update student profile
            val updatedProfile = StudentProfileEntity(
                id = 1,
                name = name.ifBlank { "دانشجو" },
                studentId = studentId.trim(),
                university = university,
                major = major,
                entryYear = entryYear,
                currentSemester = currentSemester,
                passedUnits = passedCredits,
                declaredPassedCredits = passedCredits,
                declaredGpa = currentGpa,
                activeUnits = totalActiveUnits,
                term = "ترم $currentSemester $major",
                faculty = "دانشکده $major · $totalActiveUnits واحد فعال ترم جاری",
                isOnboardingCompleted = true
            )
            dao.insertProfile(updatedProfile)

            // 4. Seed passed course attempts for prior semesters (1 until currentSemester - 1)
            dao.clearStudentAttempts(1)
            val pastCourses = fullCurriculum.filter { it.recommendedSemester < currentSemester }
            pastCourses.forEach { pastCourse ->
                dao.insertStudentAttempt(
                    StudentCourseAttemptEntity(
                        id = UUID.randomUUID().toString(),
                        profileId = 1,
                        courseId = pastCourse.id,
                        courseName = pastCourse.name,
                        units = pastCourse.units,
                        attemptNumber = 1,
                        semesterIndex = pastCourse.recommendedSemester,
                        status = "PASSED",
                        grade = currentGpa,
                        source = "QUICK_SETUP"
                    )
                )
            }

            // 5. Populate active enrolled courses for current semester
            if (selectedCourses.isNotEmpty()) {
                dao.clearCourses()
                dao.clearAttendance()
                dao.clearGrades()
                dao.clearExams()

                val colors = listOf("#10B981", "#3B82F6", "#F59E0B", "#EF4444", "#8B5CF6", "#0EA5E9", "#6366F1")
                selectedCourses.forEachIndexed { index, cc ->
                    val day = index % 5
                    val start = if (index % 2 == 0) "08:00" else "10:00"
                    val end = if (index % 2 == 0) "10:00" else "12:00"
                    val courseId = UUID.randomUUID().toString()

                    val course = CourseEntity(
                        id = courseId,
                        name = cc.name,
                        day = day,
                        start = start,
                        end = end,
                        location = "کلاس 10${index + 1} دانشکده",
                        colorHex = colors[index % colors.size],
                        units = cc.units,
                        semesterId = activeSemesterId,
                        courseCode = cc.code,
                        professor = "استاد دانشکده",
                        examDate = "1403/10/${15 + index}",
                        examTime = "09:00",
                        examLocation = "سالن امتحانات دانشکده"
                    )
                    dao.insertCourse(course)

                    val maxAllowed = if (cc.courseType == "آزمایشگاهی") 2 else 3
                    dao.insertAttendance(
                        AttendanceEntity(
                            courseId = courseId,
                            courseName = cc.name,
                            absentCount = 0,
                            maxAllowed = maxAllowed
                        )
                    )

                    val midtermEst = (currentGpa * 0.35).coerceIn(4.0, 7.0)
                    val finalEst = (currentGpa * 0.65).coerceIn(8.0, 13.0)
                    dao.insertGrade(
                        GradeEntity(
                            courseId = courseId,
                            courseName = cc.name,
                            units = cc.units,
                            midtermGrade = midtermEst,
                            finalGrade = finalEst
                        )
                    )

                    dao.insertExam(
                        ExamEntity(
                            id = "exam_$courseId",
                            courseId = courseId,
                            courseName = cc.name,
                            date = course.examDate,
                            time = course.examTime,
                            location = course.examLocation
                        )
                    )
                }
            }
        }

        try {
            if (database != null) {
                database.withTransaction { performSetup() }
            } else {
                performSetup()
            }
        } catch (e: Exception) {
            android.util.Log.e("StudentRepository", "Error during completeQuickAcademicSetup withTransaction, fallback executing sequentially", e)
            performSetup()
        }
    }

    suspend fun resetDefaults() {
        dao.clearCourses()
        dao.clearAttendance()
        dao.clearGrades()
        dao.clearTasks()
        dao.clearExams()
        dao.clearStudentAttempts(1)
        AppDatabase.populateInitialData(dao, curriculumDao)
    }

    suspend fun loadRichDemoData() {
        val performDemo = suspend {
            dao.clearCourses()
            dao.clearAttendance()
            dao.clearGrades()
            dao.clearTasks()
            dao.clearExams()
            dao.clearStudentAttempts(1)

            val demoSemester = SemesterEntity(
                id = "sem_demo_3",
                title = "ترم ۳ (پاییز ۱۴۰۳)",
                year = 1403,
                academicYear = 1403,
                semesterNumber = 3,
                termNumber = 3,
                isCurrent = true,
                isArchived = false,
                totalUnits = 19
            )
            dao.insertSemester(demoSemester)

            val demoProfile = StudentProfileEntity(
                id = 1,
                name = "دانشجو",
                studentId = "",
                faculty = "دانشکده مهندسی شیمی و نفت · ۱۹ واحد فعال",
                term = "ترم ۳ مهندسی شیمی",
                activeUnits = 19,
                passedUnits = 54,
                notes = "فرمول‌های مهم ترمودینامیک و سیالات:\n• گاز ایده‌آل: PV = nRT\n• ضریب تراکم‌پذیری: Z = PV / RT",
                isOnboardingCompleted = true,
                universityId = "UNI_AUT",
                facultyId = "FAC_AUT_CHEM_OIL",
                majorId = "MAJ_AUT_CHEM_ENG",
                declaredPassedCredits = 54,
                declaredGpa = 17.40
            )
            dao.insertProfile(demoProfile)

            val demoCourses = listOf(
                CourseEntity("c1", "محاسبات عددی", 0, "08:00", "10:00", "کلاس 107 فنی", "#10B981", 2, "sem_demo_3", "CE101", null, "دکتر احمدی", "1403/10/23", "08:30", "کلاس 107 فنی"),
                CourseEntity("c2", "ریاضی مهندسی", 0, "14:00", "15:00", "کلاس 108 فنی", "#3B82F6", 3, "sem_demo_3", "CE102", null, "دکتر حسینی", "1403/10/28", "08:30", "کلاس 108 فنی"),
                CourseEntity("c3", "ترمودینامیک مهندسی شیمی ۱", 0, "15:00", "16:00", "کلاس 108 فنی", "#F59E0B", 3, "sem_demo_3", "CE103", null, "دکتر رضایی", "1403/10/26", "10:45", "کلاس 108 فنی"),
                CourseEntity("c4", "فیزیک ۲", 1, "08:00", "10:00", "کلاس 107 فنی", "#EF4444", 3, "sem_demo_3", "CE104", null, "دکتر محمدی", "1403/10/19", "08:30", "کلاس 107 فنی"),
                CourseEntity("c5", "ترمودینامیک مهندسی شیمی ۱", 1, "10:00", "12:00", "کلاس 108 فنی", "#F59E0B", 3, "sem_demo_3", "CE103", null, "دکتر رضایی", "1403/10/26", "10:45", "کلاس 108 فنی"),
                CourseEntity("c6", "آزمایشگاه شیمی عمومی", 1, "14:00", "16:00", "آزمایشگاه شیمی ۱", "#14B8A6", 1, "sem_demo_3", "CE105", null, "مهندس کریمی", "1403/10/15", "14:00", "آزمایشگاه"),
                CourseEntity("c7", "تفسیر موضوعی قرآن", 2, "08:00", "10:00", "کلاس 118 کشاورزی", "#8B5CF6", 2, "sem_demo_3", "CE106", null, "استاد تقوی", "1403/11/02", "14:00", "کلاس 118"),
                CourseEntity("c8", "نقشه کشی صنعتی", 2, "10:00", "12:00", "کلاس 108 فنی", "#0EA5E9", 2, "sem_demo_3", "CE107", null, "مهندس عباسی", "1403/10/18", "10:00", "آتلیه 2"),
                CourseEntity("c9", "مکانیک سیالات ۱", 2, "14:00", "16:00", "کلاس 111 فنی", "#6366F1", 3, "sem_demo_3", "CE108", null, "دکتر اکبری", "1403/10/21", "10:45", "کلاس 111 فنی")
            )
            dao.insertCourses(demoCourses)

            demoCourses.distinctBy { it.id }.forEach { c ->
                dao.insertAttendance(AttendanceEntity(courseId = c.id, courseName = c.name, absentCount = 1, maxAllowed = 3))
                dao.insertGrade(GradeEntity(courseId = c.id, courseName = c.name, units = c.units, midtermGrade = 5.5, finalGrade = 11.5))
                if (c.examDate.isNotBlank()) {
                    dao.insertExam(
                        ExamEntity(
                            id = "exam_${c.id}",
                            courseId = c.id,
                            courseName = c.name,
                            date = c.examDate,
                            time = c.examTime,
                            location = c.examLocation
                        )
                    )
                }
            }

            dao.insertTask(TaskEntity(title = "حل تمرین سری ۴ سیالات", courseName = "مکانیک سیالات ۱", dueDate = "1403/10/15", isCompleted = false, courseId = "c9", semesterId = "sem_demo_3"))
            dao.insertTask(TaskEntity(title = "پروژه شبیه‌سازی متلب", courseName = "محاسبات عددی", dueDate = "1403/10/20", isCompleted = true, courseId = "c1", semesterId = "sem_demo_3"))
        }

        if (database != null) {
            database.withTransaction { performDemo() }
        } else {
            performDemo()
        }
    }

    suspend fun clearToFreshSlate(
        name: String = "دانشجو",
        studentId: String = "",
        university: String = "دانشگاه",
        major: String = "مهندسی",
        entryYear: Int = 1403,
        currentSemester: Int = 1
    ) {
        val performClear = suspend {
            dao.clearCourses()
            dao.clearAttendance()
            dao.clearGrades()
            dao.clearTasks()
            dao.clearExams()
            dao.clearStudentAttempts(1)

            val freshSem = SemesterEntity(
                id = "sem_1",
                title = "ترم $currentSemester",
                year = entryYear,
                academicYear = entryYear,
                semesterNumber = currentSemester,
                termNumber = currentSemester,
                isCurrent = true,
                isArchived = false,
                totalUnits = 0
            )
            dao.insertSemester(freshSem)

            val emptyProfile = StudentProfileEntity(
                id = 1,
                name = name,
                studentId = studentId,
                university = university,
                major = major,
                entryYear = entryYear,
                currentSemester = currentSemester,
                faculty = "دانشکده $major · ۰ واحد فعال",
                term = "ترم $currentSemester $major",
                activeUnits = 0,
                passedUnits = 0,
                notes = "",
                isOnboardingCompleted = true,
                universityId = null,
                facultyId = null,
                majorId = null,
                declaredPassedCredits = 0,
                declaredGpa = null
            )
            dao.insertProfile(emptyProfile)
        }

        if (database != null) {
            database.withTransaction { performClear() }
        } else {
            performClear()
        }
    }
}
