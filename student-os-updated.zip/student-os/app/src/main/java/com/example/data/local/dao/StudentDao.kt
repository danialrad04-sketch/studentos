package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.local.entity.AttendanceEntity
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.ExamEntity
import com.example.data.local.entity.GradeEntity
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.ProfessorEntity
import com.example.data.local.entity.SemesterEntity
import com.example.data.local.entity.StudentCourseAttemptEntity
import com.example.data.local.entity.StudentProfileEntity
import com.example.data.local.entity.TaskEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentDao {
    // ==========================================
    // 1. Semesters (Multi-Semester Lifecycle)
    // ==========================================
    @Query("SELECT * FROM semesters ORDER BY academicYear DESC, termNumber DESC")
    fun getAllSemesters(): Flow<List<SemesterEntity>>

    @Query("SELECT * FROM semesters ORDER BY academicYear DESC, termNumber DESC")
    suspend fun getAllSemestersSync(): List<SemesterEntity>

    @Query("SELECT * FROM semesters WHERE isArchived = 1 ORDER BY academicYear DESC, termNumber DESC")
    fun getArchivedSemesters(): Flow<List<SemesterEntity>>

    @Query("SELECT * FROM semesters WHERE isCurrent = 1 LIMIT 1")
    fun getCurrentSemester(): Flow<SemesterEntity?>

    @Query("SELECT * FROM semesters WHERE isCurrent = 1 LIMIT 1")
    suspend fun getCurrentSemesterSync(): SemesterEntity?

    @Query("SELECT * FROM semesters WHERE id = :semesterId LIMIT 1")
    suspend fun getSemesterById(semesterId: String): SemesterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSemester(semester: SemesterEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSemesters(semesters: List<SemesterEntity>)

    @Update
    suspend fun updateSemester(semester: SemesterEntity)

    @Query("UPDATE semesters SET isCurrent = 0")
    suspend fun clearCurrentSemesterFlag()

    @Query("DELETE FROM semesters WHERE id = :semesterId")
    suspend fun deleteSemester(semesterId: String)

    // ==========================================
    // 2. Courses (Current vs Archived Multi-Semester)
    // ==========================================
    @Query("""
        SELECT * FROM courses 
        WHERE (semesterId IN (SELECT id FROM semesters WHERE isCurrent = 1) OR semesterId = 'current') 
          AND isArchived = 0 
        ORDER BY day ASC, start ASC
    """)
    fun getCurrentSemesterCourses(): Flow<List<CourseEntity>>

    @Query("SELECT * FROM courses WHERE isArchived = 0 ORDER BY day ASC, start ASC")
    fun getAllCourses(): Flow<List<CourseEntity>>

    @Query("SELECT * FROM courses ORDER BY day ASC, start ASC")
    fun getAllCoursesIncludingArchived(): Flow<List<CourseEntity>>

    @Query("SELECT * FROM courses ORDER BY day ASC, start ASC")
    suspend fun getAllCoursesIncludingArchivedSync(): List<CourseEntity>

    @Query("SELECT * FROM courses WHERE semesterId = :semesterId ORDER BY day ASC, start ASC")
    fun getCoursesBySemester(semesterId: String): Flow<List<CourseEntity>>

    @Query("SELECT * FROM courses WHERE semesterId = :semesterId ORDER BY day ASC, start ASC")
    suspend fun getCoursesBySemesterSync(semesterId: String): List<CourseEntity>

    @Query("SELECT * FROM courses WHERE id = :courseId LIMIT 1")
    suspend fun getCourseById(courseId: String): CourseEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourse(course: CourseEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourses(courses: List<CourseEntity>)

    @Update
    suspend fun updateCourse(course: CourseEntity)

    @Query("DELETE FROM courses WHERE id = :courseId")
    suspend fun deleteCourseById(courseId: String)

    @Query("DELETE FROM courses")
    suspend fun clearCourses()

    // ==========================================
    // 3. Professors (Stable Entity)
    // ==========================================
    @Query("SELECT * FROM professors ORDER BY name ASC")
    fun getAllProfessors(): Flow<List<ProfessorEntity>>

    @Query("SELECT * FROM professors ORDER BY name ASC")
    suspend fun getAllProfessorsSync(): List<ProfessorEntity>

    @Query("SELECT * FROM professors WHERE id = :id LIMIT 1")
    suspend fun getProfessorById(id: String): ProfessorEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfessor(professor: ProfessorEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfessors(professors: List<ProfessorEntity>)

    // ==========================================
    // 4. Exams (Stable courseId Foreign Key)
    // ==========================================
    @Query("SELECT * FROM exams ORDER BY date ASC, time ASC")
    fun getAllExams(): Flow<List<ExamEntity>>

    @Query("SELECT * FROM exams ORDER BY date ASC, time ASC")
    suspend fun getAllExamsSync(): List<ExamEntity>

    @Query("SELECT * FROM exams WHERE courseId = :courseId LIMIT 1")
    suspend fun getExamByCourseId(courseId: String): ExamEntity?

    @Query("""
        SELECT e.* FROM exams e
        INNER JOIN courses c ON e.courseId = c.id
        WHERE c.semesterId = :semesterId
        ORDER BY e.date ASC, e.time ASC
    """)
    fun getExamsForSemester(semesterId: String): Flow<List<ExamEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExam(exam: ExamEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExams(exams: List<ExamEntity>)

    @Query("DELETE FROM exams WHERE courseId = :courseId")
    suspend fun deleteExamByCourseId(courseId: String)

    @Query("DELETE FROM exams")
    suspend fun clearExams()

    // ==========================================
    // 5. Notes (Stable courseId or General)
    // ==========================================
    @Query("SELECT * FROM notes ORDER BY updatedAt DESC")
    fun getAllNotes(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes ORDER BY updatedAt DESC")
    suspend fun getAllNotesSync(): List<NoteEntity>

    @Query("SELECT * FROM notes WHERE courseId = :courseId ORDER BY updatedAt DESC")
    fun getNotesByCourseId(courseId: String): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE courseId IS NULL OR courseId = '' ORDER BY updatedAt DESC")
    fun getGeneralNotes(): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteNote(id: String)

    // ==========================================
    // 6. Attendance (Stable courseId Primary Key)
    // ==========================================
    @Query("SELECT * FROM attendance")
    fun getAllAttendance(): Flow<List<AttendanceEntity>>

    @Query("SELECT * FROM attendance")
    suspend fun getAllAttendanceSync(): List<AttendanceEntity>

    @Query("SELECT * FROM attendance WHERE courseId = :courseId LIMIT 1")
    suspend fun getAttendanceByCourseId(courseId: String): AttendanceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendance(attendance: AttendanceEntity)

    @Update
    suspend fun updateAttendance(attendance: AttendanceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllAttendance(items: List<AttendanceEntity>)

    @Query("DELETE FROM attendance WHERE courseId = :courseId")
    suspend fun deleteAttendanceByCourseId(courseId: String)

    @Query("DELETE FROM attendance WHERE courseName = :courseName OR courseId = :courseId")
    suspend fun deleteAttendanceForCourse(courseName: String, courseId: String = "")

    @Query("DELETE FROM attendance")
    suspend fun clearAttendance()

    // ==========================================
    // 7. Grades (Stable courseId Foreign Key)
    // ==========================================
    @Query("SELECT * FROM grades ORDER BY id ASC")
    fun getAllGrades(): Flow<List<GradeEntity>>

    @Query("SELECT * FROM grades ORDER BY id ASC")
    suspend fun getAllGradesSync(): List<GradeEntity>

    @Query("SELECT * FROM grades WHERE courseId = :courseId LIMIT 1")
    suspend fun getGradeByCourseId(courseId: String): GradeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGrade(grade: GradeEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllGrades(grades: List<GradeEntity>)

    @Update
    suspend fun updateGrade(grade: GradeEntity)

    @Query("DELETE FROM grades WHERE courseId = :courseId")
    suspend fun deleteGradeByCourseId(courseId: String)

    @Query("DELETE FROM grades WHERE courseName = :courseName OR courseId = :courseId")
    suspend fun deleteGradeForCourse(courseName: String, courseId: String = "")

    @Query("DELETE FROM grades")
    suspend fun clearGrades()

    // ==========================================
    // 8. Tasks (Stable courseId and semesterId)
    // ==========================================
    @Query("SELECT * FROM tasks ORDER BY isCompleted ASC, id DESC")
    fun getAllTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks ORDER BY isCompleted ASC, id DESC")
    suspend fun getAllTasksSync(): List<TaskEntity>

    @Query("SELECT * FROM tasks WHERE courseId = :courseId ORDER BY isCompleted ASC, id DESC")
    fun getTasksByCourseId(courseId: String): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE semesterId = :semesterId ORDER BY isCompleted ASC, id DESC")
    fun getTasksBySemester(semesterId: String): Flow<List<TaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllTasks(tasks: List<TaskEntity>)

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Delete
    suspend fun deleteTask(task: TaskEntity)

    @Query("DELETE FROM tasks WHERE courseId = :courseId")
    suspend fun deleteTasksByCourseId(courseId: String)

    @Query("DELETE FROM tasks WHERE courseId = :courseId OR courseName = :courseName")
    suspend fun deleteTasksForCourse(courseId: String, courseName: String = "")

    @Query("DELETE FROM tasks")
    suspend fun clearTasks()

    // ==========================================
    // 9. Profile (Student Information)
    // ==========================================
    @Query("SELECT * FROM student_profile WHERE id = 1 LIMIT 1")
    fun getProfile(): Flow<StudentProfileEntity?>

    @Query("SELECT * FROM student_profile WHERE id = 1 LIMIT 1")
    suspend fun getProfileSync(): StudentProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: StudentProfileEntity)

    // ==========================================
    // 10. Student Course Attempts (Transcript History)
    // ==========================================
    @Query("SELECT * FROM student_course_attempts WHERE profileId = :profileId ORDER BY semesterIndex ASC, attemptNumber ASC")
    fun getStudentAttempts(profileId: Int = 1): Flow<List<StudentCourseAttemptEntity>>

    @Query("SELECT * FROM student_course_attempts WHERE profileId = :profileId ORDER BY semesterIndex ASC, attemptNumber ASC")
    suspend fun getStudentAttemptsSync(profileId: Int = 1): List<StudentCourseAttemptEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudentAttempt(attempt: StudentCourseAttemptEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllStudentAttempts(attempts: List<StudentCourseAttemptEntity>)

    @Query("DELETE FROM student_course_attempts WHERE id = :attemptId")
    suspend fun deleteStudentAttempt(attemptId: String)

    @Query("DELETE FROM student_course_attempts WHERE profileId = :profileId")
    suspend fun clearStudentAttempts(profileId: Int = 1)

    // ==========================================
    // 11. Orphan Cleanup
    // ==========================================
    @Query("DELETE FROM attendance WHERE courseId != '' AND courseId NOT IN (SELECT id FROM courses)")
    suspend fun deleteOrphanAttendance()

    @Query("DELETE FROM grades WHERE courseId != '' AND courseId NOT IN (SELECT id FROM courses)")
    suspend fun deleteOrphanGrades()

    @Query("DELETE FROM tasks WHERE courseId IS NOT NULL AND courseId != '' AND courseId NOT IN (SELECT id FROM courses)")
    suspend fun deleteOrphanTasks()

    @Query("DELETE FROM exams WHERE courseId NOT IN (SELECT id FROM courses)")
    suspend fun deleteOrphanExams()

    @Transaction
    suspend fun cleanupOrphans() {
        deleteOrphanAttendance()
        deleteOrphanGrades()
        deleteOrphanTasks()
        deleteOrphanExams()
    }
}
