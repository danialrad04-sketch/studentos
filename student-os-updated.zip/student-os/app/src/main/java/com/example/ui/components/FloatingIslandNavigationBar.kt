package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.models.AppTab
import com.example.ui.theme.BrandIndigo600
import com.example.ui.theme.Slate500

/**
 * 2026 Redesigned Floating Island Navigation Bar with Squircle Emoji Pack
 * Features:
 * - Fluid spring bounce physics
 * - Rich squircle emoji icons from the custom emoji pack
 * - Active tab indicator glow with adaptive light/dark glassmorphism
 * - Instant access to all secondary hubs via "بیشتر" modal sheet
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FloatingIslandNavigationBar(
    selectedTab: AppTab,
    onTabSelected: (AppTab) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAllModulesSheet by remember { mutableStateOf(false) }

    // 5 Primary Tabs as specified by 2026 Student OS Design System
    val primaryTabs = listOf(
        Triple(AppTab.DASHBOARD, AppEmojiType.HOME, "داشبورد"),
        Triple(AppTab.SCHEDULE, AppEmojiType.CALENDAR, "برنامه"),
        Triple(AppTab.GRADES, AppEmojiType.CHART, "کارنامه"),
        Triple(AppTab.ATTENDANCE, AppEmojiType.TARGET, "حضور"),
        Triple(AppTab.COPILOT, AppEmojiType.COPILOT, "کوپایلت")
    )

    val isDark = MaterialTheme.colorScheme.background.red < 0.2f
    val isOtherTab = primaryTabs.none { it.first == selectedTab }

    val dockBackground = if (isDark) Color(0xCC121829) else Color(0xF5FFFFFF)
    val dockBorderBrush = if (isDark) {
        Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.24f), Color.White.copy(alpha = 0.04f))
        )
    } else {
        Brush.linearGradient(
            listOf(Color(0xFFCBD5E1).copy(alpha = 0.85f), Color(0xFFE2E8F0).copy(alpha = 0.45f))
        )
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(32.dp),
            color = dockBackground,
            shadowElevation = if (isDark) 16.dp else 8.dp,
            border = androidx.compose.foundation.BorderStroke(
                width = 1.dp,
                brush = dockBorderBrush
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                primaryTabs.forEach { (tab, emojiType, label) ->
                    val isSelected = selectedTab == tab

                    val tabScale by animateFloatAsState(
                        targetValue = if (isSelected) 1.08f else 1f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessLow
                        ),
                        label = "tab_spring_$label"
                    )

                    val activeContainerColor = if (isDark) Color(0xFF06B6D4).copy(alpha = 0.16f) else Color(0xFF4F46E5).copy(alpha = 0.12f)
                    val activeBorderColor = if (isDark) Color(0xFF06B6D4).copy(alpha = 0.5f) else Color(0xFF4F46E5).copy(alpha = 0.4f)
                    val activeTextColor = if (isDark) Color(0xFF38BDF8) else Color(0xFF4F46E5)
                    val inactiveTextColor = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
                    val activeDotColor = if (isDark) Color(0xFF06B6D4) else Color(0xFF4F46E5)

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .scale(tabScale)
                            .clip(RoundedCornerShape(20.dp))
                            .then(
                                if (isSelected) {
                                    Modifier
                                        .background(activeContainerColor)
                                        .border(
                                            1.dp,
                                            activeBorderColor,
                                            RoundedCornerShape(20.dp)
                                        )
                                } else Modifier
                            )
                            .tactileClickable { onTabSelected(tab) }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            AppEmoji(
                                type = emojiType,
                                size = if (isSelected) 30.dp else 26.dp,
                                shapeRadiusRatio = 0.30f,
                                elevation = if (isSelected) 4.dp else 0.dp
                            )

                            Spacer(modifier = Modifier.height(3.dp))

                            Text(
                                text = label,
                                fontSize = if (isSelected) 10.sp else 9.sp,
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                                color = if (isSelected) activeTextColor else inactiveTextColor
                            )

                            if (isSelected) {
                                Spacer(modifier = Modifier.height(2.dp))
                                Box(
                                    modifier = Modifier
                                        .width(14.dp)
                                        .height(3.dp)
                                        .clip(CircleShape)
                                        .background(activeDotColor)
                                )
                            }
                        }
                    }
                }
            }
        }
    }


    if (showAllModulesSheet) {
        AllModulesModalSheet(
            currentTab = selectedTab,
            onSelectTab = { tab ->
                showAllModulesSheet = false
                onTabSelected(tab)
            },
            onDismiss = { showAllModulesSheet = false }
        )
    }
}

/**
 * All Modules & Academic Hubs Bottom Sheet with New Emoji Pack
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AllModulesModalSheet(
    currentTab: AppTab,
    onSelectTab: (AppTab) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 36.dp, topEnd = 36.dp),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 12.dp)
                    .width(48.dp)
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .padding(bottom = 32.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "همه بخش‌ها و ماژول‌های تحصیلی",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "دسترسی سریع به کلیه ابزارهای هوشمند Student OS",
                        fontSize = 11.5.sp,
                        color = Slate500
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = BrandIndigo600.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "۱۰ بخش فعال",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandIndigo600,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            val hubModules = listOf(
                HubItem(AppTab.DASHBOARD, AppEmojiType.HOME, "داشبورد مرکزی", "نمای بنتو و خلاصه آمار"),
                HubItem(AppTab.COPILOT, AppEmojiType.COPILOT, "دستیار Copilot", "مشاور تحصیلی و هوش مصنوعی"),
                HubItem(AppTab.SCHEDULE, AppEmojiType.CALENDAR, "برنامه هفتگی", "تقویم کلاس‌ها و تداخل‌ها"),
                HubItem(AppTab.ATTENDANCE, AppEmojiType.TARGET, "رادار حضور و غیاب", "مانیتور قانون ۳/۱۶ غیبت"),
                HubItem(AppTab.TASKS, AppEmojiType.CHECK, "مدیریت تکالیف", "اسپرینت و پروژه‌های درسی"),
                HubItem(AppTab.EXAMS, AppEmojiType.BELL, "امتحانات و موعدها", "شمارش معکوس و یادآورها"),
                HubItem(AppTab.GRADES, AppEmojiType.CHART, "کارنامه و معدل", "محاسبه معدل الف و شبیه‌ساز"),
                HubItem(AppTab.POMODORO, AppEmojiType.POMODORO, "تمرکز پومودورو", "تایمر مطالعه و یادداشت"),
                HubItem(AppTab.CURRICULUM, AppEmojiType.BOOK, "چارت دروس مصوب", "پیش‌نیازها و ترم‌بندی"),
                HubItem(AppTab.PASSPORT, AppEmojiType.GRAD_CAP, "پاسپورت تحصیلی", "گواهی پیشرفت آکادمیک"),
                HubItem(AppTab.GAMIFICATION, AppEmojiType.TROPHY, "تالار افتخارات", "استریک و مدال‌های آکادمیک")
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(hubModules) { item ->
                    val isSelected = currentTab == item.tab
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .tactileClickable { onSelectTab(item.tab) },
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isSelected) 1.5.dp else 0.8.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppEmoji(
                                type = item.emojiType,
                                size = 38.dp,
                                shapeRadiusRatio = 0.28f,
                                elevation = 2.dp
                            )

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = item.subtitle,
                                    fontSize = 9.5.sp,
                                    color = Slate500,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class HubItem(
    val tab: AppTab,
    val emojiType: AppEmojiType,
    val title: String,
    val subtitle: String
)
