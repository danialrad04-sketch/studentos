package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import com.example.data.local.util.DateTimeNormalizer
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.NumericBadgeText
import com.example.ui.theme.NumericDisplayStat
import com.example.ui.theme.StudentOsColors
import com.example.ui.theme.StudentOsGlassTokens
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.CourseEntity
import com.example.ui.theme.studentColors

private val WEEKDAY_NAMES = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه")

@Composable
fun WeeklyScheduleScreen(
    courses: List<CourseEntity>,
    onAddCourse: () -> Unit,
    onEditCourse: (CourseEntity) -> Unit,
    onOpenCourseWorkspace: ((CourseEntity) -> Unit)? = null,
    onDeleteCourse: ((String) -> Unit)? = null,
    onOpenZeroSetup: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedDayTab by remember { mutableIntStateOf(0) }
    var isFullWeekView by remember { mutableStateOf(false) }

    val totalUnits = remember(courses) { courses.sumOf { it.units } }

    Column(modifier = modifier.fillMaxWidth()) {
        if (courses.isEmpty()) {
            ActionableEmptyState(
                title = "برنامه هفتگی ترم جاری هنوز خالی است",
                description = "می‌توانید دروس را دستی اضافه کنید، یا با Zero-Setup در چند ثانیه چارت و برنامه را استقرار دهید.",
                icon = Icons.Default.Schedule,
                primaryActionTitle = "افزودن درس دستی (حذف و اضافه)",
                onPrimaryAction = onAddCourse,
                secondaryActionTitle = "⚡ راه‌اندازی سریع با Zero-Setup",
                onSecondaryAction = onOpenZeroSetup
            )
            return@Column
        }

        // Modern Pro Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = CardDefaults.outlinedCardBorder().copy(width = 0.9.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f, fill = false)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "برنامه هفتگی و انتخاب واحد",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.primaryContainer,
                                border = androidx.compose.foundation.BorderStroke(0.8.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                            ) {
                                Text(
                                    text = "$totalUnits واحد اخذ شده",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "مرتب‌سازی هوشمند به وقت شروع · مدیریت تداخل و حذف/اضافه",
                            fontSize = 10.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        IconButton(
                            onClick = { isFullWeekView = !isFullWeekView },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (isFullWeekView) Icons.Default.ViewAgenda else Icons.Default.GridView,
                                contentDescription = "تغییر نما",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Button(
                            onClick = onAddCourse,
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "درس جدید", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Day Selector Bento Capsules
        if (!isFullWeekView) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                WEEKDAY_NAMES.forEachIndexed { index, dayName ->
                    val isSelected = selectedDayTab == index
                    val dayCoursesCount = courses.count { it.day == index }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (isSelected) StudentOsColors.CyanAccent.copy(alpha = 0.18f)
                                else StudentOsGlassTokens.glassElevated
                            )
                            .border(
                                1.dp,
                                if (isSelected) StudentOsGlassTokens.borderCyanGradient
                                else StudentOsGlassTokens.borderGradient,
                                RoundedCornerShape(16.dp)
                            )
                            .clickable { selectedDayTab = index }
                            .padding(horizontal = 14.dp, vertical = 9.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(StudentOsColors.CyanAccent)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Text(
                                text = dayName,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.SemiBold,
                                color = if (isSelected) StudentOsColors.CyanAccent else MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "($dayCoursesCount)",
                                style = NumericBadgeText,
                                fontSize = 10.sp,
                                color = if (isSelected) StudentOsColors.CyanAccent else Color.Gray
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 2026 Live Time Indicator (تایم‌لاین زنده لحظه‌ای)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF06B6D4).copy(alpha = 0.08f))
                    .border(0.8.dp, Color(0xFF06B6D4).copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(StudentOsColors.CyanAccent)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تایم‌لاین زنده دانشگاه · روز فعال: ${WEEKDAY_NAMES.getOrNull(selectedDayTab) ?: ""}",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = StudentOsColors.CyanAccent
                        )
                    }

                    Text(
                        text = "زنده 🟢",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = StudentOsColors.CyanAccent
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Day Agenda List - Sorted strictly by start time (earliest hour first)
            val dayCourses = courses
                .filter { it.day == selectedDayTab }
                .sortedWith(compareBy({ DateTimeNormalizer.timeToMinutes(it.start) }, { it.name }))

            if (dayCourses.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "☕", fontSize = 28.sp)
                        Text(
                            text = "در این روز کلاسی ثبت نشده است.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        )
                        OutlinedButton(
                            onClick = onAddCourse,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("افزودن کلاس برای این روز", fontSize = 11.sp)
                        }
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    dayCourses.forEach { course ->
                        CourseCard(
                            course = course,
                            onClick = { onOpenCourseWorkspace?.invoke(course) ?: onEditCourse(course) },
                            onEdit = { onEditCourse(course) },
                            onDelete = onDeleteCourse?.let { { it(course.id) } },
                            onOpenWorkspace = onOpenCourseWorkspace?.let { { it(course) } }
                        )
                    }
                }
            }
        } else {
            // Full Week Agenda View - Sorted by start time for every single day
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                WEEKDAY_NAMES.forEachIndexed { dayIdx, dayName ->
                    val dayCourses = courses
                        .filter { it.day == dayIdx }
                        .sortedWith(compareBy({ DateTimeNormalizer.timeToMinutes(it.start) }, { it.name }))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .width(4.dp)
                                            .height(14.dp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(MaterialTheme.colorScheme.primary)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = dayName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Text(
                                    text = "${dayCourses.size} کلاس",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            if (dayCourses.isEmpty()) {
                                Text(
                                    text = "بدون کلاس در این روز",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    dayCourses.forEach { course ->
                                        CourseCard(
                                            course = course,
                                            onClick = { onOpenCourseWorkspace?.invoke(course) ?: onEditCourse(course) },
                                            onEdit = { onEditCourse(course) },
                                            onDelete = onDeleteCourse?.let { { it(course.id) } },
                                            onOpenWorkspace = onOpenCourseWorkspace?.let { { it(course) } }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CourseCard(
    course: CourseEntity,
    onClick: () -> Unit,
    onEdit: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null,
    onOpenWorkspace: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val defaultPrimary = MaterialTheme.colorScheme.primary
    val accentColor = remember(course.colorHex, defaultPrimary) {
        try {
            Color(android.graphics.Color.parseColor(course.colorHex))
        } catch (_: Exception) {
            defaultPrimary
        }
    }

    var showMenu by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .tactileClickable { onClick() },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = StudentOsGlassTokens.glassElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudentOsGlassTokens.borderGradient)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Colored accent line with rounded capsule
                Box(
                    modifier = Modifier
                        .width(4.5.dp)
                        .height(48.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(accentColor)
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = course.name,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Notion-Style Property Pill
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = accentColor.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(0.7.dp, accentColor.copy(alpha = 0.35f))
                        ) {
                            Text(
                                text = "${course.units} واحد",
                                style = NumericBadgeText,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = accentColor,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        // Professor or Location badge
                        if (course.professor.isNotBlank()) {
                            Text(
                                text = "👨‍🏫 ${course.professor}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        } else {
                            Text(
                                text = "📍 ${course.location}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Time slot capsule with Plus Jakarta Sans
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = StudentOsColors.CyanAccent.copy(alpha = 0.12f),
                    border = androidx.compose.foundation.BorderStroke(0.8.dp, StudentOsColors.CyanAccent.copy(alpha = 0.35f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = null,
                            tint = StudentOsColors.CyanAccent,
                            modifier = Modifier.padding(end = 4.dp).size(13.dp)
                        )
                        Text(
                            text = "${course.start} - ${course.end}",
                            style = NumericDisplayStat,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = StudentOsColors.CyanAccent
                        )
                    }
                }

                // Quick Action Context Menu (Edit / Delete / Open Workspace)
                if (onEdit != null || onDelete != null || onOpenWorkspace != null) {
                    Box {
                        IconButton(
                            onClick = { showMenu = true },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "عملیات درس",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            if (onOpenWorkspace != null) {
                                DropdownMenuItem(
                                    text = { Text("کارپوشه تخصصی ۳۶۰°", fontSize = 11.5.sp) },
                                    onClick = {
                                        showMenu = false
                                        onOpenWorkspace()
                                    },
                                    leadingIcon = {
                                        Icon(Icons.Default.OpenInFull, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                    }
                                )
                            }
                            if (onEdit != null) {
                                DropdownMenuItem(
                                    text = { Text("ویرایش درس (ساعت، مکان، رنگ)", fontSize = 11.5.sp) },
                                    onClick = {
                                        showMenu = false
                                        onEdit()
                                    },
                                    leadingIcon = {
                                        Icon(Icons.Default.Edit, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                                    }
                                )
                            }
                            if (onDelete != null) {
                                DropdownMenuItem(
                                    text = { Text("حذف و اضافه (حذف درس)", fontSize = 11.5.sp, color = MaterialTheme.studentColors.attendanceCritical) },
                                    onClick = {
                                        showMenu = false
                                        showDeleteConfirm = true
                                    },
                                    leadingIcon = {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = MaterialTheme.studentColors.attendanceCritical, modifier = Modifier.size(16.dp))
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDeleteConfirm && onDelete != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.WarningAmber,
                    contentDescription = null,
                    tint = MaterialTheme.studentColors.attendanceCritical,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "حذف درس از برنامه هفتگی",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black
                )
            },
            text = {
                Text(
                    text = "آیا می‌خواهید درس «${course.name}» را از برنامه ترم جاری حذف کنید؟",
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.studentColors.attendanceCritical),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("حذف درس", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("انصراف", fontSize = 11.sp)
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }
}
