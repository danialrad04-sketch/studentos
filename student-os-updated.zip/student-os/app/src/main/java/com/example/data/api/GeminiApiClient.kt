package com.example.data.api

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.FirebaseAI
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Production-Grade Academic Copilot client powered by Firebase AI Logic.
 * 
 * Security Architecture:
 * - ZERO client-side API keys in BuildConfig, SharedPreferences, or bytecode.
 * - Enterprise security enforced via Firebase App Check & Backend Authentication.
 * - Targeted model: 'gemini-2.5-flash'.
 */
object GeminiApiClient {

    private const val TAG = "GeminiApiClient"
    private const val MODEL_NAME = "gemini-2.5-flash"

    private val generativeModel: GenerativeModel? by lazy {
        try {
            Firebase.ai.generativeModel(
                modelName = MODEL_NAME
            )
        } catch (e: Throwable) {
            Log.w(TAG, "Firebase AI Logic initialization state: ${e.message}")
            null
        }
    }

    suspend fun generateAcademicAdvice(
        prompt: String,
        studentContext: String,
        customApiKey: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val model = generativeModel
        if (model == null) {
            return@withContext Result.failure(
                IllegalStateException("سرویس Firebase AI آماده‌سازی نشده است. سوئیچ به موتور تحلیلی محلی.")
            )
        }

        try {
            val fullPrompt = buildString {
                append("شما دستیار هوشمند و مشاور تحصیلی تخصصی دانشگاهی (Student OS AI Copilot) هستید.\n")
                append("پاسخ‌های شما باید کاملاً به زبان فارسی، ساختاریافته، دقیق و منطبق بر قوانین دانشگاهی ایران باشد.\n\n")
                append("سوابق و بافت آموزشی دانشجو:\n")
                append(studentContext)
                append("\n\nپرسش دانشجو:\n")
                append(prompt)
            }

            val response = model.generateContent(fullPrompt)
            val text = response.text

            if (text.isNullOrBlank()) {
                Result.failure(Exception("پاسخ خالی دریافت شد."))
            } else {
                Result.success(text.trim())
            }
        } catch (e: Exception) {
            Log.e(TAG, "Firebase AI generation error: ${e.message}", e)
            Result.failure(e)
        }
    }
}
