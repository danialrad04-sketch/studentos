package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.CurriculumDao
import com.example.data.local.dao.StudentDao
import com.example.data.local.entity.AttendanceEntity
import com.example.data.local.entity.CourseAliasEntity
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.CurriculumCourseEntity
import com.example.data.local.entity.CurriculumVersionEntity
import com.example.data.local.entity.ExamEntity
import com.example.data.local.entity.GradeEntity
import com.example.data.local.entity.MajorEntity
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.ProfessorEntity
import com.example.data.local.entity.SemesterEntity
import com.example.data.local.entity.StudentCourseAttemptEntity
import com.example.data.local.entity.StudentProfileEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.UniversityEntity
import com.example.data.seed.CurriculumSeedData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        SemesterEntity::class,
        CourseEntity::class,
        AttendanceEntity::class,
        GradeEntity::class,
        TaskEntity::class,
        StudentProfileEntity::class,
        CurriculumCourseEntity::class,
        UniversityEntity::class,
        MajorEntity::class,
        CurriculumVersionEntity::class,
        CourseAliasEntity::class,
        StudentCourseAttemptEntity::class,
        ProfessorEntity::class,
        ExamEntity::class,
        NoteEntity::class
    ],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun studentDao(): StudentDao
    abstract fun curriculumDao(): CurriculumDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `curriculum_courses` (
                        `id` TEXT NOT NULL PRIMARY KEY,
                        `majorId` TEXT NOT NULL,
                        `name` TEXT NOT NULL,
                        `nameEn` TEXT NOT NULL,
                        `courseCode` TEXT NOT NULL,
                        `units` INTEGER NOT NULL,
                        `courseType` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `prerequisites` TEXT NOT NULL,
                        `coRequisites` TEXT NOT NULL,
                        `recommendedSemester` INTEGER NOT NULL,
                        `syllabus` TEXT NOT NULL,
                        `description` TEXT NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `reference_universities` (
                        `id` TEXT NOT NULL PRIMARY KEY,
                        `displayNameFa` TEXT NOT NULL,
                        `shortName` TEXT NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `reference_majors` (
                        `id` TEXT NOT NULL PRIMARY KEY,
                        `universityId` TEXT NOT NULL,
                        `facultyId` TEXT NOT NULL,
                        `facultyDisplayNameFa` TEXT NOT NULL,
                        `majorDisplayNameFa` TEXT NOT NULL,
                        FOREIGN KEY(`universityId`) REFERENCES `reference_universities`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `curriculum_versions` (
                        `id` TEXT NOT NULL PRIMARY KEY,
                        `majorId` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `entryYearMin` INTEGER NOT NULL,
                        `entryYearMax` INTEGER NOT NULL,
                        `totalCreditsRequired` INTEGER NOT NULL,
                        FOREIGN KEY(`majorId`) REFERENCES `reference_majors`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `course_aliases` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `courseId` TEXT NOT NULL,
                        `aliasRaw` TEXT NOT NULL,
                        `aliasNormalized` TEXT NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `student_course_attempts` (
                        `id` TEXT NOT NULL PRIMARY KEY,
                        `profileId` INTEGER NOT NULL,
                        `courseId` TEXT NOT NULL,
                        `semesterIndex` INTEGER NOT NULL,
                        `attemptNumber` INTEGER NOT NULL,
                        `status` TEXT NOT NULL,
                        `grade` REAL,
                        `isPassed` INTEGER NOT NULL,
                        FOREIGN KEY(`profileId`) REFERENCES `student_profile`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent()
                )

                // Add missing columns to student_profile safely
                val cursor = db.query("PRAGMA table_info(`student_profile`)")
                val existingCols = mutableSetOf<String>()
                while (cursor.moveToNext()) {
                    val nameIdx = cursor.getColumnIndex("name")
                    if (nameIdx != -1) existingCols.add(cursor.getString(nameIdx))
                }
                cursor.close()

                if (!existingCols.contains("universityId")) {
                    db.execSQL("ALTER TABLE `student_profile` ADD COLUMN `universityId` TEXT DEFAULT NULL")
                }
                if (!existingCols.contains("facultyId")) {
                    db.execSQL("ALTER TABLE `student_profile` ADD COLUMN `facultyId` TEXT DEFAULT NULL")
                }
                if (!existingCols.contains("majorId")) {
                    db.execSQL("ALTER TABLE `student_profile` ADD COLUMN `majorId` TEXT DEFAULT NULL")
                }
                if (!existingCols.contains("declaredPassedCredits")) {
                    db.execSQL("ALTER TABLE `student_profile` ADD COLUMN `declaredPassedCredits` INTEGER DEFAULT NULL")
                }
                if (!existingCols.contains("declaredGpa")) {
                    db.execSQL("ALTER TABLE `student_profile` ADD COLUMN `declaredGpa` REAL DEFAULT NULL")
                }
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // 1. Create semesters table
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `semesters` (
                        `id` TEXT NOT NULL PRIMARY KEY,
                        `title` TEXT NOT NULL,
                        `year` INTEGER NOT NULL DEFAULT 1403,
                        `semesterNumber` INTEGER NOT NULL DEFAULT 1,
                        `startDate` TEXT NOT NULL DEFAULT '',
                        `endDate` TEXT NOT NULL DEFAULT '',
                        `isCurrent` INTEGER NOT NULL DEFAULT 0,
                        `isArchived` INTEGER NOT NULL DEFAULT 0,
                        `totalUnits` INTEGER NOT NULL DEFAULT 0,
                        `gpa` REAL DEFAULT NULL
                    )
                    """.trimIndent()
                )

                // 2. Add semesterId and metadata to courses
                val cursorCourses = db.query("PRAGMA table_info(`courses`)")
                val courseCols = mutableSetOf<String>()
                while (cursorCourses.moveToNext()) {
                    val nameIdx = cursorCourses.getColumnIndex("name")
                    if (nameIdx != -1) courseCols.add(cursorCourses.getString(nameIdx))
                }
                cursorCourses.close()

                if (!courseCols.contains("semesterId")) {
                    db.execSQL("ALTER TABLE `courses` ADD COLUMN `semesterId` TEXT NOT NULL DEFAULT 'current'")
                }
                if (!courseCols.contains("courseCode")) {
                    db.execSQL("ALTER TABLE `courses` ADD COLUMN `courseCode` TEXT NOT NULL DEFAULT ''")
                }
                if (!courseCols.contains("professor")) {
                    db.execSQL("ALTER TABLE `courses` ADD COLUMN `professor` TEXT NOT NULL DEFAULT ''")
                }
                if (!courseCols.contains("examDate")) {
                    db.execSQL("ALTER TABLE `courses` ADD COLUMN `examDate` TEXT NOT NULL DEFAULT ''")
                }
                if (!courseCols.contains("examTime")) {
                    db.execSQL("ALTER TABLE `courses` ADD COLUMN `examTime` TEXT NOT NULL DEFAULT ''")
                }
                if (!courseCols.contains("examLocation")) {
                    db.execSQL("ALTER TABLE `courses` ADD COLUMN `examLocation` TEXT NOT NULL DEFAULT ''")
                }
                if (!courseCols.contains("notes")) {
                    db.execSQL("ALTER TABLE `courses` ADD COLUMN `notes` TEXT NOT NULL DEFAULT ''")
                }
                if (!courseCols.contains("isArchived")) {
                    db.execSQL("ALTER TABLE `courses` ADD COLUMN `isArchived` INTEGER NOT NULL DEFAULT 0")
                }
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_courses_semesterId` ON `courses` (`semesterId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_courses_courseCode` ON `courses` (`courseCode`)")

                // 3. Add courseId to attendance, grades, tasks
                val cursorAtt = db.query("PRAGMA table_info(`attendance`)")
                val attCols = mutableSetOf<String>()
                while (cursorAtt.moveToNext()) {
                    val nameIdx = cursorAtt.getColumnIndex("name")
                    if (nameIdx != -1) attCols.add(cursorAtt.getString(nameIdx))
                }
                cursorAtt.close()
                if (!attCols.contains("courseId")) {
                    db.execSQL("ALTER TABLE `attendance` ADD COLUMN `courseId` TEXT NOT NULL DEFAULT ''")
                }
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_attendance_courseId` ON `attendance` (`courseId`)")

                val cursorGrades = db.query("PRAGMA table_info(`grades`)")
                val gradeCols = mutableSetOf<String>()
                while (cursorGrades.moveToNext()) {
                    val nameIdx = cursorGrades.getColumnIndex("name")
                    if (nameIdx != -1) gradeCols.add(cursorGrades.getString(nameIdx))
                }
                cursorGrades.close()
                if (!gradeCols.contains("courseId")) {
                    db.execSQL("ALTER TABLE `grades` ADD COLUMN `courseId` TEXT NOT NULL DEFAULT ''")
                }
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_grades_courseId` ON `grades` (`courseId`)")

                val cursorTasks = db.query("PRAGMA table_info(`tasks`)")
                val taskCols = mutableSetOf<String>()
                while (cursorTasks.moveToNext()) {
                    val nameIdx = cursorTasks.getColumnIndex("name")
                    if (nameIdx != -1) taskCols.add(cursorTasks.getString(nameIdx))
                }
                cursorTasks.close()
                if (!taskCols.contains("courseId")) {
                    db.execSQL("ALTER TABLE `tasks` ADD COLUMN `courseId` TEXT NOT NULL DEFAULT ''")
                }
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_tasks_courseId` ON `tasks` (`courseId`)")

                // 4. Populate default current semester if none exists
                db.execSQL("""
                    INSERT OR IGNORE INTO `semesters` (`id`, `title`, `year`, `semesterNumber`, `isCurrent`, `isArchived`, `totalUnits`)
                    VALUES ('current', 'ترم جاری', 1403, 1, 1, 0, 0)
                """.trimIndent())
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // 1. Upgrade semesters table with academicYear, termNumber, status, createdAt, updatedAt
                val cursorSem = db.query("PRAGMA table_info(`semesters`)")
                val semCols = mutableSetOf<String>()
                while (cursorSem.moveToNext()) {
                    val nameIdx = cursorSem.getColumnIndex("name")
                    if (nameIdx != -1) semCols.add(cursorSem.getString(nameIdx))
                }
                cursorSem.close()

                if (!semCols.contains("academicYear")) {
                    db.execSQL("ALTER TABLE `semesters` ADD COLUMN `academicYear` INTEGER NOT NULL DEFAULT 1403")
                    db.execSQL("UPDATE `semesters` SET `academicYear` = `year`")
                }
                if (!semCols.contains("termNumber")) {
                    db.execSQL("ALTER TABLE `semesters` ADD COLUMN `termNumber` INTEGER NOT NULL DEFAULT 1")
                    db.execSQL("UPDATE `semesters` SET `termNumber` = `semesterNumber`")
                }
                if (!semCols.contains("status")) {
                    db.execSQL("ALTER TABLE `semesters` ADD COLUMN `status` TEXT NOT NULL DEFAULT 'ACTIVE'")
                    db.execSQL("UPDATE `semesters` SET `status` = CASE WHEN `isArchived` = 1 THEN 'ARCHIVED' ELSE 'ACTIVE' END")
                }
                if (!semCols.contains("createdAt")) {
                    db.execSQL("ALTER TABLE `semesters` ADD COLUMN `createdAt` INTEGER NOT NULL DEFAULT 0")
                }
                if (!semCols.contains("updatedAt")) {
                    db.execSQL("ALTER TABLE `semesters` ADD COLUMN `updatedAt` INTEGER NOT NULL DEFAULT 0")
                }
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_semesters_isCurrent` ON `semesters` (`isCurrent`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_semesters_academicYear_termNumber` ON `semesters` (`academicYear`, `termNumber`)")

                // 2. Add professorId to courses
                val cursorCourses = db.query("PRAGMA table_info(`courses`)")
                val courseCols = mutableSetOf<String>()
                while (cursorCourses.moveToNext()) {
                    val nameIdx = cursorCourses.getColumnIndex("name")
                    if (nameIdx != -1) courseCols.add(cursorCourses.getString(nameIdx))
                }
                cursorCourses.close()

                if (!courseCols.contains("professorId")) {
                    db.execSQL("ALTER TABLE `courses` ADD COLUMN `professorId` TEXT DEFAULT NULL")
                }
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_courses_professorId` ON `courses` (`professorId`)")

                // 3. Create professors table
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `professors` (
                        `id` TEXT NOT NULL PRIMARY KEY,
                        `name` TEXT NOT NULL,
                        `email` TEXT NOT NULL DEFAULT '',
                        `office` TEXT NOT NULL DEFAULT '',
                        `department` TEXT NOT NULL DEFAULT '',
                        `notes` TEXT NOT NULL DEFAULT ''
                    )
                """.trimIndent())

                // 4. Create exams table
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `exams` (
                        `id` TEXT NOT NULL PRIMARY KEY,
                        `courseId` TEXT NOT NULL,
                        `courseName` TEXT NOT NULL DEFAULT '',
                        `date` TEXT NOT NULL DEFAULT '',
                        `time` TEXT NOT NULL DEFAULT '',
                        `location` TEXT NOT NULL DEFAULT '',
                        `notes` TEXT NOT NULL DEFAULT '',
                        FOREIGN KEY(`courseId`) REFERENCES `courses`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_exams_courseId` ON `exams` (`courseId`)")

                // Populate exams from existing courses with exam info
                db.execSQL("""
                    INSERT OR IGNORE INTO `exams` (`id`, `courseId`, `courseName`, `date`, `time`, `location`)
                    SELECT 'exam_' || id, id, name, examDate, examTime, examLocation
                    FROM `courses`
                    WHERE examDate != '' OR examTime != ''
                """.trimIndent())

                // 5. Create notes table
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `notes` (
                        `id` TEXT NOT NULL PRIMARY KEY,
                        `courseId` TEXT DEFAULT NULL,
                        `title` TEXT NOT NULL DEFAULT '',
                        `content` TEXT NOT NULL DEFAULT '',
                        `updatedAt` INTEGER NOT NULL DEFAULT 0
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_notes_courseId` ON `notes` (`courseId`)")

                // 6. Migrate attendance table to have courseId as primary key
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `attendance_new` (
                        `courseId` TEXT NOT NULL PRIMARY KEY,
                        `courseName` TEXT NOT NULL DEFAULT '',
                        `absentCount` INTEGER NOT NULL DEFAULT 0,
                        `maxAllowed` INTEGER NOT NULL DEFAULT 3,
                        FOREIGN KEY(`courseId`) REFERENCES `courses`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                """.trimIndent())

                db.execSQL("""
                    INSERT OR REPLACE INTO `attendance_new` (`courseId`, `courseName`, `absentCount`, `maxAllowed`)
                    SELECT 
                        CASE 
                            WHEN a.courseId != '' THEN a.courseId 
                            WHEN c.id IS NOT NULL THEN c.id 
                            ELSE 'att_' || abs(random()) 
                        END,
                        a.courseName,
                        a.absentCount,
                        a.maxAllowed
                    FROM `attendance` a
                    LEFT JOIN `courses` c ON a.courseName = c.name
                """.trimIndent())

                db.execSQL("DROP TABLE `attendance`")
                db.execSQL("ALTER TABLE `attendance_new` RENAME TO `attendance`")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_attendance_courseId` ON `attendance` (`courseId`)")

                // 7. Add semesterId to tasks if missing
                val cursorTasks = db.query("PRAGMA table_info(`tasks`)")
                val taskCols = mutableSetOf<String>()
                while (cursorTasks.moveToNext()) {
                    val nameIdx = cursorTasks.getColumnIndex("name")
                    if (nameIdx != -1) taskCols.add(cursorTasks.getString(nameIdx))
                }
                cursorTasks.close()

                if (!taskCols.contains("semesterId")) {
                    db.execSQL("ALTER TABLE `tasks` ADD COLUMN `semesterId` TEXT DEFAULT NULL")
                }
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_tasks_semesterId` ON `tasks` (`semesterId`)")
            }
        }

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "student_os_db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
                    .addCallback(DatabaseCallback(scope))
                    .enableMultiInstanceInvalidation()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.studentDao(), database.curriculumDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: StudentDao, curriculumDao: CurriculumDao? = null) {
            // 1. Seed Reference Data first (Strict foreign key hierarchy: University -> Major -> CurriculumVersion)
            curriculumDao?.let { cDao ->
                val universities = listOf(
                    UniversityEntity(
                        id = "UNI_AUT",
                        displayNameFa = "دانشگاه صنعتی امیرکبیر",
                        shortName = "پلی‌تکنیک تهران"
                    ),
                    UniversityEntity(
                        id = "UNI_UT",
                        displayNameFa = "دانشگاه تهران",
                        shortName = "دانشگاه تهران"
                    ),
                    UniversityEntity(
                        id = "UNI_SUT",
                        displayNameFa = "دانشگاه صنعتی شریف",
                        shortName = "شریف"
                    )
                )
                cDao.insertUniversities(universities)

                val majors = listOf(
                    MajorEntity(
                        id = "MAJ_AUT_CHEM_ENG",
                        universityId = "UNI_AUT",
                        facultyId = "FAC_AUT_CHEM_OIL",
                        facultyDisplayNameFa = "دانشکده مهندسی شیمی و نفت",
                        majorDisplayNameFa = "مهندسی شیمی"
                    ),
                    MajorEntity(
                        id = "MAJ_AUT_COMP_ENG",
                        universityId = "UNI_AUT",
                        facultyId = "FAC_AUT_COMP",
                        facultyDisplayNameFa = "دانشکده مهندسی کامپیوتر",
                        majorDisplayNameFa = "مهندسی کامپیوتر"
                    )
                )
                cDao.insertMajors(majors)

                val versions = listOf(
                    CurriculumVersionEntity(
                        id = "CURR_AUT_CE_1401",
                        majorId = "MAJ_AUT_CHEM_ENG",
                        title = "چارت مهندسی شیمی امیرکبیر ورودی‌های ۱۴۰۱ به بعد",
                        entryYearMin = 1401,
                        entryYearMax = 1405,
                        totalCreditsRequired = 140
                    )
                )
                cDao.insertCurriculumVersions(versions)

                // Populate accredited curriculum courses
                cDao.insertCurriculumCourses(CurriculumSeedData.chemicalEngineeringCourses)

                // Aliases for accurate matching
                val aliases = listOf(
                    CourseAliasEntity(courseId = "CE_THERMO_1", aliasRaw = "ترمو ۱", aliasNormalized = "ترمو 1"),
                    CourseAliasEntity(courseId = "CE_THERMO_1", aliasRaw = "ترمودینامیک ۱", aliasNormalized = "ترمودینامیک 1"),
                    CourseAliasEntity(courseId = "CE_FLUID_1", aliasRaw = "سیالات ۱", aliasNormalized = "سیالات 1"),
                    CourseAliasEntity(courseId = "CE_HEAT_1", aliasRaw = "حرارت ۱", aliasNormalized = "حرارت 1"),
                    CourseAliasEntity(courseId = "CE_MATH_1", aliasRaw = "ریاضی ۱", aliasNormalized = "ریاضی 1"),
                    CourseAliasEntity(courseId = "CE_MATH_2", aliasRaw = "ریاضی ۲", aliasNormalized = "ریاضی 2")
                )
                cDao.insertAliases(aliases)
            }

            // 2. Clean Zero Setup Initial Profile (Zero personal/demo developer data)
            // Only seed initial blank profile if NO profile currently exists in the database
            val existingProfile = dao.getProfileSync()
            if (existingProfile == null) {
                dao.insertProfile(
                    StudentProfileEntity(
                        id = 1,
                        name = "دانشجو",
                        studentId = "",
                        faculty = "دانشکده مهندسی",
                        term = "ترم ۱",
                        activeUnits = 0,
                        passedUnits = 0,
                        notes = "",
                        isOnboardingCompleted = false,
                        universityId = "UNI_AUT",
                        facultyId = "FAC_AUT_CHEM_OIL",
                        majorId = "MAJ_AUT_CHEM_ENG",
                        declaredPassedCredits = 0,
                        declaredGpa = null
                    )
                )
            }

            // 3. Default clean initial semester (only if no active semester exists)
            val existingSemesters = dao.getAllSemestersSync()
            if (existingSemesters.isEmpty()) {
                dao.insertSemester(
                    SemesterEntity(
                        id = "sem_1",
                        title = "ترم ۱ (پاییز ۱۴۰۳)",
                        year = 1403,
                        academicYear = 1403,
                        semesterNumber = 1,
                        termNumber = 1,
                        isCurrent = true,
                        isArchived = false,
                        totalUnits = 0,
                        status = "ACTIVE"
                    )
                )
            }
        }
    }
}
