package com.example.ui.components

import android.content.Context
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.AttendanceEntity
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.CurriculumCourseEntity
import com.example.data.local.entity.GradeEntity
import com.example.data.local.entity.StudentProfileEntity
import com.example.data.local.entity.TaskEntity
import com.example.domain.model.GlobalSearchResult
import com.example.ui.StudentViewModel
import com.example.ui.components.export.ExportSourcePayload
import com.example.ui.components.export.PremiumShareExportModal
import com.example.ui.models.AppTab
import com.example.ui.models.ExamItem
import com.example.ui.models.SystemNotification
import com.example.ui.models.ThemeMode

@Composable
fun AppDialogManager(
    context: Context,
    studentViewModel: StudentViewModel,
    profile: StudentProfileEntity,
    userAccount: com.example.domain.model.UserAccount,
    themeMode: ThemeMode,
    notificationsEnabled: Boolean,
    notifications: List<SystemNotification>,
    courses: List<CourseEntity>,
    attendance: List<AttendanceEntity>,
    grades: List<GradeEntity>,
    tasks: List<TaskEntity>,
    exams: List<ExamItem>,
    curriculumCourses: List<CurriculumCourseEntity>,
    globalSearchResults: List<GlobalSearchResult>,
    searchQuery: String,
    // Dialog visibility states
    showSettingsAndRoadmapDialog: Boolean,
    onDismissSettingsDialog: () -> Unit,
    showProfileDialog: Boolean,
    onDismissProfileDialog: () -> Unit,
    showPastSemestersDialog: Boolean,
    onDismissPastSemestersDialog: () -> Unit,
    showNotifDialog: Boolean,
    onDismissNotifDialog: () -> Unit,
    showApkDialog: Boolean,
    onDismissApkDialog: () -> Unit,
    showAddCourseDialog: Boolean,
    onDismissAddCourseDialog: () -> Unit,
    editingCourse: CourseEntity?,
    onDismissEditingCourse: () -> Unit,
    showAddTaskDialog: Boolean,
    onDismissAddTaskDialog: () -> Unit,
    showCommandCenter: Boolean,
    onDismissCommandCenter: () -> Unit,
    showCopilotDialog: Boolean,
    onDismissCopilotDialog: () -> Unit,
    showOcrImportDialog: Boolean,
    onDismissOcrImportDialog: () -> Unit,
    showAuthDialog: Boolean,
    onDismissAuthDialog: () -> Unit,
    showUpgradeDialog: Boolean,
    onDismissUpgradeDialog: () -> Unit,
    showBackupRestoreDialog: Boolean,
    onDismissBackupRestoreDialog: () -> Unit,
    selectedWorkspaceCourseId: String?,
    onDismissWorkspaceCourse: () -> Unit,
    exportPayload: ExportSourcePayload?,
    onDismissExportPayload: () -> Unit,
    // Triggers
    onOpenProfileDialog: () -> Unit,
    onOpenPastSemestersDialog: () -> Unit,
    onOpenApkDialog: () -> Unit,
    onOpenOnboardingWizard: () -> Unit,
    onOpenAuthDialog: () -> Unit,
    onOpenUpgradeDialog: () -> Unit,
    onOpenBackupRestoreDialog: () -> Unit,
    onSendDeviceTestNotif: () -> Unit,
    onSelectWorkspaceCourseId: (String) -> Unit
) {
    if (showSettingsAndRoadmapDialog) {
        SettingsAndRoadmapDialog(
            profile = profile,
            themeMode = themeMode,
            onSelectThemeMode = { studentViewModel.setThemeMode(it) },
            notificationsEnabled = notificationsEnabled,
            onToggleNotifications = { studentViewModel.setNotificationsEnabled(it) },
            onOpenEditProfile = onOpenProfileDialog,
            onDismiss = onDismissSettingsDialog,
            userAccount = userAccount,
            onOpenAuth = onOpenAuthDialog,
            onOpenUpgrade = onOpenUpgradeDialog,
            onOpenBackupRestore = onOpenBackupRestoreDialog,
            onLoadDemoData = {
                studentViewModel.loadDemoData()
                onDismissSettingsDialog()
                Toast.makeText(context, "داده‌های کامل نمونه دمو بارگذاری شد 🎓", Toast.LENGTH_LONG).show()
            },
            onClearToFreshSlate = {
                studentViewModel.clearToFreshSlate()
                onDismissSettingsDialog()
                Toast.makeText(context, "سیستم‌عامل پاکسازی شد و آماده ورود اطلاعات شماست ✨", Toast.LENGTH_LONG).show()
            },
            onReopenOnboarding = {
                onDismissSettingsDialog()
                onOpenOnboardingWizard()
            },
            onOpenPastSemesters = {
                onDismissSettingsDialog()
                onOpenPastSemestersDialog()
            },
            onOpenApkInfo = {
                onDismissSettingsDialog()
                onOpenApkDialog()
            },
            onTestNotification = onSendDeviceTestNotif
        )
    }

    if (showAuthDialog) {
        AuthAccountDialog(
            userAccount = userAccount,
            onSignInEmail = { email, password ->
                studentViewModel.signInWithEmail(email, password) { ok, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    if (ok) onDismissAuthDialog()
                }
            },
            onSignUpEmail = { name, email, password ->
                studentViewModel.signUpWithEmail(name, email, password) { ok, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    if (ok) onDismissAuthDialog()
                }
            },
            onGoogleSignIn = {
                studentViewModel.signInWithGoogle { ok, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    if (ok) onDismissAuthDialog()
                }
            },
            onSignOut = {
                studentViewModel.signOutUser()
                Toast.makeText(context, "از حساب کاربری خارج شدید.", Toast.LENGTH_SHORT).show()
            },
            onDeleteAccount = {
                studentViewModel.deleteUserAccount {
                    Toast.makeText(context, "حساب و داده‌ها حذف شدند.", Toast.LENGTH_SHORT).show()
                }
            },
            onOpenUpgrade = {
                onDismissAuthDialog()
                onOpenUpgradeDialog()
            },
            onDismiss = onDismissAuthDialog
        )
    }

    if (showUpgradeDialog) {
        SubscriptionUpgradeDialog(
            userAccount = userAccount,
            onUpgradeTier = { tier ->
                studentViewModel.upgradeSubscriptionTier(tier) { success, msg ->
                    if (success) {
                        Toast.makeText(context, "اشتراک شما به ${tier.titleFa} ارتقا یافت! ★", Toast.LENGTH_LONG).show()
                        onDismissUpgradeDialog()
                    }
                }
            },
            onApplyPromoCode = { code ->
                studentViewModel.applyPromoCode(code) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    if (success) {
                        onDismissUpgradeDialog()
                    }
                }
            },
            onDismiss = onDismissUpgradeDialog
        )
    }

    if (showBackupRestoreDialog) {
        val lastTimestamp by studentViewModel.lastSavedTimestamp.collectAsStateWithLifecycle()
        BackupRestoreDialog(
            lastSavedTimestamp = lastTimestamp,
            onExportJson = {
                studentViewModel.exportDatabaseBackup()
            },
            onImportJson = { json, callback ->
                studentViewModel.importDatabaseBackup(json, callback)
            },
            onDismiss = onDismissBackupRestoreDialog
        )
    }

    if (showProfileDialog) {
        EditProfileDialog(
            profile = profile,
            onDismiss = onDismissProfileDialog,
            onSave = { name, stdId, uni, maj, year, sem, passed, active ->
                studentViewModel.updateFullProfile(name, stdId, uni, maj, year, sem, passed, active)
                onDismissProfileDialog()
                Toast.makeText(context, "مشخصات دانشجویی با موفقیت ذخیره شد ✨", Toast.LENGTH_SHORT).show()
            },
            onReopenOnboarding = {
                onDismissProfileDialog()
                onOpenOnboardingWizard()
            },
            onOpenPastSemesters = {
                onDismissProfileDialog()
                onOpenPastSemestersDialog()
            }
        )
    }

    if (showPastSemestersDialog) {
        PastSemestersHistoryDialog(
            profile = profile,
            curriculumCourses = curriculumCourses,
            onDismiss = onDismissPastSemestersDialog,
            onSaveSummaryHistory = { selectedSemester, totalPassedCredits, overallGpa, summaries ->
                studentViewModel.savePastSemesterHistory(selectedSemester, totalPassedCredits, overallGpa, summaries)
                onDismissPastSemestersDialog()
                Toast.makeText(context, "سوابق تحصیلی و ترم جدید با موفقیت همگام‌سازی شد 🚀", Toast.LENGTH_LONG).show()
            }
        )
    }

    if (showNotifDialog) {
        NotificationDialog(
            notifications = notifications,
            onDismiss = onDismissNotifDialog,
            onTestAlarm = {
                studentViewModel.playNotificationTone(true)
                Toast.makeText(context, "آلارم صوتی تست شد 🔔", Toast.LENGTH_SHORT).show()
            },
            onSendDeviceTestNotif = onSendDeviceTestNotif,
            onClearAll = {
                studentViewModel.clearNotifications()
            }
        )
    }

    if (showApkDialog) {
        AndroidApkDialog(
            onDismiss = onDismissApkDialog
        )
    }

    if (showAddCourseDialog) {
        AddEditCourseDialog(
            initialCourse = null,
            onDismiss = onDismissAddCourseDialog,
            onSave = { newCourse ->
                studentViewModel.saveCourse(newCourse)
                onDismissAddCourseDialog()
            }
        )
    }

    editingCourse?.let { targetCourse ->
        AddEditCourseDialog(
            initialCourse = targetCourse,
            onDismiss = onDismissEditingCourse,
            onSave = { updated ->
                studentViewModel.saveCourse(updated)
                onDismissEditingCourse()
            },
            onDelete = { id ->
                studentViewModel.deleteCourse(id)
                onDismissEditingCourse()
            }
        )
    }

    if (showAddTaskDialog) {
        val availableCourseNames = courses.map { it.name }.distinct().ifEmpty { listOf("عمومی") }
        AddTaskDialog(
            courseNames = availableCourseNames,
            onDismiss = onDismissAddTaskDialog,
            onSave = { title, cName, date ->
                studentViewModel.saveTask(title, cName, date)
                onDismissAddTaskDialog()
            }
        )
    }

    // Phase 15 & 24: Spotlight-Style Command Center & Global Search
    if (showCommandCenter) {
        SpotlightSearchDialog(
            searchResults = globalSearchResults,
            searchQuery = searchQuery,
            onSearchQueryChange = { studentViewModel.setSearchQuery(it) },
            onDismiss = {
                studentViewModel.setSearchQuery("")
                onDismissCommandCenter()
            },
            onSelectCourse = { courseId ->
                val selected = courses.firstOrNull { it.id == courseId }
                if (selected != null) {
                    onSelectWorkspaceCourseId(selected.id)
                } else {
                    studentViewModel.selectTab(AppTab.SCHEDULE)
                }
                onDismissCommandCenter()
            },
            onSelectCurriculumCourse = {
                studentViewModel.selectTab(AppTab.CURRICULUM)
                onDismissCommandCenter()
            },
            onNavigateToTasks = {
                studentViewModel.selectTab(AppTab.TASKS)
                onDismissCommandCenter()
            },
            onNavigateToExams = {
                studentViewModel.selectTab(AppTab.EXAMS)
                onDismissCommandCenter()
            },
            onNavigateToNotes = {
                studentViewModel.selectTab(AppTab.POMODORO)
                onDismissCommandCenter()
            }
        )
    }

    // Phase 20, 21: Context-Aware Academic Copilot
    if (showCopilotDialog) {
        AcademicCopilotDialog(
            profile = profile,
            courses = courses,
            attendanceList = attendance,
            grades = grades,
            tasks = tasks,
            exams = exams,
            onDismiss = onDismissCopilotDialog
        )
    }

    // Phase 2 & 23: OCR Schedule Import
    if (showOcrImportDialog) {
        OcrScheduleImportDialog(
            onDismiss = onDismissOcrImportDialog,
            onConfirmImport = { drafts ->
                studentViewModel.importParsedCourses(drafts, clearExisting = false)
                onDismissOcrImportDialog()
                Toast.makeText(context, "${drafts.size} درس جدید با موفقیت به برنامه هفتگی اضافه شد 🚀", Toast.LENGTH_LONG).show()
            }
        )
    }

    // Phase 11 & 21: 360-Degree Course Workspace
    selectedWorkspaceCourseId?.let { courseId ->
        val activeCourse = courses.find { it.id == courseId }
        if (activeCourse != null) {
            val courseAttendance = attendance.find { it.courseName == activeCourse.name }
            val courseGrade = grades.find { it.courseName == activeCourse.name }
            val courseTasks = tasks.filter { it.courseName == activeCourse.name }
            val courseExam = exams.find { it.courseName == activeCourse.name }

            CourseWorkspaceDialog(
                course = activeCourse,
                attendance = courseAttendance,
                grade = courseGrade,
                tasks = courseTasks,
                exam = courseExam,
                onDismiss = onDismissWorkspaceCourse,
                onEditCourse = { updated ->
                    studentViewModel.saveCourse(updated)
                },
                onDeleteCourse = { id ->
                    studentViewModel.deleteCourse(id)
                    onDismissWorkspaceCourse()
                },
                onChangeAttendance = { delta ->
                    studentViewModel.changeAttendance(activeCourse.name, delta)
                },
                onToggleTask = { task ->
                    studentViewModel.toggleTask(task)
                },
                onAddTask = { title, date ->
                    studentViewModel.saveTask(title, activeCourse.name, date)
                },
                onDeleteTask = { task ->
                    studentViewModel.deleteTask(task)
                },
                onStartFocus = {
                    studentViewModel.selectTab(AppTab.POMODORO)
                    onDismissWorkspaceCourse()
                }
            )
        }
    }

    // Phase 2: Premium Share & Export System (Story Card 9:16 + Official Document A4)
    exportPayload?.let { payload ->
        PremiumShareExportModal(
            payload = payload,
            onDismiss = onDismissExportPayload
        )
    }
}
