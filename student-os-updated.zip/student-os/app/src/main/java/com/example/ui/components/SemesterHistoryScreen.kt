package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.GradeEntity
import com.example.data.local.entity.SemesterEntity
import com.example.data.local.entity.StudentProfileEntity
import com.example.ui.StudentViewModel
import com.example.ui.theme.Amber600
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import java.util.Locale

/**
 * Phase S & U: Semester History Notebook Screen
 * Clean, database-driven history displaying current and archived semesters with
 * authentic academic summaries (credits, courses, GPA, passed units) and transition entrypoint.
 */
@Composable
fun SemesterHistoryScreen(
    studentViewModel: StudentViewModel,
    modifier: Modifier = Modifier
) {
    val allSemesters by studentViewModel.allSemesters.collectAsState()
    val currentSemester by studentViewModel.currentSemester.collectAsState()
    val courses by studentViewModel.courses.collectAsState()
    val grades by studentViewModel.grades.collectAsState()
    val profile by studentViewModel.profile.collectAsState()

    var showTransitionDialog by remember { mutableStateOf(false) }
    val expandedSemesters = remember { mutableStateMapOf<String, Boolean>() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("semester_history_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Banner & Summary
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "دفترچه سوابق تحصیلی",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "تاریخچه پایدار ترم‌ها و آرشیو عملکرد دانشگاهی",
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate500
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(MaterialTheme.colorScheme.primary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.History,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Academic Profile Metrics Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        SummaryPill(
                            title = "ترم‌های ثبت‌شده",
                            value = "${allSemesters.size} ترم",
                            icon = Icons.Default.School
                        )
                        SummaryPill(
                            title = "مجموع واحدهای گذرانده",
                            value = "${profile.passedUnits} واحد",
                            icon = Icons.AutoMirrored.Filled.MenuBook
                        )
                        SummaryPill(
                            title = "معدل کل دانشجو",
                            value = if ((profile.declaredGpa ?: 0.0) > 0) String.format(Locale.US, "%.2f", profile.declaredGpa) else "ثبت‌نشده",
                            icon = Icons.AutoMirrored.Filled.TrendingUp
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Start New Semester Transition Action Button
                    Button(
                        onClick = { showTransitionDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("start_new_semester_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("انتقال و آغاز ترم تحصیلی جدید", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Semesters Section Title
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "فهرست ترم‌های دانشگاهی (${allSemesters.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "منبع داده پایدار: Room",
                    style = MaterialTheme.typography.labelSmall,
                    color = Slate500
                )
            }
        }

        // Semester Cards
        items(allSemesters, key = { it.id }) { semester ->
            val isCurrent = semester.isCurrent
            val isExpanded = expandedSemesters[semester.id] ?: isCurrent

            // Filter courses belonging to this semester
            val semesterCourses = remember(courses, semester.id) {
                courses.filter { it.semesterId == semester.id }
            }
            val totalSemesterUnits = semesterCourses.sumOf { it.units }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = if (isCurrent) 1.5.dp else 1.dp,
                        color = if (isCurrent) MaterialTheme.colorScheme.primary else Slate200.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(16.dp)
                    ),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isCurrent) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Semester Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { expandedSemesters[semester.id] = !isExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = semester.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                if (isCurrent) {
                                    Box(
                                        modifier = Modifier
                                            .background(Emerald600.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "ترم جاری",
                                            color = Emerald600,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .background(Slate400.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "آرشیو شده",
                                            color = Slate500,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                }
                            }
                            Text(
                                text = "سال تحصیلی: ${semester.academicYear} | ترم ${semester.termNumber}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate500
                            )
                        }

                        Icon(
                            if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = Slate500
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick Stats Line
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "${semesterCourses.size} درس ثبت‌شده",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "$totalSemesterUnits واحد",
                            style = MaterialTheme.typography.labelMedium,
                            color = Slate500
                        )
                        if ((semester.gpa ?: 0.0) > 0.0) {
                            Text(
                                text = "معدل: ${String.format(Locale.US, "%.2f", semester.gpa ?: 0.0)}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Emerald600
                            )
                        }
                    }

                    // Expanded Course Details
                    AnimatedVisibility(
                        visible = isExpanded,
                        enter = expandVertically(),
                        exit = shrinkVertically()
                    ) {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            HorizontalDivider(color = Slate200.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(8.dp))

                            if (semesterCourses.isEmpty()) {
                                Text(
                                    text = "هنوز درسی برای این ترم ثبت نشده است.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Slate400,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            } else {
                                semesterCourses.forEach { course ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = course.name,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Medium
                                            )
                                            Text(
                                                text = "${course.start} تا ${course.end} | ${course.location}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Slate400
                                            )
                                        }
                                        Text(
                                            text = "${course.units} واحد",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Slate500
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showTransitionDialog) {
        val currentSemesterCourses = remember(courses, currentSemester) {
            courses.filter { it.semesterId == currentSemester?.id }
        }
        SemesterTransitionDialog(
            currentSemester = currentSemester,
            currentCourses = currentSemesterCourses,
            currentGrades = grades,
            onDismiss = { showTransitionDialog = false },
            onExecuteTransition = { newTitle, newYear, newTermNum, newCoursesList ->
                val yearInt = newYear.filter { it.isDigit() }.take(4).toIntOrNull() ?: 1403
                studentViewModel.startNewSemester(newTitle, yearInt, newTermNum, newCoursesList)
            }
        )
    }
}

@Composable
private fun SummaryPill(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = Slate500
        )
    }
}
