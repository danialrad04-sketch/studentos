package com.example.domain.engine

import com.example.data.local.entity.AttendanceEntity
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.GradeEntity
import com.example.data.local.entity.StudentProfileEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.seed.CurriculumSeedData
import com.example.domain.model.ActionImpactType
import com.example.domain.model.CopilotActionProposal
import com.example.domain.model.CopilotMessage
import com.example.domain.model.CopilotPayload
import com.example.domain.model.CopilotSender
import com.example.ui.models.ExamItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object AcademicCopilotEngine {

    fun generateWelcomeMessage(
        profile: StudentProfileEntity,
        courses: List<CourseEntity>,
        attendanceList: List<AttendanceEntity>,
        grades: List<GradeEntity>,
        tasks: List<TaskEntity>
    ): CopilotMessage {
        val totalActiveUnits = courses.sumOf { it.units }.coerceAtLeast(profile.activeUnits)
        val passedUnits = profile.passedUnits
        val totalRequired = 140
        val remainingUnits = (totalRequired - passedUnits - totalActiveUnits).coerceAtLeast(0)
        val gpa = computeGpa(grades, profile.declaredGpa)

        val criticalAbsences = attendanceList.count { it.absentCount >= it.maxAllowed && it.maxAllowed > 0 }
        val pendingTasks = tasks.count { !it.isCompleted }

        val greeting = buildString {
            append("سلام ${profile.name} عزیز! من Academic Copilot (دستیار تحصیلی هوشمند) شما هستم.\n\n")
            append("📊 **شناسنامه زنده و تحلیل وضعیت:**\n")
            append("• **رشته تحصیلی:** ${profile.major} (${profile.university})\n")
            append("• **ترم جاری:** ترم ${profile.currentSemester} (ورودی ${profile.entryYear})\n")
            append("• **واحدهای فعال این ترم:** $totalActiveUnits واحد (${courses.size} درس فعال)\n")
            append("• **واحدهای گذرانده:** $passedUnits از $totalRequired واحد ($remainingUnits واحد تا فارغ‌التحصیلی)\n")
            append("• **معدل کل:** ${String.format(Locale.US, "%.2f", gpa)}\n")

            if (criticalAbsences > 0) {
                append("• 🚨 **هشدار قانون 3/16:** $criticalAbsences درس در لبه سقف غیبت قرار دارد!\n")
            }
            if (pendingTasks > 0) {
                append("• 📋 **تکالیف فعال:** $pendingTasks تکلیف باقی‌مانده\n")
            }
            append("\nمن بر تمام چارت مصوب ${profile.major}، قوانین آموزشی وزارت علوم، رادار غیبت‌ها و شبیه‌سازی معدل مسلط هستم. چه سوالی دارید؟")
        }

        return CopilotMessage(
            id = UUID.randomUUID().toString(),
            sender = CopilotSender.COPILOT,
            text = greeting,
            timestamp = currentTimeString(),
            suggestedQuickReplies = listOf(
                "تحلیل سقف غیبت‌های 3/16",
                "پیش‌نیازها و دروس ترم بعد",
                "محاسبه هدف معدل الف (بالای 17)",
                "برنامه کلاس‌ها و زمان‌بندی امروز",
                "بررسی تقویم امتحانات پایان‌ترم"
            ),
            confidenceBadge = "تحلیل رسمی چارت ${profile.major}"
        )
    }

    fun processUserQuery(
        query: String,
        profile: StudentProfileEntity,
        courses: List<CourseEntity>,
        attendanceList: List<AttendanceEntity>,
        grades: List<GradeEntity>,
        tasks: List<TaskEntity>,
        exams: List<ExamItem>
    ): CopilotMessage {
        val cleanQuery = query.trim().lowercase(Locale.ROOT)
        val gpa = computeGpa(grades, profile.declaredGpa)
        val totalActiveUnits = courses.sumOf { it.units }
        val majorCurriculum = CurriculumSeedData.getCoursesForMajor(profile.major)

        return when {
            // Fix / check semester
            cleanQuery.contains("ترم من") || cleanQuery.contains("ترم چندم") || cleanQuery.contains("اصلاح ترم") || cleanQuery.contains("تغییر ترم") -> {
                val text = buildString {
                    append("🎓 **بررسی و تعیین دقیق ترم تحصیلی:**\n\n")
                    append("• ترم ثبت‌شده برای شما در سیستم: **ترم ${profile.currentSemester}** (${profile.major})\n")
                    append("• سال ورود: **${profile.entryYear}**\n")
                    append("• واحدهای گذرانده تاکنون: **${profile.passedUnits} واحد**\n\n")
                    append("✅ سیستم به صورت مستقیم عدد ترم شما را محاسبه می‌کند (بدون هیچ خطای اندیس‌گذاری).\n")
                    append("اگر مایلید ترم خود را تغییر دهید یا سوابق تحصیلی گذشته را ویرایش کنید، از دکمه زیر اقدام فرمایید:")
                }

                val proposal = CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "ویرایش مشخصات تحصیلی و ترم",
                    description = "تنظیم دستی شماره ترم، سال ورود و تعداد واحدهای پاس‌شده",
                    impactType = ActionImpactType.REQUIRES_CONFIRMATION,
                    payload = CopilotPayload.NavigateToTab("PASSPORT"),
                    buttonLabel = "ورود به شناسنامه تحصیلی"
                )

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    proposedAction = proposal,
                    suggestedQuickReplies = listOf("پیش‌نیازها و دروس ترم بعد", "تحلیل سقف غیبت‌ها", "برنامه هفتگی من")
                )
            }

            // Attendance & 3/16 law analysis
            cleanQuery.contains("غیبت") || cleanQuery.contains("حضور") || cleanQuery.contains("رادار") || cleanQuery.contains("3/16") || cleanQuery.contains("۳/۱۶") -> {
                val dangerous = attendanceList.filter { it.absentCount >= it.maxAllowed && it.maxAllowed > 0 }
                val warning = attendanceList.filter { it.absentCount == it.maxAllowed - 1 && it.maxAllowed > 0 }
                val safe = attendanceList.filter { it.absentCount < it.maxAllowed - 1 }

                val text = buildString {
                    append("🛡️ **تحلیل رادار هوشمند غیبت‌ها (قانون 3/16 وزارت علوم):**\n\n")
                    if (dangerous.isNotEmpty()) {
                        append("🚨 **دروس در وضعیت بحرانی (رسیده به سقف حذف ماده 35):**\n")
                        dangerous.forEach {
                            append("• **${it.courseName}**: ${it.absentCount} غیبت از سقف مجاز ${it.maxAllowed} جلسه\n")
                        }
                        append("\n⚠️ **توصیه فوری:** در این دروس نباید حتی 1 جلسه دیگر غیبت داشته باشید تا مشمول حذف آموزشی نشوید.\n\n")
                    }
                    if (warning.isNotEmpty()) {
                        append("⚠️ **دروس در آستانه خطر (تنها 1 جلسه تا سقف مجاز):**\n")
                        warning.forEach {
                            append("• **${it.courseName}**: ${it.absentCount} غیبت (سقف مجاز: ${it.maxAllowed} جلسه)\n")
                        }
                        append("\n")
                    }
                    if (safe.isNotEmpty()) {
                        append("✅ **دروس در حاشیه امن:**\n")
                        safe.take(4).forEach {
                            val remainingSafe = (it.maxAllowed - it.absentCount).coerceAtLeast(0)
                            append("• **${it.courseName}**: ${it.absentCount} غیبت (حاشیه امن: $remainingSafe جلسه دیگر)\n")
                        }
                    }
                    if (attendanceList.isEmpty()) {
                        append("هنوز کلاسی در رادار حضور و غیاب ثبت نشده است.")
                    }
                }

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    suggestedQuickReplies = listOf("مشاهده رادار کامل غیبت‌ها", "امتحانات پایان‌ترم", "برنامه هفتگی")
                )
            }

            // Schedule & Today's classes
            cleanQuery.contains("کلاس") || cleanQuery.contains("برنامه") || cleanQuery.contains("استاد") || cleanQuery.contains("امروز") || cleanQuery.contains("ساعت") -> {
                val text = buildString {
                    append("📅 **تحلیل برنامه هفتگی و زمان‌بندی کلاس‌ها:**\n\n")
                    if (courses.isNotEmpty()) {
                        val daysMap = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنج‌شنبه", "جمعه")
                        val sortedCourses = courses.sortedWith(compareBy({ it.day }, { it.start }))
                        sortedCourses.forEach { c ->
                            val dayName = daysMap.getOrElse(c.day) { "شنبه" }
                            append("• **${c.name}** (${c.units} واحد)\n")
                            append("  🕒 $dayName | ساعت ${c.start} تا ${c.end} | ${c.location}\n")
                            if (c.professor.isNotBlank() && c.professor != "استاد دانشکده") {
                                append("  👨‍🏫 مدرس: ${c.professor}\n")
                            }
                        }
                    } else {
                        append("در حال حاضر درسی در برنامه هفتگی شما اضافه نشده است.")
                    }
                }

                val proposal = CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "انتقال به برنامه هفتگی کامل",
                    description = "مشاهده تقویم هفتگی کلاسی با تفکیک روزها و تداخل‌سنجی",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("SCHEDULE"),
                    buttonLabel = "ورود به برنامه هفتگی"
                )

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    proposedAction = proposal,
                    suggestedQuickReplies = listOf("رادار غیبت‌های کلاس‌ها", "امتحانات پایان‌ترم", "پیش‌نیازهای ترم بعد")
                )
            }

            // Next semester & Prerequisite tree analysis
            cleanQuery.contains("پیش‌نیاز") || cleanQuery.contains("ترم بعد") || cleanQuery.contains("انتخاب واحد") || cleanQuery.contains("چارت") || cleanQuery.contains("واحد") -> {
                val nextSemester = (profile.currentSemester + 1).coerceAtMost(8)
                val nextSemCourses = majorCurriculum.filter { it.recommendedSemester == nextSemester }
                val currentSemCourses = majorCurriculum.filter { it.recommendedSemester == profile.currentSemester }

                val text = buildString {
                    append("🗺️ **تحلیل تخصصی چارت ${profile.major} و پیش‌نیازها برای ترم $nextSemester:**\n\n")

                    if (nextSemCourses.isNotEmpty()) {
                        append("دروس مصوب ترم $nextSemester در چارت دانشگاه:\n")
                        nextSemCourses.forEach { c ->
                            val preReqInfo = if (c.prerequisites.isNotBlank()) " | پیش‌نیاز: ${c.prerequisites}" else " | بدون پیش‌نیاز"
                            val coReqInfo = if (c.coRequisites.isNotBlank()) " | هم‌نیاز: ${c.coRequisites}" else ""
                            append("• **${c.name}** (${c.units} واحد - نوع: ${c.courseType})$preReqInfo$coReqInfo\n")
                        }
                    } else {
                        append("دروس پایانی شامل پروژه کارشناسی، کارآموزی صنعتی و دروس اختیاری تخصصی هستند.\n")
                    }

                    append("\n📌 **توصیه استراتژیک آموزشی:**\n")
                    if (currentSemCourses.isNotEmpty()) {
                        val criticalPreReqs = currentSemCourses.take(2).map { it.name }.joinToString(" و ")
                        append("پاس کردن دروس «$criticalPreReqs» در ترم جاری شرط اساسی برای اخذ بدون مانع دروس ترم $nextSemester خواهد بود.\n")
                    }
                    val creditCeiling = if (gpa >= 17.0) 24 else if (gpa < 12.0) 14 else 20
                    append("با توجه به معدل فعلی شما (${String.format(Locale.US, "%.2f", gpa)})، سقف مجاز انتخاب واحد شما در ترم آینده **$creditCeiling واحد** است.")
                }

                val proposal = CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "مشاهده درخت کامل چارت و پیش‌نیازها",
                    description = "نمایش ماتریس ترم‌های 1 تا 8 و گراف وابستگی دروس",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("CURRICULUM"),
                    buttonLabel = "ورود به چارت تحصیلی"
                )

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    proposedAction = proposal,
                    suggestedQuickReplies = listOf("مشاهده چارت کامل", "چند واحد تا فارغ‌التحصیلی مانده؟", "شبیه‌ساز معدل الف")
                )
            }

            // Exam schedules
            cleanQuery.contains("امتحان") || cleanQuery.contains("فرجه") || cleanQuery.contains("پایان‌ترم") || cleanQuery.contains("تاریخ") -> {
                val text = buildString {
                    append("🎯 **تحلیل فشردگی امتحانات و تقویم پایان‌ترم:**\n\n")
                    if (exams.isNotEmpty()) {
                        append("لیست امتحانات ثبت‌شده شما:\n")
                        exams.sortedBy { it.solarDate }.forEach { exam ->
                            append("• **${exam.courseName}**: تاریخ ${exam.solarDate} ساعت ${exam.time} (${exam.location})\n")
                        }
                        val firstExam = exams.first()
                        append("\n💡 **توصیه زمان‌بندی:** اولین امتحان شما «${firstExam.courseName}» در تاریخ ${firstExam.solarDate} است. پیشنهاد می‌شود مرور متمرکز را با تکنیک پومودورو آغاز کنید.")
                    } else {
                        append("هنوز هیچ امتحانی ثبت نشده است. می‌توانید تاریخ امتحانات را در کارت‌های برنامه کلاسی وارد کنید.")
                    }
                }

                val proposal = CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "شروع جلسه مطالعه پومودورو",
                    description = "یک بازه 25 دقیقه‌ای تمرکز عمیق برای آمادگی امتحانات",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("POMODORO"),
                    buttonLabel = "ورود به تایمر تمرکز"
                )

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    proposedAction = proposal,
                    suggestedQuickReplies = listOf("لیست کامل امتحانات", "برنامه هفتگی", "تکالیف باقی‌مانده")
                )
            }

            // GPA Target simulation
            cleanQuery.contains("معدل") || cleanQuery.contains("الف") || cleanQuery.contains("شبیه‌ساز") || cleanQuery.contains("نمره") || cleanQuery.contains("کارنامه") -> {
                val currentGpa = gpa
                val neededFor17 = if (currentGpa < 17.0) {
                    val targetUnits = profile.passedUnits + totalActiveUnits
                    val targetScore = 17.0 * targetUnits
                    val currentScore = currentGpa * profile.passedUnits
                    val needed = (targetScore - currentScore) / totalActiveUnits.coerceAtLeast(1)
                    needed.coerceIn(0.0, 20.0)
                } else 17.0
                val formattedNeeded = String.format(Locale.US, "%.2f", neededFor17)

                val text = buildString {
                    append("📈 **تحلیل و شبیه‌سازی ارتقای معدل کل:**\n\n")
                    append("• **معدل کل فعلی:** ${String.format(Locale.US, "%.2f", currentGpa)}\n")
                    append("• **واحدهای فعال این ترم:** $totalActiveUnits واحد\n")
                    append("• **واحدهای پاس‌شده قبلی:** ${profile.passedUnits} واحد\n\n")

                    if (currentGpa >= 17.0) {
                        append("🌟 وضعیت شما در محدوده **دانشجوی ممتاز (رتبه الف)** قرار دارد! با حفظ معدل بالای 17 در این ترم، سقف انتخاب واحد شما در ترم بعد تا 24 واحد آزاد خواهد بود.\n")
                    } else {
                        append("🎯 برای رساندن معدل کل به **17.00 (رتبه الف)**، میانگین نمرات مورد نیاز شما در دروس این ترم برابر با **$formattedNeeded** از 20 است.\n")
                        append("• تمرکز ویژه روی دروس 3 واحدی بالاترین ضریب رشد معدل را برای شما خواهد داشت.")
                    }
                }

                val proposal = CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "باز کردن شبیه‌ساز زنده نمرات و کارنامه",
                    description = "تغییر نمرات میان‌ترم و پایان‌ترم برای مشاهده اثر آنی روی معدل",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("GRADES"),
                    buttonLabel = "ورود به شبیه‌ساز کارنامه"
                )

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    proposedAction = proposal,
                    suggestedQuickReplies = listOf("ورود به شبیه‌ساز کارنامه", "بررسی پیش‌نیازها", "تحلیل سقف غیبت‌ها")
                )
            }

            // Tasks & Deadlines
            cleanQuery.contains("تکلیف") || cleanQuery.contains("پروژه") || cleanQuery.contains("تسک") || cleanQuery.contains("تمرین") -> {
                val pending = tasks.filter { !it.isCompleted }
                val text = buildString {
                    append("📋 **وضعیت تکالیف و پروژه‌های درسی:**\n\n")
                    if (pending.isNotEmpty()) {
                        append("تکالیف فعال شما:\n")
                        pending.forEach {
                            append("• **${it.title}** (درس: ${it.courseName}) — موعد: ${it.dueDate}\n")
                        }
                    } else {
                        append("🎉 فوق‌العاده است! تمام تکالیف شما تکمیل شده‌اند و هیچ تسک معوقه‌ای ندارید.\n")
                    }
                }

                val firstPending = pending.firstOrNull()
                val proposal = if (firstPending != null) {
                    CopilotActionProposal(
                        id = UUID.randomUUID().toString(),
                        title = "تکمیل تکلیف: ${firstPending.title}",
                        description = "علامت‌گذاری این تکلیف به عنوان انجام‌شده",
                        impactType = ActionImpactType.REQUIRES_CONFIRMATION,
                        payload = CopilotPayload.CompleteTask(firstPending.id.toString(), firstPending.title),
                        buttonLabel = "علامت‌گذاری به عنوان انجام‌شده"
                    )
                } else null

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    proposedAction = proposal,
                    suggestedQuickReplies = listOf("افزودن تکلیف جدید", "برنامه هفتگی", "امتحانات")
                )
            }

            // Gamification & Badges
            cleanQuery.contains("مدال") || cleanQuery.contains("استریک") || cleanQuery.contains("دستاورد") || cleanQuery.contains("امتیاز") || cleanQuery.contains("xp") -> {
                val completedTasksCount = tasks.count { it.isCompleted }
                val zeroAbsenceCount = attendanceList.count { it.absentCount == 0 }

                val text = buildString {
                    append("🏆 **سامانه دستاوردها و لول آکادمیک:**\n\n")
                    append("• **استریک مطالعه پیوسته:** 🔥 4 روز متوالی\n")
                    append("• **تکالیف تکمیل‌شده:** $completedTasksCount مورد به موقع\n")
                    append("• **سپر غیبت صفر:** $zeroAbsenceCount درس با حضور کامل 100%\n\n")
                    append("با ادامه تمرکز در پومودورو، ثبت به موقع تکالیف و مدیریت غیبت‌ها امتیاز تجربه (XP) کسب کرده و مدال‌های آکادمیک را آنلاک کنید!")
                }

                val proposal = CopilotActionProposal(
                    id = UUID.randomUUID().toString(),
                    title = "مشاهده تالار افتخارات و مدال‌ها",
                    description = "بررسی لول آکادمیک، استریک روزانه و وضعیت مدال‌ها",
                    impactType = ActionImpactType.SAFE_QUERY,
                    payload = CopilotPayload.NavigateToTab("GAMIFICATION"),
                    buttonLabel = "ورود به بخش مدال‌ها"
                )

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    proposedAction = proposal,
                    suggestedQuickReplies = listOf("وضعیت مدال‌ها و استریک", "تحلیل سقف غیبت‌های من", "محاسبه معدل الف")
                )
            }

            // Default intelligent response
            else -> {
                val text = buildString {
                    append("💡 در پاسخ به پرسش شما درباره «$query»:\n\n")
                    append("به عنوان دستیار تحصیلی هوشمند دانشگاه، من روی بخش‌های زیر آماده خدمت‌رسانی هستم:\n")
                    append("1. **تحلیل غیبت‌ها و سقف مجاز 3/16** برای تمام دروس\n")
                    append("2. **چارت مصوب ${profile.major}**، پیش‌نیازها و هم‌نیازها (ترم 1 تا 8)\n")
                    append("3. **زمان‌بندی کلاس‌ها و تداخل‌سنجی برنامه هفتگی**\n")
                    append("4. **شبیه‌سازی نمرات و محاسبه معدل الف (بالای 17)**\n")
                    append("5. **تقویم امتحانات پایان‌ترم و تایمر پومودورو**\n\n")
                    append("می‌توانید یکی از گزینه‌های زیر را لمس کنید یا سوال مشخص‌تری مطرح نمایید:")
                }

                CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = text,
                    timestamp = currentTimeString(),
                    suggestedQuickReplies = listOf(
                        "تحلیل سقف غیبت‌های من",
                        "پیش‌نیازهای دروس ترم بعد",
                        "محاسبه معدل الف",
                        "برنامه هفتگی من",
                        "برنامه امتحانات"
                    )
                )
            }
        }
    }

    suspend fun processUserQueryAsync(
        query: String,
        profile: StudentProfileEntity,
        courses: List<CourseEntity>,
        attendanceList: List<AttendanceEntity>,
        grades: List<GradeEntity>,
        tasks: List<TaskEntity>,
        exams: List<ExamItem>,
        customApiKey: String? = null
    ): CopilotMessage {
        val studentContext = buildString {
            append("نام: ${profile.name}\n")
            append("دانشگاه: ${profile.university}\n")
            append("رشته: ${profile.major}\n")
            append("ترم تحصیلی: ترم ${profile.currentSemester} (ورودی ${profile.entryYear})\n")
            append("واحدهای گذرانده: ${profile.passedUnits}\n")
            append("دروس فعال این ترم (${courses.size} درس):\n")
            courses.forEach { c ->
                val att = attendanceList.find { it.courseId == c.id || it.courseName == c.name }
                append("- ${c.name} (${c.units} واحد) | زمان: روز ${c.day} ساعت ${c.start}-${c.end} | غیبت: ${att?.absentCount ?: 0}/${att?.maxAllowed ?: 3}\n")
            }
            if (exams.isNotEmpty()) {
                append("امتحانات پیش‌رو:\n")
                exams.forEach { e ->
                    append("- ${e.courseName}: تاریخ ${e.solarDate} ساعت ${e.time}\n")
                }
            }
        }

        // 1. Try real Gemini API via Firebase AI Logic first
        val geminiResult = com.example.data.api.GeminiApiClient.generateAcademicAdvice(
            prompt = query,
            studentContext = studentContext,
            customApiKey = customApiKey
        )

        if (geminiResult.isSuccess) {
            val geminiText = geminiResult.getOrNull()
            if (!geminiText.isNullOrBlank()) {
                return CopilotMessage(
                    id = UUID.randomUUID().toString(),
                    sender = CopilotSender.COPILOT,
                    text = geminiText,
                    timestamp = currentTimeString(),
                    confidenceBadge = "پاسخ زنده هوش مصنوعی Gemini 3.5 Flash ✦",
                    suggestedQuickReplies = listOf(
                        "برنامه مطالعه برای امتحانات",
                        "تحلیل سقف غیبت‌های من",
                        "محاسبه معدل الف"
                    )
                )
            }
        }

        // 2. Offline heuristic fallback
        return processUserQuery(query, profile, courses, attendanceList, grades, tasks, exams)
    }

    private fun computeGpa(grades: List<GradeEntity>, declaredGpa: Double?): Double {
        return if (grades.isNotEmpty() && grades.sumOf { it.units } > 0) {
            val totalWeighted = grades.sumOf { (it.midtermGrade + it.finalGrade) * it.units }
            val totalU = grades.sumOf { it.units }
            totalWeighted / totalU
        } else {
            declaredGpa?.takeIf { it > 0.0 } ?: 16.5
        }
    }

    private fun currentTimeString(): String {
        return SimpleDateFormat("HH:mm", Locale.US).format(Date())
    }
}
