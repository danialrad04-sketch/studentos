package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StudentOsColors
import com.example.ui.theme.StudentOsGlassTokens
import com.example.data.local.entity.AttendanceEntity
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.GradeEntity
import com.example.data.local.entity.StudentProfileEntity
import com.example.data.local.entity.TaskEntity
import com.example.domain.engine.AcademicCopilotEngine
import com.example.domain.model.ActionImpactType
import com.example.domain.model.CopilotActionProposal
import com.example.domain.model.CopilotMessage
import com.example.domain.model.CopilotPayload
import com.example.domain.model.CopilotSender
import com.example.ui.models.AppTab
import com.example.ui.models.ExamItem
import com.example.ui.theme.Amber500
import com.example.ui.theme.Amber600
import com.example.ui.theme.BrandIndigo400
import com.example.ui.theme.BrandIndigo600
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.Emerald500
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Rose500
import com.example.ui.theme.Rose600
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import com.example.ui.theme.VioletNeon
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@Composable
fun AcademicCopilotScreen(
    profile: StudentProfileEntity,
    courses: List<CourseEntity>,
    attendanceList: List<AttendanceEntity>,
    grades: List<GradeEntity>,
    tasks: List<TaskEntity>,
    exams: List<ExamItem>,
    onNavigateTab: (AppTab) -> Unit,
    onExecuteAction: (CopilotPayload) -> Unit,
    onOpenPastSemestersDialog: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val messages = remember {
        mutableStateListOf<CopilotMessage>().apply {
            add(
                AcademicCopilotEngine.generateWelcomeMessage(
                    profile = profile,
                    courses = courses,
                    attendanceList = attendanceList,
                    grades = grades,
                    tasks = tasks
                )
            )
        }
    }

    var inputText by remember { mutableStateOf("") }
    var isAiLoading by remember { mutableStateOf(false) }

    val sendMessage: (String) -> Unit = { query ->
        if (query.isNotBlank() && !isAiLoading) {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            val userMsg = CopilotMessage(
                id = UUID.randomUUID().toString(),
                sender = CopilotSender.USER,
                text = query.trim(),
                timestamp = time
            )
            messages.add(userMsg)
            inputText = ""
            isAiLoading = true

            coroutineScope.launch {
                listState.animateScrollToItem(messages.size - 1)
                val responseMsg = AcademicCopilotEngine.processUserQueryAsync(
                    query = query,
                    profile = profile,
                    courses = courses,
                    attendanceList = attendanceList,
                    grades = grades,
                    tasks = tasks,
                    exams = exams
                )
                messages.add(responseMsg)
                isAiLoading = false
                listState.animateScrollToItem(messages.size - 1)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("academic_copilot_screen")
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        // 1. Context HUD Bar (Live Student State)
        CopilotContextHudHeader(
            profile = profile,
            courses = courses,
            attendanceList = attendanceList,
            grades = grades,
            onOpenPastSemesters = onOpenPastSemestersDialog
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 2. Chat Conversation List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                CopilotMessageItem(
                    message = msg,
                    onQuickReplyClicked = { sendMessage(it) },
                    onApplyAction = { proposal ->
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        val index = messages.indexOf(msg)
                        if (index != -1) {
                            messages[index] = msg.copy(isActionApplied = true)
                        }
                        if (proposal.payload is CopilotPayload.NavigateToTab) {
                            when (proposal.payload.tabName) {
                                "CURRICULUM" -> onNavigateTab(AppTab.CURRICULUM)
                                "PASSPORT" -> onNavigateTab(AppTab.PASSPORT)
                                "GRADES" -> onNavigateTab(AppTab.GRADES)
                                "POMODORO" -> onNavigateTab(AppTab.POMODORO)
                                "TASKS" -> onNavigateTab(AppTab.TASKS)
                                "ATTENDANCE" -> onNavigateTab(AppTab.ATTENDANCE)
                                "GAMIFICATION" -> onNavigateTab(AppTab.GAMIFICATION)
                                else -> onNavigateTab(AppTab.DASHBOARD)
                            }
                        } else {
                            onExecuteAction(proposal.payload)
                        }
                    },
                    onDismissAction = {
                        val index = messages.indexOf(msg)
                        if (index != -1) {
                            messages[index] = msg.copy(isActionDismissed = true)
                        }
                    }
                )
            }

            if (isAiLoading) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            border = androidx.compose.foundation.BorderStroke(0.8.dp, BrandIndigo600.copy(alpha = 0.2f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = BrandIndigo600
                                )
                                Text(
                                    text = "دستیار در حال تحلیل وضعیت تحصیلی و تولید پاسخ...",
                                    fontSize = 11.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 3. Bento Quick Prompt Capsules
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            val quickChips = listOf(
                "📜 شرایط حذف ترم بدون احتساب",
                "⚠️ حدنصاب معدل مشروطی (ماده ۴۶)",
                "🔗 قانون پیش‌نیاز و هم‌پیشنیاز",
                "🚨 آیین‌نامه غیبت ۳/۱۶ و ماده ۳۵",
                "🌟 سقف واحد ترم بعد (معدل الف)",
                "🏆 وضعیت مدال‌ها و استریک تحصیلی"
            )
            items(quickChips) { chipText ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(StudentOsGlassTokens.glassElevated)
                        .border(1.dp, StudentOsGlassTokens.borderGradient, RoundedCornerShape(14.dp))
                        .clickable { sendMessage(chipText) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = chipText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 4. Floating Glass Input Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(StudentOsGlassTokens.glassElevated)
                .border(1.dp, StudentOsGlassTokens.borderCyanGradient, RoundedCornerShape(22.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = {
                        Text(
                            "از Academic Copilot بپرسید (مثلاً: شرایط حذف ترم، غیبت ۳/۱۶...)",
                            fontSize = 11.5.sp,
                            color = Slate400
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("copilot_input_field"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    ),
                    maxLines = 3,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { sendMessage(inputText) })
                )

                Surface(
                    onClick = { sendMessage(inputText) },
                    enabled = inputText.isNotBlank(),
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    color = if (inputText.isNotBlank()) StudentOsColors.CyanAccent else Color.White.copy(alpha = 0.08f),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (inputText.isNotBlank()) Color.White.copy(alpha = 0.3f) else Color.Transparent
                    )
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "ارسال",
                            tint = if (inputText.isNotBlank()) Color.Black else Slate400,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

    }
}

@Composable
private fun CopilotContextHudHeader(
    profile: StudentProfileEntity,
    courses: List<CourseEntity>,
    attendanceList: List<AttendanceEntity>,
    grades: List<GradeEntity>,
    onOpenPastSemesters: () -> Unit
) {
    val totalActiveUnits = courses.sumOf { it.units }.coerceAtLeast(profile.activeUnits)
    val criticalAbsences = attendanceList.count { it.absentCount >= it.maxAllowed && it.maxAllowed > 0 }

    val currentGpa = if (grades.isNotEmpty() && grades.sumOf { it.units } > 0) {
        val totalWeighted = grades.sumOf { (it.midtermGrade + it.finalGrade) * it.units }
        val totalU = grades.sumOf { it.units }
        totalWeighted / totalU
    } else {
        profile.declaredGpa?.takeIf { it > 0.0 } ?: 16.5
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    brush = Brush.horizontalGradient(listOf(BrandIndigo600.copy(alpha = 0.4f), VioletNeon.copy(alpha = 0.2f))),
                    shape = RoundedCornerShape(20.dp)
                )
                .padding(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(BrandIndigo600),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "دستیار تخصصی سیستم‌عامل تحصیلی",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "تحلیلگر بلادرنگ چارت، قوانین آموزشی و پیش‌نیازها",
                                fontSize = 9.5.sp,
                                color = Slate400
                            )
                        }
                    }

                    // Button to edit/adjust semester and past records
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onOpenPastSemesters() },
                        color = BrandIndigo600.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.History, contentDescription = null, tint = BrandIndigo600, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تنظیم ترم و سوابق", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BrandIndigo600)
                        }
                    }
                }

                HorizontalDivider(color = Slate200.copy(alpha = 0.3f))

                // Mini HUD Stats Pills
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    HudPill(label = "ترم فعلی", value = "ترم ${profile.currentSemester}", color = BrandIndigo600)
                    HudPill(label = "واحدهای فعال", value = "$totalActiveUnits واحد", color = CyanNeon)
                    HudPill(label = "پاس‌شده", value = "${profile.passedUnits} واحد", color = Emerald600)
                    HudPill(label = "معدل", value = String.format(Locale.US, "%.2f", currentGpa), color = Amber600)
                    if (criticalAbsences > 0) {
                        HudPill(label = "سقف غیبت", value = "$criticalAbsences هشدار", color = Rose600)
                    }
                }
            }
        }
    }
}

@Composable
private fun HudPill(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, fontSize = 9.sp, color = Slate400)
        Text(text = value, fontSize = 11.sp, fontWeight = FontWeight.Black, color = color)
    }
}

@Composable
private fun CopilotMessageItem(
    message: CopilotMessage,
    onQuickReplyClicked: (String) -> Unit,
    onApplyAction: (CopilotActionProposal) -> Unit,
    onDismissAction: () -> Unit
) {
    val isUser = message.sender == CopilotSender.USER

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(if (isUser) 0.85f else 0.95f),
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
        ) {
            if (!isUser) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(StudentOsColors.VioletAccent, StudentOsColors.CyanAccent)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(17.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
            }

            Box(
                modifier = Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart = 20.dp,
                            topEnd = 20.dp,
                            bottomStart = if (isUser) 20.dp else 6.dp,
                            bottomEnd = if (isUser) 6.dp else 20.dp
                        )
                    )
                    .background(
                        if (isUser) {
                            Brush.linearGradient(
                                listOf(
                                    StudentOsColors.CyanAccent.copy(alpha = 0.22f),
                                    StudentOsColors.CyanAccent.copy(alpha = 0.12f)
                                )
                            )
                        } else {
                            Brush.linearGradient(
                                listOf(
                                    StudentOsColors.VioletAccent.copy(alpha = 0.16f),
                                    StudentOsGlassTokens.glassElevated,
                                    StudentOsGlassTokens.glassDark
                                )
                            )
                        }
                    )
                    .border(
                        1.dp,
                        if (isUser) StudentOsGlassTokens.borderCyanGradient else StudentOsGlassTokens.borderVioletGradient,
                        RoundedCornerShape(
                            topStart = 20.dp,
                            topEnd = 20.dp,
                            bottomStart = if (isUser) 20.dp else 6.dp,
                            bottomEnd = if (isUser) 6.dp else 20.dp
                        )
                    )
                    .padding(14.dp)
            ) {
                Column {
                    // Badge if available
                    if (!isUser && message.confidenceBadge != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(StudentOsColors.VioletAccent.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = StudentOsColors.VioletAccent, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = message.confidenceBadge, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = StudentOsColors.VioletAccent)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    Text(
                        text = message.text,
                        fontSize = 12.5.sp,
                        fontWeight = if (isUser) FontWeight.SemiBold else FontWeight.Normal,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = message.timestamp,
                        fontSize = 9.sp,
                        color = Slate400,
                        modifier = Modifier.align(Alignment.End)
                    )
                }
            }
        }

        // Action Proposal Card if attached
        if (message.proposedAction != null && !message.isActionDismissed) {
            Spacer(modifier = Modifier.height(8.dp))
            CopilotActionProposalCard(
                proposal = message.proposedAction,
                isApplied = message.isActionApplied,
                onApply = { onApplyAction(message.proposedAction) },
                onDismiss = onDismissAction
            )
        }

        // Suggested Quick Replies if available
        if (message.suggestedQuickReplies.isNotEmpty() && !isUser) {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 40.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                message.suggestedQuickReplies.take(3).forEach { reply ->
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onQuickReplyClicked(reply) },
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(0.6.dp, BrandIndigo400.copy(alpha = 0.25f))
                    ) {
                        Text(
                            text = reply,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = BrandIndigo600,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CopilotActionProposalCard(
    proposal: CopilotActionProposal,
    isApplied: Boolean,
    onApply: () -> Unit,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 40.dp, top = 4.dp, bottom = 4.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isApplied) Emerald600.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (isApplied) Emerald600 else BrandIndigo600.copy(alpha = 0.4f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isApplied) Icons.Default.CheckCircle else Icons.Default.Lightbulb,
                        contentDescription = null,
                        tint = if (isApplied) Emerald600 else BrandIndigo600,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = proposal.title,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Impact Type Tag
                val impactLabel = when (proposal.impactType) {
                    ActionImpactType.SAFE_QUERY -> "تحلیلی / ایمن"
                    ActionImpactType.REQUIRES_CONFIRMATION -> "نیازمند تأیید شما"
                    ActionImpactType.PROTECTED_READONLY -> "قانون مصوب"
                }
                val impactColor = when (proposal.impactType) {
                    ActionImpactType.SAFE_QUERY -> CyanNeon
                    ActionImpactType.REQUIRES_CONFIRMATION -> Amber600
                    ActionImpactType.PROTECTED_READONLY -> Slate500
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = impactColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = impactLabel,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = impactColor,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = proposal.description,
                fontSize = 11.sp,
                color = Slate400
            )

            Spacer(modifier = Modifier.height(10.dp))

            if (isApplied) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Emerald600, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "تغییرات با موفقیت اعمال شد", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Emerald600)
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("رد پیشنهاد", fontSize = 11.sp, color = Slate500)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onApply,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo600),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(proposal.buttonLabel, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
