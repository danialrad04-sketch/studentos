package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SettingsBrightness
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.StudentProfileEntity
import com.example.ui.models.ThemeMode

@Composable
fun HeaderSection(
    profile: StudentProfileEntity,
    courseCount: Int,
    gpa: String,
    passedUnits: Int,
    totalRequiredCredits: Int = 140,
    notifCount: Int,
    isDarkTheme: Boolean,
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    onToggleTheme: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenAndroidInfo: () -> Unit,
    onResetDefaults: () -> Unit,
    onOpenCommandCenter: () -> Unit = {},
    onOpenCopilot: () -> Unit = {},
    onOpenOcrImport: () -> Unit = {},
    onOpenSettingsAndRoadmap: () -> Unit = {},
    onLoadDemoData: () -> Unit = {},
    onClearToFreshSlate: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showMenu by remember { mutableStateOf(false) }

    val isDark = MaterialTheme.colorScheme.background.red < 0.2f
    val studentDisplayName = if (profile.name.isNotBlank()) profile.name else "امیر"
    val termDisplayText = if (profile.term.isNotBlank()) "${profile.term} - هفته ۶" else "ترم پاییز ۱۴۰۴ - هفته ۶"
    val initialLetter = studentDisplayName.trim().firstOrNull()?.toString() ?: "ع"

    // Minimalist Top Bar matching the exact design in the user screenshot
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Streak Badge (Flame Pill on left in RTL)
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = if (isDark) Color(0xFF451A03).copy(alpha = 0.8f) else Color(0xFFFEF3C7),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isDark) Color(0xFFD97706).copy(alpha = 0.4f) else Color(0xFFFDE68A)
            ),
            modifier = Modifier.tactileClickable { onOpenProfile() }
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                AppEmoji(
                    type = AppEmojiType.FIRE,
                    size = 20.dp,
                    shapeRadiusRatio = 0.28f
                )
                Text(
                    text = "۱۲",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = if (isDark) Color(0xFFFBBF24) else Color(0xFFD97706)
                )
            }
        }

        // Student Profile & Greeting (Right in RTL)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "سلام، $studentDisplayName",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = "✍️", fontSize = 14.sp)
                }
                Spacer(modifier = Modifier.height(1.dp))
                Text(
                    text = termDisplayText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Avatar Circle
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF8B5CF6), // Violet
                                Color(0xFFEC4899), // Rose
                                Color(0xFFF43F5E)  // Coral
                            )
                        )
                    )
                    .border(2.dp, Color.White.copy(alpha = 0.8f), CircleShape)
                    .tactileClickable { showMenu = true },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initialLetter,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                    shape = RoundedCornerShape(18.dp)
                ) {
                    DropdownMenuItem(
                        text = { Text("✏️ ویرایش مشخصات دانشجو", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                        onClick = {
                            showMenu = false
                            onOpenProfile()
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Edit, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("⚙️ تنظیمات و وضعیت تم", fontSize = 12.sp) },
                        onClick = {
                            showMenu = false
                            onOpenSettingsAndRoadmap()
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("🌗 تغییر سریع تم", fontSize = 12.sp) },
                        onClick = {
                            showMenu = false
                            onToggleTheme()
                        },
                        leadingIcon = {
                            Icon(Icons.Default.SettingsBrightness, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("🎓 بارگذاری نمونه دمو (Rich Demo)", fontSize = 12.sp) },
                        onClick = {
                            showMenu = false
                            onLoadDemoData()
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("🧹 پاکسازی کامل داده‌ها (Clean Slate)", fontSize = 12.sp) },
                        onClick = {
                            showMenu = false
                            onClearToFreshSlate()
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
                        }
                    )
                }
            }
        }
    }
}

