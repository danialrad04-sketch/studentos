package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.StudentProfileEntity
import com.example.domain.model.AcademicProgress
import com.example.domain.model.CourseState
import com.example.domain.model.DataConfidence
import com.example.domain.model.DataSource
import com.example.domain.model.EvaluatedCurriculumCourse
import com.example.domain.model.GpaState
import com.example.ui.models.AcademicProgressUiState
import com.example.ui.models.CurriculumMatchUiState
import com.example.ui.theme.Amber600
import com.example.ui.theme.BrandIndigo600
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Rose600
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500

/**
 * Production Academic Passport Screen (Phase 4).
 * Clean, high-contrast, zero-fake data display of academic progress, GPA, readiness, and confidence.
 */
@Composable
fun AcademicPassportScreen(
    profile: StudentProfileEntity,
    progressState: AcademicProgressUiState,
    matchState: CurriculumMatchUiState,
    onNavigateToCurriculum: () -> Unit,
    onOpenExport: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("academic_passport_screen")
            .padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header: Student Identity & Accredited Curriculum Version
        PassportHeaderCard(profile = profile, matchState = matchState, onOpenExport = onOpenExport)

        // Loading & Error states
        when (progressState) {
            is AcademicProgressUiState.Loading -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = BrandIndigo600, strokeWidth = 3.dp)
                        Text(
                            text = "در حال تجمیع اطلاعات و تحلیل پیش‌نیازها...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Slate500
                        )
                    }
                }
            }
            is AcademicProgressUiState.Empty -> {
                EmptyStateCard(message = "شناسنامه تحصیلی شما هنوز مقداردهی نشده است.")
            }
            is AcademicProgressUiState.Error -> {
                ErrorStateCard(message = progressState.message)
            }
            is AcademicProgressUiState.Partial -> {
                PassportContent(
                    progress = progressState.progress,
                    matchState = matchState,
                    note = progressState.note,
                    onNavigateToCurriculum = onNavigateToCurriculum
                )
            }
            is AcademicProgressUiState.Ready -> {
                PassportContent(
                    progress = progressState.progress,
                    matchState = matchState,
                    note = null,
                    onNavigateToCurriculum = onNavigateToCurriculum
                )
            }
        }
    }
}

@Composable
private fun PassportHeaderCard(
    profile: StudentProfileEntity,
    matchState: CurriculumMatchUiState,
    onOpenExport: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("passport_header_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder().copy(width = 0.8.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = BrandIndigo600.copy(alpha = 0.12f),
                        modifier = Modifier.size(46.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.School,
                                contentDescription = "آیکون شناسنامه",
                                tint = BrandIndigo600,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = profile.name.ifEmpty { "دانشجوی گرامی" },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "شماره دانشجویی: ${profile.studentId.ifEmpty { "وارد نشده" }}",
                            fontSize = 11.5.sp,
                            color = Slate500
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = BrandIndigo600.copy(alpha = 0.08f)
                ) {
                    Text(
                        text = profile.term.ifEmpty { "ترم ۳ مهندسی شیمی" },
                        color = BrandIndigo600,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // University & Curriculum info
            val curriculumTitle = when (matchState) {
                is CurriculumMatchUiState.Ready -> matchState.output.version.title
                is CurriculumMatchUiState.NotFound -> "چارت نامشخص (${matchState.explanation})"
                else -> "در حال بازیابی چارت مرجع..."
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "چارت معتبر",
                        tint = BrandIndigo600,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = curriculumTitle,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            if (onOpenExport != null) {
                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onOpenExport,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BrandIndigo600
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "اشتراک و استوری",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "اشتراک شناسنامه و خروجی استوری / مدرک 📸",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun PassportContent(
    progress: AcademicProgress,
    matchState: CurriculumMatchUiState,
    note: String?,
    onNavigateToCurriculum: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Note banner if partial
        if (note != null) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Amber600.copy(alpha = 0.1f),
                border = androidx.compose.foundation.BorderStroke(0.8.dp, Amber600.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "توجه",
                        tint = Amber600,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = note,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // 2. Key Metrics Row (Passed, Enrolled, Remaining, Total)
        KeyMetricsRow(progress = progress)

        // 3. Visual Progress Bar Card
        ProgressCard(progress = progress)

        // 4. GPA & Confidence Row
        GpaAndConfidenceCard(progress = progress)

        // 5. Course Readiness Summary (Available, Blocked, Current)
        if (matchState is CurriculumMatchUiState.Ready) {
            CourseReadinessCard(
                output = matchState.output,
                onNavigateToCurriculum = onNavigateToCurriculum
            )
        }
    }
}

@Composable
private fun KeyMetricsRow(progress: AcademicProgress) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        MetricTile(
            title = "گذرانده",
            value = "${progress.passedCredits}",
            sub = "واحد",
            accentColor = Emerald600,
            modifier = Modifier.weight(1f)
        )
        MetricTile(
            title = "ترم جاری",
            value = "${progress.currentCredits}",
            sub = "واحد",
            accentColor = BrandIndigo600,
            modifier = Modifier.weight(1f)
        )
        MetricTile(
            title = "باقیمانده",
            value = "${progress.remainingCredits}",
            sub = "واحد",
            accentColor = Amber600,
            modifier = Modifier.weight(1f)
        )
        MetricTile(
            title = "کل مصوب",
            value = "${progress.totalRequiredCredits}",
            sub = "چارت",
            accentColor = Slate500,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun MetricTile(
    title: String,
    value: String,
    sub: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder().copy(width = 0.8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                fontSize = 11.sp,
                color = Slate500,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = accentColor
            )
            Text(
                text = sub,
                fontSize = 9.5.sp,
                color = Slate400
            )
        }
    }
}

@Composable
private fun ProgressCard(progress: AcademicProgress) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("progress_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder().copy(width = 0.8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "درصد پیشرفت کارشناسی",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${"%.1f".format(progress.progressPercentage)}٪",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = BrandIndigo600
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { progress.progressPercentage / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp)),
                color = Emerald600,
                trackColor = Slate200.copy(alpha = 0.6f)
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${progress.passedCredits} واحد گذرانده از ${progress.totalRequiredCredits} واحد مصوب",
                    fontSize = 11.sp,
                    color = Slate500
                )
                Text(
                    text = "${progress.remainingCredits} واحد تا فارغ‌التحصیلی",
                    fontSize = 11.sp,
                    color = Slate500,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun GpaAndConfidenceCard(progress: AcademicProgress) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("gpa_confidence_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder().copy(width = 0.8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // GPA Section
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "معدل کل",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "بر مبنای کارنامه ثبت شده رسمی",
                        fontSize = 10.5.sp,
                        color = Slate500
                    )
                }

                when (val gpa = progress.gpaState) {
                    is GpaState.Known -> {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Emerald600.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = "%.2f".format(gpa.value),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = Emerald600,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                        }
                    }
                    is GpaState.Unknown -> {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Slate200.copy(alpha = 0.6f)
                        ) {
                            Text(
                                text = "وارد نشده",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Slate500,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                    is GpaState.PartiallyCalculated -> {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = BrandIndigo600.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = "تخمینی: %.2f".format(gpa.currentSemesterGpa),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = BrandIndigo600,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Data Confidence Indicator
            val (confTitle, confDesc, confColor) = when (progress.confidence) {
                DataConfidence.VERIFIED_FULL -> Triple(
                    "تطبیق کامل و قطعی (Verified Full)",
                    "تمام سوابق دروس گذرانده با چارت مرجع مطابقت دقیق دارد.",
                    Emerald600
                )
                DataConfidence.CREDIT_ONLY -> Triple(
                    "فقط مجموع واحد (Credit Only)",
                    "واحدهای گذرانده به صورت خوداظهاری ثبت شده؛ ریز دروس ترم‌های قبل وارد نشده است.",
                    Amber600
                )
                DataConfidence.PARTIAL_HISTORY -> Triple(
                    "تاریخچه ناقص (Partial History)",
                    "مجموع واحدهای سوابق دروس با مجموع واحدهای گذرانده مغایرت دارد.",
                    Amber600
                )
                DataConfidence.UNKNOWN -> Triple(
                    "نامشخص (Unknown)",
                    "هیچ سابقه‌ای از نمرات یا واحدهای گذرانده در سیستم ثبت نشده است.",
                    Rose600
                )
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = confColor.copy(alpha = 0.08f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .size(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(confColor)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = confTitle,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = confColor
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = confDesc,
                            fontSize = 10.5.sp,
                            color = Slate500,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CourseReadinessCard(
    output: com.example.domain.engine.CurriculumMatchOutput,
    onNavigateToCurriculum: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("readiness_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder().copy(width = 0.8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "وضعیت آمادگی و واجدشرایطی دروس",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "مشاهده چارت ←",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandIndigo600,
                    modifier = Modifier.clickable { onNavigateToCurriculum() }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 3 Badges (Available, Blocked, Current)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ReadinessBadge(
                    symbol = "→",
                    label = "قابل اخذ",
                    count = output.availableCourses.size,
                    color = BrandIndigo600,
                    modifier = Modifier.weight(1f)
                )
                ReadinessBadge(
                    symbol = "🔒",
                    label = "قفل پیش‌نیاز",
                    count = output.blockedCourses.size,
                    color = Rose600,
                    modifier = Modifier.weight(1f)
                )
                ReadinessBadge(
                    symbol = "◉",
                    label = "ترم جاری",
                    count = output.currentCourses.size,
                    color = Amber600,
                    modifier = Modifier.weight(1f)
                )
            }

            // Quick list of Top 3 Available courses
            if (output.availableCourses.isNotEmpty()) {
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "دروس اولویت‌دار آماده اخذ ترم آینده:",
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Slate500
                )
                Spacer(modifier = Modifier.height(6.dp))
                output.availableCourses.take(3).forEach { course ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "→", color = BrandIndigo600, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = course.name,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "(${course.units} واحد · ترم پیشنهادی ${course.recommendedSemester})",
                            fontSize = 10.sp,
                            color = Slate400
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ReadinessBadge(
    symbol: String,
    label: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = color.copy(alpha = 0.08f),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "$symbol $count",
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                color = color
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = Slate500
            )
        }
    }
}

@Composable
private fun EmptyStateCard(message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = Slate400, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = message, style = MaterialTheme.typography.bodyMedium, color = Slate500)
        }
    }
}

@Composable
private fun ErrorStateCard(message: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder().copy(width = 0.8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = Rose600, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text(text = message, style = MaterialTheme.typography.bodySmall, color = Rose600)
        }
    }
}
