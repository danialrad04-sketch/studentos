package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.CourseEntity
import com.example.ui.theme.studentColors

private val DAY_LABELS = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه")

private val PALETTE_COLORS = listOf(
    "#6366F1" to "نیلی مدرن",
    "#8B5CF6" to "بنفش نئونی",
    "#3B82F6" to "آبی آسمانی",
    "#06B6D4" to "فیروزه‌ای",
    "#10B981" to "سبز زمردی",
    "#F59E0B" to "کهربایی آذرخش",
    "#EF4444" to "سرخ مرجانی",
    "#EC4899" to "صورتی فانتزی"
)

private val STANDARD_TIME_SLOTS = listOf(
    "08:00" to "10:00",
    "10:00" to "12:00",
    "13:30" to "15:30",
    "15:30" to "17:30",
    "17:30" to "19:30"
)

private val POPULAR_COURSE_PRESETS = listOf(
    "ریاضی عمومی ۱", "ریاضی عمومی ۲", "معادلات دیفرانسیل", "فیزیک ۱", "فیزیک ۲",
    "برنامه‌نویسی مقدماتی", "ساختمان داده‌ها", "طراحی الگوریتم", "شبکه‌های کامپیوتری",
    "سیستم‌های عامل", "مدار منطقی", "معماری کامپیوتر", "آمار و احتمالات",
    "پایگاه داده‌ها", "اندیشه اسلامی ۱", "اخلاق اسلامی", "زبان عمومی",
    "فارسی عمومی", "تربیت بدنی"
)

// Shared shape tokens so every control in this dialog (and its confirm dialog)
// reads as one consistent, minimal, professional surface language.
private val FieldShape = RoundedCornerShape(14.dp)
private val ChipShape = RoundedCornerShape(10.dp)
private val CardShape = RoundedCornerShape(18.dp)
private val ButtonShape = RoundedCornerShape(12.dp)

/**
 * Pro Add / Edit / Add-Drop Course Dialog.
 * One consistent minimal design language shared across every field: same
 * field shape, same focus color (the course's own accent), same typography
 * scale, and clearly separated sections so editing a course feels calm and
 * professional in both light and dark mode.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddEditCourseDialog(
    initialCourse: CourseEntity?,
    onDismiss: () -> Unit,
    onSave: (CourseEntity) -> Unit,
    onDelete: ((String) -> Unit)? = null
) {
    var name by remember { mutableStateOf(initialCourse?.name ?: "") }
    var courseCode by remember { mutableStateOf(initialCourse?.courseCode ?: "") }
    var professor by remember { mutableStateOf(initialCourse?.professor ?: "") }
    var day by remember { mutableIntStateOf(initialCourse?.day ?: 0) }
    var location by remember { mutableStateOf(initialCourse?.location ?: "") }
    var start by remember { mutableStateOf(initialCourse?.start ?: "08:00") }
    var end by remember { mutableStateOf(initialCourse?.end ?: "10:00") }
    var units by remember { mutableIntStateOf(initialCourse?.units ?: 3) }
    var selectedColorHex by remember { mutableStateOf(initialCourse?.colorHex ?: "#6366F1") }
    var examDate by remember { mutableStateOf(initialCourse?.examDate ?: "") }
    var examTime by remember { mutableStateOf(initialCourse?.examTime ?: "09:00") }
    var examLocation by remember { mutableStateOf(initialCourse?.examLocation ?: "") }
    var notes by remember { mutableStateOf(initialCourse?.notes ?: "") }

    var dayExpanded by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showQuickPresets by remember { mutableStateOf(false) }

    val activeColor = remember(selectedColorHex) {
        try {
            Color(android.graphics.Color.parseColor(selectedColorHex))
        } catch (_: Exception) {
            Color(0xFF6366F1)
        }
    }

    // One color-scheme instance reused by every field in this dialog, so
    // focus/label/cursor colors never diverge between sections.
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = activeColor,
        focusedLabelColor = activeColor,
        cursorColor = activeColor,
        focusedLeadingIconColor = activeColor,
        unfocusedLeadingIconColor = MaterialTheme.colorScheme.onSurfaceVariant
    )

    StudentGlassModalSheet(
        onDismiss = onDismiss,
        maxWidth = 620.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // ── Header ──────────────────────────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(activeColor.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = null,
                            tint = activeColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = if (initialCourse == null) "درس جدید" else "ویرایش درس",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (initialCourse == null)
                                "مشخصات و برنامه هفتگی درس را وارد کنید"
                            else
                                "تغییرات را ثبت کنید تا برنامه به‌روز شود",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "بستن",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // ── Basic info ──────────────────────────────────────────
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FormSectionLabel(Icons.Default.School, "اطلاعات پایه", activeColor)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("نام درس") },
                        modifier = Modifier.weight(1.8f),
                        singleLine = true,
                        shape = FieldShape,
                        colors = fieldColors
                    )
                    OutlinedTextField(
                        value = courseCode,
                        onValueChange = { courseCode = it },
                        label = { Text("کد درس") },
                        placeholder = { Text("۱۲-۳۴") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = FieldShape,
                        colors = fieldColors
                    )
                }

                OutlinedTextField(
                    value = professor,
                    onValueChange = { professor = it },
                    label = { Text("نام استاد / مدرس") },
                    placeholder = { Text("مثال: دکتر احمدی") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    leadingIcon = {
                        Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(18.dp))
                    },
                    shape = FieldShape,
                    colors = fieldColors
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "پیشنهاد از عنوان‌های پرکاربرد",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = { showQuickPresets = !showQuickPresets }) {
                        Text(
                            text = if (showQuickPresets) "بستن" else "مشاهده",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = activeColor
                        )
                    }
                }

                AnimatedVisibility(visible = showQuickPresets) {
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        POPULAR_COURSE_PRESETS.forEach { preset ->
                            SelectableChip(
                                text = preset,
                                selected = name == preset,
                                activeColor = activeColor,
                                onClick = {
                                    name = preset
                                    showQuickPresets = false
                                }
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // ── Schedule ────────────────────────────────────────────
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FormSectionLabel(Icons.Default.Schedule, "زمان‌بندی کلاس", activeColor)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ExposedDropdownMenuBox(
                        expanded = dayExpanded,
                        onExpandedChange = { dayExpanded = !dayExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = DAY_LABELS.getOrElse(day) { "شنبه" },
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("روز برگزاری") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dayExpanded) },
                            modifier = Modifier.menuAnchor(),
                            shape = FieldShape,
                            colors = fieldColors
                        )
                        ExposedDropdownMenu(
                            expanded = dayExpanded,
                            onDismissRequest = { dayExpanded = false }
                        ) {
                            DAY_LABELS.forEachIndexed { index, label ->
                                DropdownMenuItem(
                                    text = { Text(label) },
                                    onClick = {
                                        day = index
                                        dayExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = location,
                        onValueChange = { location = it },
                        label = { Text("مکان / کلاس") },
                        placeholder = { Text("کلاس ۱۰۲") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        leadingIcon = {
                            Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(18.dp))
                        },
                        shape = FieldShape,
                        colors = fieldColors
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = start,
                        onValueChange = { start = it },
                        label = { Text("شروع") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = FieldShape,
                        colors = fieldColors
                    )
                    OutlinedTextField(
                        value = end,
                        onValueChange = { end = it },
                        label = { Text("پایان") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = FieldShape,
                        colors = fieldColors
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    STANDARD_TIME_SLOTS.forEach { (slotStart, slotEnd) ->
                        SelectableChip(
                            text = "$slotStart–$slotEnd",
                            selected = start == slotStart && end == slotEnd,
                            activeColor = activeColor,
                            onClick = {
                                start = slotStart
                                end = slotEnd
                            }
                        )
                    }
                }

                Column {
                    Text(
                        text = "تعداد واحد: $units واحد",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(1, 2, 3, 4).forEach { u ->
                            val isSelected = units == u
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { units = u },
                                shape = ChipShape,
                                color = if (isSelected) activeColor else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) activeColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                                )
                            ) {
                                Box(
                                    modifier = Modifier.padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "$u",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // ── Exam info ───────────────────────────────────────────
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FormSectionLabel(Icons.Default.CalendarToday, "آزمون پایان‌ترم", activeColor)

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = CardShape,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = examDate,
                                onValueChange = { examDate = it },
                                label = { Text("تاریخ امتحان") },
                                placeholder = { Text("۱۴۰۳/۱۰/۲۵") },
                                modifier = Modifier.weight(1.2f),
                                singleLine = true,
                                shape = FieldShape,
                                colors = fieldColors
                            )
                            OutlinedTextField(
                                value = examTime,
                                onValueChange = { examTime = it },
                                label = { Text("ساعت") },
                                placeholder = { Text("۰۸:۳۰") },
                                modifier = Modifier.weight(0.8f),
                                singleLine = true,
                                shape = FieldShape,
                                colors = fieldColors
                            )
                        }
                        OutlinedTextField(
                            value = examLocation,
                            onValueChange = { examLocation = it },
                            label = { Text("محل امتحان") },
                            placeholder = { Text("سالن امتحانات یا کلاس") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = FieldShape,
                            colors = fieldColors
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // ── Notes ───────────────────────────────────────────────
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FormSectionLabel(Icons.Default.EditNote, "یادداشت و سرفصل", activeColor)
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    placeholder = { Text("سرفصل‌ها، بارم‌بندی یا یادداشت‌های مهم درسی...") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4,
                    shape = FieldShape,
                    colors = fieldColors
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // ── Color ───────────────────────────────────────────────
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FormSectionLabel(Icons.Default.Palette, "رنگ شاخص درس", activeColor)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    PALETTE_COLORS.forEach { (hex, _) ->
                        val c = try {
                            Color(android.graphics.Color.parseColor(hex))
                        } catch (_: Exception) {
                            Color(0xFF6366F1)
                        }
                        val isSelected = selectedColorHex.equals(hex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(c)
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable { selectedColorHex = hex },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
                Text(
                    text = PALETTE_COLORS.firstOrNull { it.first.equals(selectedColorHex, true) }?.second ?: "",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            // ── Actions ─────────────────────────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (initialCourse != null && onDelete != null) {
                    OutlinedButton(
                        onClick = { showDeleteConfirm = true },
                        shape = ButtonShape,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.studentColors.attendanceCritical
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.studentColors.attendanceCritical.copy(alpha = 0.4f))
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("حذف درس", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                } else {
                    Spacer(modifier = Modifier.width(4.dp))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = ButtonShape
                    ) {
                        Text("انصراف", fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                val id = initialCourse?.id ?: java.util.UUID.randomUUID().toString()
                                onSave(
                                    CourseEntity(
                                        id = id,
                                        name = name.trim(),
                                        day = day,
                                        start = start.trim(),
                                        end = end.trim(),
                                        location = location.trim(),
                                        colorHex = selectedColorHex,
                                        units = units,
                                        semesterId = initialCourse?.semesterId ?: "current",
                                        courseCode = courseCode.trim(),
                                        professor = professor.trim(),
                                        examDate = examDate.trim(),
                                        examTime = examTime.trim(),
                                        examLocation = examLocation.trim(),
                                        notes = notes.trim()
                                    )
                                )
                            }
                        },
                        shape = ButtonShape,
                        colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                        enabled = name.isNotBlank()
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ذخیره تغییرات", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Confirmation Alert for Course Deletion — themed to match the app surface
    // in both light and dark mode rather than the Material default.
    if (showDeleteConfirm && initialCourse != null && onDelete != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            containerColor = MaterialTheme.colorScheme.surface,
            icon = {
                Icon(
                    imageVector = Icons.Default.WarningAmber,
                    contentDescription = null,
                    tint = MaterialTheme.studentColors.attendanceCritical,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "حذف «${initialCourse.name}»؟",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Text(
                    text = "با حذف این درس، حضور و غیاب، نمرات و تکالیف مرتبط با آن نیز پاک خواهند شد. این عملیات قابل بازگشت نیست.",
                    fontSize = 12.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 19.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete(initialCourse.id)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.studentColors.attendanceCritical),
                    shape = ButtonShape
                ) {
                    Text("بله، حذف کن", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("انصراف", fontSize = 12.sp)
                }
            },
            shape = RoundedCornerShape(24.dp)
        )
    }
}

/** Small, consistent section header used to visually separate every group of fields. */
@Composable
private fun FormSectionLabel(icon: ImageVector, text: String, tint: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = text,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/** One reusable pill/chip style shared by presets & time slots so both look identical. */
@Composable
private fun SelectableChip(
    text: String,
    selected: Boolean,
    activeColor: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = ChipShape,
        color = if (selected) activeColor.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        border = BorderStroke(1.dp, if (selected) activeColor else Color.Transparent),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) activeColor else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}
