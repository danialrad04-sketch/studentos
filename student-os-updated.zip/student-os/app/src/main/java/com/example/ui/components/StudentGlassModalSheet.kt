package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.StudentOsColors
import com.example.ui.theme.StudentOsGlassTokens
import kotlinx.coroutines.delay

/**
 * 2026 Architectural Standard for Minimalist Fluid Glass Modal Bottom Sheet.
 * Adapts seamlessly across:
 * - All screen sizes (Compact smartphones, Foldables, Tablets)
 * - Both Light & Dark Themes (Dark Velvet space glass vs Frost Crisp Paper glass)
 * - Safe Area Insets (Keyboard IME padding + System Navigation Bar)
 */
@Composable
fun StudentGlassModalSheet(
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    maxWidth: Dp = 560.dp,
    maxHeightPercent: Float = 0.92f,
    showDragHandle: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    var isVisible by remember { mutableStateOf(false) }
    val isDark = isSystemInDarkTheme()

    LaunchedEffect(Unit) {
        isVisible = true
    }

    val sheetShape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp, bottomStart = 16.dp, bottomEnd = 16.dp)

    val surfaceColor = if (isDark) {
        Color(0xEB161C2D) // rgba(22, 28, 45, 0.92)
    } else {
        Color(0xF5FFFFFF) // 96% frosted pure white
    }

    val borderBrush = if (isDark) {
        StudentOsGlassTokens.GlassBorderGradient
    } else {
        StudentOsGlassTokens.GlassBorderLightGradient
    }

    val dragHandleColor = if (isDark) {
        Color.White.copy(alpha = 0.28f)
    } else {
        Color(0xFF0F172A).copy(alpha = 0.20f)
    }

    Dialog(
        onDismissRequest = {
            isVisible = false
            onDismiss()
        },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    if (isDark) Color(0x99000000) else Color(0x660F172A)
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    isVisible = false
                    onDismiss()
                },
            contentAlignment = Alignment.BottomCenter
        ) {
            AnimatedVisibility(
                visible = isVisible,
                enter = slideInVertically(
                    initialOffsetY = { it },
                    animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing)
                ) + fadeIn(animationSpec = tween(200)),
                exit = slideOutVertically(
                    targetOffsetY = { it },
                    animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing)
                ) + fadeOut(animationSpec = tween(150))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = maxWidth)
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .navigationBarsPadding()
                        .imePadding()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { /* Consume click inside sheet */ }
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(
                                elevation = if (isDark) 24.dp else 16.dp,
                                shape = sheetShape,
                                spotColor = if (isDark) StudentOsColors.CyanAccent.copy(alpha = 0.20f) else Color(0x1F000000)
                            )
                            .clip(sheetShape)
                            .background(surfaceColor)
                            .border(1.dp, borderBrush, sheetShape)
                            .then(modifier)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 18.dp, vertical = 14.dp)
                        ) {
                            if (showDragHandle) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.CenterHorizontally)
                                        .padding(bottom = 12.dp)
                                        .size(width = 38.dp, height = 4.5.dp)
                                        .clip(CircleShape)
                                        .background(dragHandleColor)
                                )
                            }
                            content()
                        }
                    }
                }
            }
        }
    }
}
