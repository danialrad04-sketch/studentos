package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * CourseEntity upgraded for Student OS.
 * Includes complete course metadata, professor, exams, notes, semesterId, and stable IDs.
 */
@Entity(
    tableName = "courses",
    indices = [
        Index(value = ["semesterId"]),
        Index(value = ["courseCode"]),
        Index(value = ["professorId"])
    ]
)
data class CourseEntity(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val day: Int, // 0 = شنبه, 1 = یکشنبه, 2 = دوشنبه, 3 = سه‌شنبه, 4 = چهارشنبه
    val start: String,
    val end: String,
    val location: String,
    val colorHex: String,
    val units: Int = 3,
    val semesterId: String = "current",
    val courseCode: String = "",
    val professorId: String? = null,
    val professor: String = "",
    val examDate: String = "",
    val examTime: String = "",
    val examLocation: String = "",
    val notes: String = "",
    val isArchived: Boolean = false
)
