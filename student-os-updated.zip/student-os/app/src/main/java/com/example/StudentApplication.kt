package com.example

import android.app.Application
import android.util.Log
import com.example.ui.util.NotificationHelper

class StudentApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            NotificationHelper.initNotificationChannel(this)
        } catch (e: Throwable) {
            Log.e("StudentApplication", "Failed to initialize notification channel", e)
        }
    }
}
