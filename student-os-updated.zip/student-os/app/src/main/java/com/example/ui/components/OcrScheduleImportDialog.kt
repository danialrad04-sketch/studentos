package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Scanner
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.parser.DraftValidationState
import com.example.data.parser.ParsedCourseDraft
import com.example.data.parser.RegistrationTextParser
import com.example.ui.theme.Amber600
import com.example.ui.theme.BrandIndigo600
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Rose600
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import kotlinx.coroutines.delay

/**
 * Phase H, I, J: Bulk Import & OCR Schedule Import Dialog.
 * Dual-Mode:
 * 1. Image OCR with Android Photo Picker
 * 2. Persian Natural Language & Structured Text Bulk Parser
 * Includes Pre-Commit Schema Validation, Conflict and Missing Field checks.
 */
@Composable
fun OcrScheduleImportDialog(
    onDismiss: () -> Unit,
    onConfirmImport: (List<ParsedCourseDraft>) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(1) } // Default to Bulk Text (0: OCR Image, 1: Bulk Text)

    // OCR State
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var isProcessingOcr by remember { mutableStateOf(false) }
    var ocrProgress by remember { mutableStateOf(0f) }

    // Bulk Text State
    var bulkInputText by remember { mutableStateOf("") }

    // Extracted drafts
    val extractedDrafts = remember { mutableStateListOf<ParsedCourseDraft>() }

    // Android Photo Picker launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedImageUri = uri
            isProcessingOcr = true
            ocrProgress = 0f
        }
    }

    // OCR processing simulation
    LaunchedEffect(isProcessingOcr) {
        if (isProcessingOcr) {
            ocrProgress = 0.2f
            delay(350)
            ocrProgress = 0.65f
            delay(400)
            ocrProgress = 1.0f
            delay(250)

            extractedDrafts.clear()
            extractedDrafts.addAll(
                listOf(
                    ParsedCourseDraft(
                        name = "مکانیک سیالات ۱",
                        units = 3,
                        dayOfWeek = 0,
                        startTime = "08:00",
                        endTime = "10:00",
                        location = "دانشکده شیمی - تالار ۳",
                        instructor = "دکتر مرادی"
                    ),
                    ParsedCourseDraft(
                        name = "انتقال حرارت ۱",
                        units = 3,
                        dayOfWeek = 1,
                        startTime = "10:00",
                        endTime = "12:00",
                        location = "کلاس ۲۰۴ ابوریحان",
                        instructor = "دکتر صادقی"
                    ),
                    ParsedCourseDraft(
                        name = "ترمودینامیک ۲",
                        units = 3,
                        dayOfWeek = 2,
                        startTime = "13:30",
                        endTime = "15:30",
                        location = "کلاس ۱۰۱ مهندسی",
                        instructor = "دکتر کاظمی"
                    )
                )
            )
            isProcessingOcr = false
        }
    }

    StudentGlassModalSheet(
        onDismiss = onDismiss,
        maxWidth = 620.dp
    ) {
        Column(
            modifier = modifier
                .fillMaxWidth()
                .testTag("ocr_schedule_import_dialog"),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Dialog Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = BrandIndigo600.copy(alpha = 0.15f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = BrandIndigo600,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "ورود گروهی و هوشمند دروس",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "پردازش متن طبیعی فارسی یا اسکن تصویر با اعتبارسنجی پیش از ثبت",
                                style = MaterialTheme.typography.labelSmall,
                                color = Slate500
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "بستن", tint = Slate400)
                    }
                }

                // Tabs: OCR vs Bulk Text
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.clip(RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Scanner, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("اسکن تصویر (OCR)", fontSize = 11.5.sp)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.TextFields, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("ورود متنی و طبیعی", fontSize = 11.5.sp)
                            }
                        }
                    )
                }

                // Tab Contents
                if (selectedTab == 0) {
                    // OCR Mode
                    if (extractedDrafts.isEmpty() && !isProcessingOcr) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Image, contentDescription = null, tint = BrandIndigo600, modifier = Modifier.size(40.dp))
                                Text(
                                    text = "تصویر فرم یا اسکرین‌شات انتخاب واحد را انتخاب کنید",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Button(
                                    onClick = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo600),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("انتخاب از گالری (Photo Picker)")
                                }
                            }
                        }
                    }

                    if (isProcessingOcr) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            LinearProgressIndicator(progress = { ocrProgress }, modifier = Modifier.fillMaxWidth())
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("در حال استخراج مشخصات دروس از تصویر...", fontSize = 11.sp, color = Slate500)
                        }
                    }
                } else {
                    // Bulk Text Mode
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "متن دروس را وارد یا پیست کنید (پشتیبانی از فرمت پایپ یا جملات فارسی):",
                            fontSize = 11.sp,
                            color = Slate500
                        )
                        OutlinedTextField(
                            value = bulkInputText,
                            onValueChange = { bulkInputText = it },
                            placeholder = {
                                Text(
                                    "نمونه ۱: ریاضی عمومی ۲ | ۳ واحد | شنبه ۱۰ تا ۱۲ | استاد احمدی | امتحان ۲۰ دی ساعت ۹\nنمونه ۲: شیمی فیزیک سه واحد یکشنبه هشت تا ده دکتر کاظمی",
                                    fontSize = 10.5.sp,
                                    lineHeight = 16.sp
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .testTag("bulk_text_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val parsed = RegistrationTextParser.parse(bulkInputText)
                                    extractedDrafts.clear()
                                    extractedDrafts.addAll(parsed)
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo600),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("parse_bulk_text_button")
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("پردازش و اعتبارسنجی متن")
                            }

                            OutlinedButton(
                                onClick = {
                                    bulkInputText = "ریاضی عمومی ۲ | ۳ واحد | شنبه ۱۰ تا ۱۲ | استاد احمدی | امتحان ۲۰ دی ساعت ۹\nفیزیک ۲ | ۳ واحد | یکشنبه ۸ تا ۱۰ | دکتر حسینی | امتحان ۲۵ دی ساعت ۱۰\nمعادلات دیفرانسیل | ۳ واحد | دوشنبه ۱۳:۳۰ تا ۱۵:۳۰ | دکتر صادقی"
                                },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("نمونه آماده")
                            }
                        }
                    }
                }

                // Extracted drafts preview list
                if (extractedDrafts.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "دروس شناسایی‌شده (${extractedDrafts.size} درس):",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .background(Emerald600.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "پیش‌نمایش قبل از ثبت در Room",
                                color = Emerald600,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .heightIn(max = 240.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(extractedDrafts) { draft ->
                            DraftCardItem(
                                draft = draft,
                                onRemove = { extractedDrafts.remove(draft) }
                            )
                        }
                    }

                    // Confirm and Save Button
                    Button(
                        onClick = {
                            onConfirmImport(extractedDrafts.toList())
                            onDismiss()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("confirm_bulk_import_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald600)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تأیید و ذخیره کلیه دروس در پایگاه‌داده", fontWeight = FontWeight.Bold)
                    }
                }
            }
    }
}

@Composable
private fun DraftCardItem(
    draft: ParsedCourseDraft,
    onRemove: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Slate200.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = draft.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(6.dp))
                    if (draft.validationState == DraftValidationState.INCOMPLETE) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Amber600, modifier = Modifier.size(14.dp))
                    }
                }
                Text(
                    text = "${draft.dayName} (${draft.startTime} تا ${draft.endTime}) | ${draft.instructor}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate500
                )
                if (draft.examDate.isNotBlank()) {
                    Text(
                        text = "امتحان: ${draft.examDate} ساعت ${draft.examTime}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = BrandIndigo600.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "${draft.units} واحد",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandIndigo600,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                IconButton(onClick = onRemove, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Rose600, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}
