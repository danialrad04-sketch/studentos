package com.example.data.backup

import android.content.Context
import com.example.data.local.dao.CurriculumDao
import com.example.data.local.dao.StudentDao
import com.example.data.local.entity.AttendanceEntity
import com.example.data.local.entity.CourseEntity
import com.example.data.local.entity.CurriculumCourseEntity
import com.example.data.local.entity.ExamEntity
import com.example.data.local.entity.GradeEntity
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.ProfessorEntity
import com.example.data.local.entity.SemesterEntity
import com.example.data.local.entity.StudentCourseAttemptEntity
import com.example.data.local.entity.StudentProfileEntity
import com.example.data.local.entity.TaskEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * High-performance, offline-independent Local Data Backup & Restore Manager.
 * Serializes and restores all 11 Room entity tables without loss of relational integrity.
 */
object LocalDataBackupManager {

    private const val BACKUP_VERSION = 1
    private const val SNAPSHOT_FILE_NAME = "student_os_latest_snapshot.json"

    suspend fun exportCompleteDatabaseJson(
        dao: StudentDao,
        curriculumDao: CurriculumDao? = null
    ): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("version", BACKUP_VERSION)
        root.put("exportedAt", System.currentTimeMillis())
        root.put("appName", "Student OS")

        // 1. Profile
        val profile = dao.getProfileSync()
        if (profile != null) {
            val profObj = JSONObject()
            profObj.put("id", profile.id)
            profObj.put("name", profile.name)
            profObj.put("studentId", profile.studentId)
            profObj.put("faculty", profile.faculty)
            profObj.put("term", profile.term)
            profObj.put("university", profile.university)
            profObj.put("major", profile.major)
            profObj.put("entryYear", profile.entryYear)
            profObj.put("currentSemester", profile.currentSemester)
            profObj.put("activeUnits", profile.activeUnits)
            profObj.put("passedUnits", profile.passedUnits)
            profObj.put("notes", profile.notes)
            profObj.put("isOnboardingCompleted", profile.isOnboardingCompleted)
            profile.universityId?.let { profObj.put("universityId", it) }
            profile.facultyId?.let { profObj.put("facultyId", it) }
            profile.majorId?.let { profObj.put("majorId", it) }
            profile.declaredPassedCredits?.let { profObj.put("declaredPassedCredits", it) }
            profile.declaredGpa?.let { profObj.put("declaredGpa", it) }
            root.put("profile", profObj)
        }

        // 2. Semesters
        val semesters = dao.getAllSemestersSync()
        val semArray = JSONArray()
        semesters.forEach { s ->
            val obj = JSONObject()
            obj.put("id", s.id)
            obj.put("title", s.title)
            obj.put("year", s.year)
            obj.put("academicYear", s.academicYear)
            obj.put("semesterNumber", s.semesterNumber)
            obj.put("termNumber", s.termNumber)
            obj.put("startDate", s.startDate)
            obj.put("endDate", s.endDate)
            obj.put("isCurrent", s.isCurrent)
            obj.put("isArchived", s.isArchived)
            obj.put("status", s.status)
            obj.put("totalUnits", s.totalUnits)
            s.gpa?.let { obj.put("gpa", it) }
            obj.put("createdAt", s.createdAt)
            obj.put("updatedAt", s.updatedAt)
            semArray.put(obj)
        }
        root.put("semesters", semArray)

        // 3. Courses
        val courses = dao.getAllCoursesIncludingArchivedSync()
        val courseArray = JSONArray()
        courses.forEach { c ->
            val obj = JSONObject()
            obj.put("id", c.id)
            obj.put("name", c.name)
            obj.put("day", c.day)
            obj.put("start", c.start)
            obj.put("end", c.end)
            obj.put("location", c.location)
            obj.put("colorHex", c.colorHex)
            obj.put("units", c.units)
            obj.put("semesterId", c.semesterId)
            obj.put("courseCode", c.courseCode)
            c.professorId?.let { obj.put("professorId", it) }
            obj.put("professor", c.professor)
            obj.put("examDate", c.examDate)
            obj.put("examTime", c.examTime)
            obj.put("examLocation", c.examLocation)
            obj.put("notes", c.notes)
            obj.put("isArchived", c.isArchived)
            courseArray.put(obj)
        }
        root.put("courses", courseArray)

        // 4. Attendance
        val attendanceList = dao.getAllAttendanceSync()
        val attArray = JSONArray()
        attendanceList.forEach { a ->
            val obj = JSONObject()
            obj.put("courseId", a.courseId)
            obj.put("courseName", a.courseName)
            obj.put("absentCount", a.absentCount)
            obj.put("maxAllowed", a.maxAllowed)
            attArray.put(obj)
        }
        root.put("attendance", attArray)

        // 5. Grades
        val grades = dao.getAllGradesSync()
        val gradeArray = JSONArray()
        grades.forEach { g ->
            val obj = JSONObject()
            obj.put("courseId", g.courseId)
            obj.put("courseName", g.courseName)
            obj.put("units", g.units)
            obj.put("midtermGrade", g.midtermGrade)
            obj.put("finalGrade", g.finalGrade)
            gradeArray.put(obj)
        }
        root.put("grades", gradeArray)

        // 6. Tasks
        val tasks = dao.getAllTasksSync()
        val taskArray = JSONArray()
        tasks.forEach { t ->
            val obj = JSONObject()
            obj.put("id", t.id)
            obj.put("title", t.title)
            obj.put("courseName", t.courseName)
            obj.put("dueDate", t.dueDate)
            obj.put("isCompleted", t.isCompleted)
            obj.put("courseId", t.courseId)
            t.semesterId?.let { obj.put("semesterId", it) }
            taskArray.put(obj)
        }
        root.put("tasks", taskArray)

        // 7. Professors
        val professors = dao.getAllProfessorsSync()
        val profArray = JSONArray()
        professors.forEach { p ->
            val obj = JSONObject()
            obj.put("id", p.id)
            obj.put("name", p.name)
            obj.put("email", p.email)
            obj.put("office", p.office)
            obj.put("department", p.department)
            obj.put("notes", p.notes)
            profArray.put(obj)
        }
        root.put("professors", profArray)

        // 8. Exams
        val exams = dao.getAllExamsSync()
        val examArray = JSONArray()
        exams.forEach { e ->
            val obj = JSONObject()
            obj.put("id", e.id)
            obj.put("courseId", e.courseId)
            obj.put("courseName", e.courseName)
            obj.put("date", e.date)
            obj.put("time", e.time)
            obj.put("location", e.location)
            obj.put("notes", e.notes)
            examArray.put(obj)
        }
        root.put("exams", examArray)

        // 9. Notes
        val notes = dao.getAllNotesSync()
        val noteArray = JSONArray()
        notes.forEach { n ->
            val obj = JSONObject()
            obj.put("id", n.id)
            n.courseId?.let { obj.put("courseId", it) }
            obj.put("title", n.title)
            obj.put("content", n.content)
            obj.put("updatedAt", n.updatedAt)
            noteArray.put(obj)
        }
        root.put("notes", noteArray)

        // 10. Student Attempts
        val attempts = dao.getStudentAttemptsSync(1)
        val attemptArray = JSONArray()
        attempts.forEach { att ->
            val obj = JSONObject()
            obj.put("id", att.id)
            obj.put("profileId", att.profileId)
            obj.put("courseId", att.courseId)
            obj.put("courseName", att.courseName)
            obj.put("units", att.units)
            obj.put("semesterIndex", att.semesterIndex)
            obj.put("attemptNumber", att.attemptNumber)
            obj.put("status", att.status)
            att.grade?.let { obj.put("grade", it) }
            obj.put("source", att.source)
            attemptArray.put(obj)
        }
        root.put("attempts", attemptArray)

        root.toString(2)
    }

    suspend fun restoreDatabaseFromJson(
        jsonString: String,
        dao: StudentDao,
        curriculumDao: CurriculumDao? = null
    ): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)

            // 1. Profile
            if (root.has("profile")) {
                val p = root.getJSONObject("profile")
                val profile = StudentProfileEntity(
                    id = p.optInt("id", 1),
                    name = p.optString("name", "دانشجو"),
                    studentId = p.optString("studentId", ""),
                    faculty = p.optString("faculty", ""),
                    term = p.optString("term", ""),
                    university = p.optString("university", "دانشگاه"),
                    major = p.optString("major", "مهندسی"),
                    entryYear = p.optInt("entryYear", 1403),
                    currentSemester = p.optInt("currentSemester", 1),
                    activeUnits = p.optInt("activeUnits", 0),
                    passedUnits = p.optInt("passedUnits", 0),
                    notes = p.optString("notes", ""),
                    isOnboardingCompleted = p.optBoolean("isOnboardingCompleted", true),
                    universityId = if (p.has("universityId")) p.getString("universityId") else null,
                    facultyId = if (p.has("facultyId")) p.getString("facultyId") else null,
                    majorId = if (p.has("majorId")) p.getString("majorId") else null,
                    declaredPassedCredits = if (p.has("declaredPassedCredits")) p.getInt("declaredPassedCredits") else null,
                    declaredGpa = if (p.has("declaredGpa")) p.getDouble("declaredGpa") else null
                )
                dao.insertProfile(profile)
            }

            // 2. Semesters
            if (root.has("semesters")) {
                val semArray = root.getJSONArray("semesters")
                val semesters = mutableListOf<SemesterEntity>()
                for (i in 0 until semArray.length()) {
                    val s = semArray.getJSONObject(i)
                    semesters.add(
                        SemesterEntity(
                            id = s.getString("id"),
                            title = s.optString("title", "ترم"),
                            year = s.optInt("year", 1403),
                            academicYear = s.optInt("academicYear", s.optInt("year", 1403)),
                            semesterNumber = s.optInt("semesterNumber", 1),
                            termNumber = s.optInt("termNumber", s.optInt("semesterNumber", 1)),
                            startDate = s.optString("startDate", ""),
                            endDate = s.optString("endDate", ""),
                            isCurrent = s.optBoolean("isCurrent", false),
                            isArchived = s.optBoolean("isArchived", false),
                            status = s.optString("status", "ACTIVE"),
                            totalUnits = s.optInt("totalUnits", 0),
                            gpa = if (s.has("gpa") && !s.isNull("gpa")) s.getDouble("gpa") else null,
                            createdAt = s.optLong("createdAt", System.currentTimeMillis()),
                            updatedAt = s.optLong("updatedAt", System.currentTimeMillis())
                        )
                    )
                }
                if (semesters.isNotEmpty()) {
                    dao.insertSemesters(semesters)
                }
            }

            // 3. Courses
            if (root.has("courses")) {
                val courseArray = root.getJSONArray("courses")
                val courses = mutableListOf<CourseEntity>()
                for (i in 0 until courseArray.length()) {
                    val c = courseArray.getJSONObject(i)
                    courses.add(
                        CourseEntity(
                            id = c.getString("id"),
                            name = c.optString("name", "درس"),
                            day = c.optInt("day", 0),
                            start = c.optString("start", "08:00"),
                            end = c.optString("end", "10:00"),
                            location = c.optString("location", ""),
                            colorHex = c.optString("colorHex", "#3B82F6"),
                            units = c.optInt("units", 3),
                            semesterId = c.optString("semesterId", "current"),
                            courseCode = c.optString("courseCode", ""),
                            professorId = if (c.has("professorId")) c.getString("professorId") else null,
                            professor = c.optString("professor", ""),
                            examDate = c.optString("examDate", ""),
                            examTime = c.optString("examTime", ""),
                            examLocation = c.optString("examLocation", ""),
                            notes = c.optString("notes", ""),
                            isArchived = c.optBoolean("isArchived", false)
                        )
                    )
                }
                if (courses.isNotEmpty()) {
                    dao.insertCourses(courses)
                }
            }

            // 4. Attendance
            if (root.has("attendance")) {
                val attArray = root.getJSONArray("attendance")
                for (i in 0 until attArray.length()) {
                    val a = attArray.getJSONObject(i)
                    dao.insertAttendance(
                        AttendanceEntity(
                            courseId = a.getString("courseId"),
                            courseName = a.optString("courseName", ""),
                            absentCount = a.optInt("absentCount", 0),
                            maxAllowed = a.optInt("maxAllowed", 3)
                        )
                    )
                }
            }

            // 5. Grades
            if (root.has("grades")) {
                val gradeArray = root.getJSONArray("grades")
                for (i in 0 until gradeArray.length()) {
                    val g = gradeArray.getJSONObject(i)
                    dao.insertGrade(
                        GradeEntity(
                            courseId = g.getString("courseId"),
                            courseName = g.optString("courseName", ""),
                            units = g.optInt("units", 3),
                            midtermGrade = g.optDouble("midtermGrade", 0.0),
                            finalGrade = g.optDouble("finalGrade", 0.0)
                        )
                    )
                }
            }

            // 6. Tasks
            if (root.has("tasks")) {
                val taskArray = root.getJSONArray("tasks")
                for (i in 0 until taskArray.length()) {
                    val t = taskArray.getJSONObject(i)
                    dao.insertTask(
                        TaskEntity(
                            id = t.optLong("id", 0L),
                            title = t.optString("title", ""),
                            courseName = t.optString("courseName", ""),
                            dueDate = t.optString("dueDate", ""),
                            isCompleted = t.optBoolean("isCompleted", false),
                            courseId = t.optString("courseId", ""),
                            semesterId = if (t.has("semesterId")) t.getString("semesterId") else null
                        )
                    )
                }
            }

            // 7. Professors
            if (root.has("professors")) {
                val profArray = root.getJSONArray("professors")
                for (i in 0 until profArray.length()) {
                    val p = profArray.getJSONObject(i)
                    dao.insertProfessor(
                        ProfessorEntity(
                            id = p.getString("id"),
                            name = p.optString("name", ""),
                            email = p.optString("email", ""),
                            office = p.optString("office", ""),
                            department = p.optString("department", ""),
                            notes = p.optString("notes", "")
                        )
                    )
                }
            }

            // 8. Exams
            if (root.has("exams")) {
                val examArray = root.getJSONArray("exams")
                for (i in 0 until examArray.length()) {
                    val e = examArray.getJSONObject(i)
                    dao.insertExam(
                        ExamEntity(
                            id = e.getString("id"),
                            courseId = e.getString("courseId"),
                            courseName = e.optString("courseName", ""),
                            date = e.optString("date", ""),
                            time = e.optString("time", ""),
                            location = e.optString("location", ""),
                            notes = e.optString("notes", "")
                        )
                    )
                }
            }

            // 9. Notes
            if (root.has("notes")) {
                val noteArray = root.getJSONArray("notes")
                for (i in 0 until noteArray.length()) {
                    val n = noteArray.getJSONObject(i)
                    dao.insertNote(
                        NoteEntity(
                            id = n.getString("id"),
                            courseId = if (n.has("courseId")) n.getString("courseId") else null,
                            title = n.optString("title", ""),
                            content = n.optString("content", ""),
                            updatedAt = n.optLong("updatedAt", System.currentTimeMillis())
                        )
                    )
                }
            }

            // 10. Attempts
            if (root.has("attempts")) {
                val attArray = root.getJSONArray("attempts")
                for (i in 0 until attArray.length()) {
                    val att = attArray.getJSONObject(i)
                    dao.insertStudentAttempt(
                        StudentCourseAttemptEntity(
                            id = att.getString("id"),
                            profileId = att.optInt("profileId", 1),
                            courseId = if (att.has("courseId") && !att.isNull("courseId")) att.getString("courseId") else null,
                            courseName = att.optString("courseName", ""),
                            units = att.optInt("units", 3),
                            attemptNumber = att.optInt("attemptNumber", 1),
                            semesterIndex = att.optInt("semesterIndex", 1),
                            status = att.optString("status", "PASSED"),
                            grade = if (att.has("grade") && !att.isNull("grade")) att.getDouble("grade") else null,
                            source = att.optString("source", "RESTORE")
                        )
                    )
                }
            }

            Result.success(1)
        } catch (e: Throwable) {
            e.printStackTrace()
            Result.failure(e)
        }
    }

    suspend fun saveLocalSnapshot(context: Context, json: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val file = File(context.filesDir, SNAPSHOT_FILE_NAME)
            file.writeText(json)
            true
        } catch (e: Throwable) {
            e.printStackTrace()
            false
        }
    }

    suspend fun loadLatestLocalSnapshot(context: Context): String? = withContext(Dispatchers.IO) {
        try {
            val file = File(context.filesDir, SNAPSHOT_FILE_NAME)
            if (file.exists() && file.length() > 10) {
                file.readText()
            } else null
        } catch (e: Throwable) {
            e.printStackTrace()
            null
        }
    }
}
