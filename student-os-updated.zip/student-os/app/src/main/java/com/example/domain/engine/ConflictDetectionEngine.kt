package com.example.domain.engine

import com.example.data.local.entity.CourseEntity
import com.example.data.local.util.DateTimeNormalizer
import com.example.data.parser.ParsedCourseDraft

enum class ConflictSeverity {
    ERROR,   // Critical: e.g. Exact time overlap or duplicate course
    WARNING, // Important: e.g. Back-to-back exams on same day or missing location
    INFO     // Notification: e.g. Unspecified exam time
}

enum class ConflictType {
    CLASS_CLASS_OVERLAP,
    EXAM_EXAM_OVERLAP,
    CLASS_EXAM_OVERLAP,
    DUPLICATE_COURSE_CODE,
    DUPLICATE_COURSE_NAME,
    INVALID_TIME_RANGE,
    INVALID_EXAM_DATE,
    INCOMPLETE_RECORD
}

data class CourseConflict(
    val type: ConflictType,
    val severity: ConflictSeverity,
    val course1Id: String,
    val course1Name: String,
    val course2Id: String? = null,
    val course2Name: String? = null,
    val description: String,
    val recommendation: String
)

/**
 * Pure Kotlin conflict detection engine for Student OS.
 * Detects Class/Class conflicts, Exam/Exam conflicts, duplicate courses, and invalid time ranges.
 */
object ConflictDetectionEngine {

    /**
     * Checks all conflicts across a list of courses.
     */
    fun checkAllConflicts(courses: List<CourseEntity>): List<CourseConflict> {
        val conflicts = mutableListOf<CourseConflict>()
        val activeCourses = courses.filter { !it.isArchived }

        // 1. Incomplete records & invalid time range check per course
        for (course in activeCourses) {
            conflicts.addAll(validateSingleCourse(course))
        }

        // 2. Pairwise checks for overlaps and duplicates
        for (i in activeCourses.indices) {
            for (j in i + 1 until activeCourses.size) {
                val c1 = activeCourses[i]
                val c2 = activeCourses[j]

                // Class vs Class overlap (same day, overlapping time)
                if (c1.day == c2.day && DateTimeNormalizer.hasTimeConflict(c1.day, c1.start, c1.end, c2.day, c2.start, c2.end)) {
                    conflicts.add(
                        CourseConflict(
                            type = ConflictType.CLASS_CLASS_OVERLAP,
                            severity = ConflictSeverity.ERROR,
                            course1Id = c1.id,
                            course1Name = c1.name,
                            course2Id = c2.id,
                            course2Name = c2.name,
                            description = "تداخل زمانی کلاس «${c1.name}» و «${c2.name}» (${c1.start} تا ${c1.end})",
                            recommendation = "ساعت برگزاری یا گروه درسی یکی از دروس را تغییر دهید."
                        )
                    )
                }

                // Exam vs Exam overlap (same exam date and time)
                if (c1.examDate.isNotBlank() && c2.examDate.isNotBlank() &&
                    c1.examDate.trim() == c2.examDate.trim()
                ) {
                    val timeOverlap = if (c1.examTime.isNotBlank() && c2.examTime.isNotBlank()) {
                        c1.examTime.trim() == c2.examTime.trim()
                    } else true

                    conflicts.add(
                        CourseConflict(
                            type = ConflictType.EXAM_EXAM_OVERLAP,
                            severity = if (timeOverlap) ConflictSeverity.ERROR else ConflictSeverity.WARNING,
                            course1Id = c1.id,
                            course1Name = c1.name,
                            course2Id = c2.id,
                            course2Name = c2.name,
                            description = "تداخل امتحان «${c1.name}» و «${c2.name}» در تاریخ ${c1.examDate}",
                            recommendation = "امکان برگزاری دو امتحان در یک روز یا همزمان وجود ندارد."
                        )
                    )
                }

                // Duplicate course code check
                if (c1.courseCode.isNotBlank() && c2.courseCode.isNotBlank() &&
                    c1.courseCode.trim().equals(c2.courseCode.trim(), ignoreCase = true)
                ) {
                    conflicts.add(
                        CourseConflict(
                            type = ConflictType.DUPLICATE_COURSE_CODE,
                            severity = ConflictSeverity.ERROR,
                            course1Id = c1.id,
                            course1Name = c1.name,
                            course2Id = c2.id,
                            course2Name = c2.name,
                            description = "کد درس تکراری: ${c1.courseCode} برای هر دو درس «${c1.name}» و «${c2.name}»",
                            recommendation = "کد درس را بررسی یا درس تکراری را حذف نمایید."
                        )
                    )
                }
            }
        }

        return conflicts
    }

    /**
     * Checks conflicts for a single incoming or edited course against existing courses.
     */
    fun checkCourseConflicts(targetCourse: CourseEntity, existingCourses: List<CourseEntity>): List<CourseConflict> {
        val conflicts = mutableListOf<CourseConflict>()
        conflicts.addAll(validateSingleCourse(targetCourse))

        val otherCourses = existingCourses.filter { it.id != targetCourse.id && !it.isArchived }
        for (c in otherCourses) {
            // Class vs Class overlap
            if (targetCourse.day == c.day &&
                DateTimeNormalizer.hasTimeConflict(targetCourse.day, targetCourse.start, targetCourse.end, c.day, c.start, c.end)
            ) {
                conflicts.add(
                    CourseConflict(
                        type = ConflictType.CLASS_CLASS_OVERLAP,
                        severity = ConflictSeverity.ERROR,
                        course1Id = targetCourse.id,
                        course1Name = targetCourse.name,
                        course2Id = c.id,
                        course2Name = c.name,
                        description = "تداخل زمانی با کلاس «${c.name}» (${c.start} تا ${c.end})",
                        recommendation = "ساعت برگزاری یکی از دو کلاس را تغییر دهید."
                    )
                )
            }

            // Exam overlap
            if (targetCourse.examDate.isNotBlank() && c.examDate.isNotBlank() &&
                targetCourse.examDate.trim() == c.examDate.trim()
            ) {
                val timeOverlap = if (targetCourse.examTime.isNotBlank() && c.examTime.isNotBlank()) {
                    targetCourse.examTime.trim() == c.examTime.trim()
                } else true

                conflicts.add(
                    CourseConflict(
                        type = ConflictType.EXAM_EXAM_OVERLAP,
                        severity = if (timeOverlap) ConflictSeverity.ERROR else ConflictSeverity.WARNING,
                        course1Id = targetCourse.id,
                        course1Name = targetCourse.name,
                        course2Id = c.id,
                        course2Name = c.name,
                        description = "تداخل تاریخ امتحان با «${c.name}» در ${c.examDate}",
                        recommendation = "برنامه‌ریزی امتحان‌ها را بازبینی کنید."
                    )
                )
            }

            // Duplicate code
            if (targetCourse.courseCode.isNotBlank() && c.courseCode.isNotBlank() &&
                targetCourse.courseCode.trim().equals(c.courseCode.trim(), ignoreCase = true)
            ) {
                conflicts.add(
                    CourseConflict(
                        type = ConflictType.DUPLICATE_COURSE_CODE,
                        severity = ConflictSeverity.ERROR,
                        course1Id = targetCourse.id,
                        course1Name = targetCourse.name,
                        course2Id = c.id,
                        course2Name = c.name,
                        description = "کد درس ${targetCourse.courseCode} قبلاً برای «${c.name}» ثبت شده است.",
                        recommendation = "از کد درس منحصر‌به‌فرد استفاده کنید."
                    )
                )
            }
        }

        return conflicts
    }

    /**
     * Validates a draft course from Bulk Import or AI parser against existing semester courses.
     */
    fun validateDraft(draft: ParsedCourseDraft, existingCourses: List<CourseEntity>): List<CourseConflict> {
        val course = CourseEntity(
            id = draft.tempId,
            name = draft.name,
            day = draft.dayOfWeek,
            start = draft.startTime,
            end = draft.endTime,
            location = draft.location,
            colorHex = "#3B82F6",
            units = draft.units,
            courseCode = draft.courseCode,
            examDate = draft.examDate,
            examTime = draft.examTime,
            examLocation = draft.examLocation
        )
        return checkCourseConflicts(course, existingCourses)
    }

    private fun validateSingleCourse(course: CourseEntity): List<CourseConflict> {
        val list = mutableListOf<CourseConflict>()

        // Check empty course name
        if (course.name.isBlank()) {
            list.add(
                CourseConflict(
                    type = ConflictType.INCOMPLETE_RECORD,
                    severity = ConflictSeverity.ERROR,
                    course1Id = course.id,
                    course1Name = "نامشخص",
                    description = "نام درس نمی‌تواند خالی باشد.",
                    recommendation = "نام کامل درس را وارد کنید."
                )
            )
        }

        // Check units
        if (course.units <= 0 || course.units > 8) {
            list.add(
                CourseConflict(
                    type = ConflictType.INCOMPLETE_RECORD,
                    severity = ConflictSeverity.WARNING,
                    course1Id = course.id,
                    course1Name = course.name,
                    description = "تعداد واحد نامتعارف (${course.units} واحد). واحدهای معتبر بین 1 تا 6 هستند.",
                    recommendation = "تعداد واحد معتبر برای این درس وارد کنید."
                )
            )
        }

        // Check time range validity
        val startMin = parseTimeToMinutes(course.start)
        val endMin = parseTimeToMinutes(course.end)
        if (startMin != null && endMin != null) {
            if (endMin <= startMin) {
                list.add(
                    CourseConflict(
                        type = ConflictType.INVALID_TIME_RANGE,
                        severity = ConflictSeverity.ERROR,
                        course1Id = course.id,
                        course1Name = course.name,
                        description = "ساعت پایان (${course.end}) باید پس از ساعت شروع (${course.start}) باشد.",
                        recommendation = "بازه زمانی کلاس را تصحیح نمایید."
                    )
                )
            } else if (endMin - startMin < 30) {
                list.add(
                    CourseConflict(
                        type = ConflictType.INVALID_TIME_RANGE,
                        severity = ConflictSeverity.WARNING,
                        course1Id = course.id,
                        course1Name = course.name,
                        description = "مدت کلاس کمتر از 30 دقیقه است.",
                        recommendation = "ساعت شروع و پایان را بررسی نمایید."
                    )
                )
            }
        }

        return list
    }

    private fun parseTimeToMinutes(timeStr: String): Int? {
        val parts = timeStr.trim().split(":")
        if (parts.size != 2) return null
        val h = parts[0].toIntOrNull() ?: return null
        val m = parts[1].toIntOrNull() ?: return null
        return h * 60 + m
    }
}
