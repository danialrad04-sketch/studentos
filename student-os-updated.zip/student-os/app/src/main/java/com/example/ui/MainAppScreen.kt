package com.example.ui

import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.entity.CourseEntity
import com.example.ui.components.AppDialogManager
import com.example.ui.components.DynamicIslandLiveActivity
import com.example.ui.components.FirstTimeAppTourDialog
import com.example.ui.components.FloatingIslandNavigationBar
import com.example.ui.components.HeaderSection
import com.example.ui.components.MainTabContent
import com.example.ui.components.OnboardingScreen
import com.example.ui.components.SubScreenHeaderSection
import com.example.ui.components.export.ExportSourcePayload
import com.example.ui.models.AppTab
import com.example.ui.models.ThemeMode
import com.example.ui.theme.BrandIndigo600
import com.example.ui.theme.MyApplicationTheme
import java.util.Locale

@Composable
fun MainAppScreen(
    studentViewModel: StudentViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current

    // Persistent Theme & System Theme detection
    val themeMode by studentViewModel.themeMode.collectAsStateWithLifecycle()
    val notificationsEnabled by studentViewModel.notificationsEnabled.collectAsStateWithLifecycle()
    val systemInDark = isSystemInDarkTheme()
    val isDarkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> systemInDark
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    // Dialog states
    var showProfileDialog by remember { mutableStateOf(false) }
    var showSettingsAndRoadmapDialog by remember { mutableStateOf(false) }
    var showNotifDialog by remember { mutableStateOf(false) }
    var showApkDialog by remember { mutableStateOf(false) }
    var showAddCourseDialog by remember { mutableStateOf(false) }
    var editingCourse by remember { mutableStateOf<CourseEntity?>(null) }
    var showAddTaskDialog by remember { mutableStateOf(false) }
    var showOnboardingWizard by remember { mutableStateOf(false) }
    var showCommandCenter by remember { mutableStateOf(false) }
    var showCopilotDialog by remember { mutableStateOf(false) }
    var showPastSemestersDialog by remember { mutableStateOf(false) }
    var showOcrImportDialog by remember { mutableStateOf(false) }
    var showAppTourGuide by remember { mutableStateOf(false) }
    var showAuthDialog by remember { mutableStateOf(false) }
    var showUpgradeDialog by remember { mutableStateOf(false) }
    var showBackupRestoreDialog by remember { mutableStateOf(false) }
    var selectedWorkspaceCourseId by remember { mutableStateOf<String?>(null) }
    var exportPayload by remember { mutableStateOf<ExportSourcePayload?>(null) }

    // Notification Permission Launcher (Android 13+ / Samsung One UI)
    val notifPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            studentViewModel.sendTestNotificationToDevice()
            Toast.makeText(context, "هشدار با موفقیت به نوار وضعیت گوشی ارسال شد 🔔", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "مجوز نمایش اعلان در دستگاه تأیید نشد", Toast.LENGTH_SHORT).show()
        }
    }

    val onSendDeviceTestNotif: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        } else {
            studentViewModel.sendTestNotificationToDevice()
            Toast.makeText(context, "هشدار به نوار وضعیت گوشی ارسال شد 🔔", Toast.LENGTH_SHORT).show()
        }
    }

    // Collect data
    val isOnboardingCompleted by studentViewModel.isOnboardingCompleted.collectAsStateWithLifecycle()
    val currentUser by studentViewModel.currentUser.collectAsStateWithLifecycle()
    val courses by studentViewModel.courses.collectAsStateWithLifecycle()
    val attendance by studentViewModel.attendance.collectAsStateWithLifecycle()
    val grades by studentViewModel.grades.collectAsStateWithLifecycle()
    val tasks by studentViewModel.tasks.collectAsStateWithLifecycle()
    val exams by studentViewModel.exams.collectAsStateWithLifecycle()
    val profile by studentViewModel.profile.collectAsStateWithLifecycle()
    val selectedTab by studentViewModel.selectedTab.collectAsStateWithLifecycle()
    val notifications by studentViewModel.notifications.collectAsStateWithLifecycle()
    val pomodoroSeconds by studentViewModel.pomodoroSeconds.collectAsStateWithLifecycle()
    val isPomodoroRunning by studentViewModel.isPomodoroRunning.collectAsStateWithLifecycle()
    val academicProgressState by studentViewModel.academicProgressUiState.collectAsStateWithLifecycle()
    val curriculumMatchState by studentViewModel.curriculumMatchUiState.collectAsStateWithLifecycle()
    val curriculumCourses by studentViewModel.curriculumCourses.collectAsStateWithLifecycle()
    val academicRisks by studentViewModel.academicRisks.collectAsStateWithLifecycle()
    val weeklyWorkload by studentViewModel.weeklyWorkload.collectAsStateWithLifecycle()
    val candidateSemesterPlans by studentViewModel.candidateSemesterPlans.collectAsStateWithLifecycle()
    val searchQuery by studentViewModel.searchQuery.collectAsStateWithLifecycle()
    val globalSearchResults by studentViewModel.globalSearchResults.collectAsStateWithLifecycle()
    val gamificationProfile by studentViewModel.gamificationProfile.collectAsStateWithLifecycle()

    // Dynamic weighted GPA: calculates from entered grades, or falls back to declared GPA from setup
    val totalUnits = grades.sumOf { it.units }
    val totalWeightedScore = grades.sumOf { (it.midtermGrade + it.finalGrade) * it.units }
    val calculatedGpa = if (totalUnits > 0) totalWeightedScore / totalUnits else 0.0
    val effectiveGpa = if (calculatedGpa > 0.0) {
        calculatedGpa
    } else if ((profile.declaredGpa ?: 0.0) > 0.0) {
        profile.declaredGpa ?: 0.0
    } else {
        0.0
    }
    val currentTermGpa = effectiveGpa
    val gpaFormatted = String.format(Locale.US, "%.2f", effectiveGpa)

    val anyModalOrDialogActive = exportPayload != null ||
            selectedWorkspaceCourseId != null ||
            showBackupRestoreDialog ||
            showUpgradeDialog ||
            showAuthDialog ||
            showAppTourGuide ||
            showOcrImportDialog ||
            showPastSemestersDialog ||
            showCopilotDialog ||
            showCommandCenter ||
            showAddTaskDialog ||
            editingCourse != null ||
            showAddCourseDialog ||
            showApkDialog ||
            showNotifDialog ||
            showSettingsAndRoadmapDialog ||
            showProfileDialog ||
            showOnboardingWizard

    BackHandler(enabled = anyModalOrDialogActive || selectedTab != AppTab.DASHBOARD) {
        when {
            exportPayload != null -> exportPayload = null
            selectedWorkspaceCourseId != null -> selectedWorkspaceCourseId = null
            showBackupRestoreDialog -> showBackupRestoreDialog = false
            showUpgradeDialog -> showUpgradeDialog = false
            showAuthDialog -> showAuthDialog = false
            showAppTourGuide -> showAppTourGuide = false
            showOcrImportDialog -> showOcrImportDialog = false
            showPastSemestersDialog -> showPastSemestersDialog = false
            showCopilotDialog -> showCopilotDialog = false
            showCommandCenter -> showCommandCenter = false
            showAddTaskDialog -> showAddTaskDialog = false
            editingCourse != null -> editingCourse = null
            showAddCourseDialog -> showAddCourseDialog = false
            showApkDialog -> showApkDialog = false
            showNotifDialog -> showNotifDialog = false
            showSettingsAndRoadmapDialog -> showSettingsAndRoadmapDialog = false
            showProfileDialog -> showProfileDialog = false
            showOnboardingWizard -> showOnboardingWizard = false
            selectedTab != AppTab.DASHBOARD -> studentViewModel.selectTab(AppTab.DASHBOARD)
        }
    }

    MyApplicationTheme(darkTheme = isDarkTheme) {
        // Enforce Persian RTL
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            val shouldShowOnboarding = (!isOnboardingCompleted && !profile.isOnboardingCompleted) || showOnboardingWizard
            if (shouldShowOnboarding) {
                val storedName = studentViewModel.preferencesRepository.getStoredStudentName()
                val effectiveInitialName = if (storedName.isNotBlank()) storedName else if (profile.name != "دانشجو") profile.name else ""
                val storedUni = studentViewModel.preferencesRepository.getStoredUniversity()
                val effectiveInitialUni = if (storedUni.isNotBlank()) storedUni else if (profile.university != "دانشگاه") profile.university else ""
                val storedMaj = studentViewModel.preferencesRepository.getStoredMajor()
                val effectiveInitialMaj = if (storedMaj.isNotBlank()) storedMaj else if (profile.major != "مهندسی") profile.major else ""

                OnboardingScreen(
                    initialName = effectiveInitialName,
                    initialStudentId = profile.studentId.ifBlank { studentViewModel.preferencesRepository.getStoredStudentId() },
                    initialUniversity = effectiveInitialUni,
                    initialMajor = effectiveInitialMaj,
                    initialEntryYear = if (profile.entryYear > 0) profile.entryYear else studentViewModel.preferencesRepository.getStoredEntryYear(),
                    initialSemester = if (profile.currentSemester > 0) profile.currentSemester else studentViewModel.preferencesRepository.getStoredCurrentSemester(),
                    onCompleteQuickSetup = { name, stdId, uni, maj, yr, sem, passed, gpa, selCourses ->
                        studentViewModel.completeQuickAcademicSetup(name, stdId, uni, maj, yr, sem, passed, gpa, selCourses)
                        showOnboardingWizard = false
                        showAppTourGuide = true
                        Toast.makeText(context, "سیستم‌عامل تحصیلی با موفقیت راه‌اندازی شد 🚀", Toast.LENGTH_LONG).show()
                    },
                    onCompleteTextImport = { drafts, name, stdId, uni, maj, yr, sem ->
                        studentViewModel.importParsedCourses(
                            drafts = drafts,
                            clearExisting = true,
                            studentName = name,
                            studentId = stdId,
                            university = uni,
                            major = maj,
                            entryYear = yr,
                            currentSemester = sem
                        )
                        showOnboardingWizard = false
                        showAppTourGuide = true
                        Toast.makeText(context, "${drafts.size} درس از برگه انتخاب واحد ثبت شد 📋", Toast.LENGTH_LONG).show()
                    },
                    onSkip = { name, stdId, uni, maj, yr, sem ->
                        studentViewModel.setOnboardingCompleted(
                            completed = true,
                            name = name,
                            studentId = stdId,
                            university = uni,
                            major = maj,
                            entryYear = yr,
                            currentSemester = sem,
                            passedCredits = profile.passedUnits,
                            declaredGpa = profile.declaredGpa ?: 0.0
                        )
                        showOnboardingWizard = false
                    }
                )
            } else {
                Scaffold(
                    modifier = modifier.fillMaxSize(),
                    containerColor = MaterialTheme.colorScheme.background,
                    bottomBar = {
                        FloatingIslandNavigationBar(
                            selectedTab = selectedTab,
                            onTabSelected = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                studentViewModel.selectTab(it)
                            }
                        )
                    }
                ) { innerPadding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background)
                            .padding(innerPadding)
                            .statusBarsPadding()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        val totalCurriculumUnits = when (val state = academicProgressState) {
                            is com.example.ui.models.AcademicProgressUiState.Ready -> state.progress.totalRequiredCredits
                            is com.example.ui.models.AcademicProgressUiState.Partial -> state.progress.totalRequiredCredits
                            else -> 140
                        }

                        // Show Header and Live Activity ONLY on Dashboard for a clean, focused view on other tabs
                        if (selectedTab == AppTab.DASHBOARD) {
                            // Apple Dynamic Island / Live Activity Top Capsule
                            DynamicIslandLiveActivity(
                                courses = courses,
                                pomodoroSeconds = pomodoroSeconds,
                                isPomodoroRunning = isPomodoroRunning,
                                onNavigateTab = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    studentViewModel.selectTab(it)
                                }
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            HeaderSection(
                                profile = profile,
                                courseCount = courses.map { it.name }.distinct().size,
                                gpa = gpaFormatted,
                                passedUnits = profile.passedUnits,
                                totalRequiredCredits = totalCurriculumUnits,
                                notifCount = notifications.size,
                                isDarkTheme = isDarkTheme,
                                themeMode = themeMode,
                                onToggleTheme = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    studentViewModel.toggleThemeQuickly()
                                },
                                onOpenProfile = { showProfileDialog = true },
                                onOpenNotifications = { showNotifDialog = true },
                                onOpenAndroidInfo = { showApkDialog = true },
                                onResetDefaults = {
                                    studentViewModel.resetToDefaults()
                                    Toast.makeText(context, "اطلاعات به حالت اولیه ریست شد", Toast.LENGTH_SHORT).show()
                                },
                                onOpenCommandCenter = { showCommandCenter = true },
                                onOpenCopilot = { showCopilotDialog = true },
                                onOpenOcrImport = { showOcrImportDialog = true },
                                onOpenSettingsAndRoadmap = { showSettingsAndRoadmapDialog = true },
                                onLoadDemoData = {
                                    studentViewModel.loadDemoData()
                                    Toast.makeText(context, "حالت دمو با داده‌های نمونه فعال شد 🎓", Toast.LENGTH_LONG).show()
                                },
                                onClearToFreshSlate = {
                                    studentViewModel.clearToFreshSlate()
                                    Toast.makeText(context, "سیستم‌عامل پاکسازی شد و آماده ورود اطلاعات شماست ✨", Toast.LENGTH_LONG).show()
                                }
                            )

                            Spacer(modifier = Modifier.height(10.dp))
                        } else {
                            SubScreenHeaderSection(
                                currentTab = selectedTab,
                                onBackToDashboard = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    studentViewModel.selectTab(AppTab.DASHBOARD)
                                },
                                onOpenSearch = { showCommandCenter = true },
                                onOpenNotifications = { showNotifDialog = true },
                                onOpenSettings = { showSettingsAndRoadmapDialog = true },
                                notifCount = notifications.size,
                                isDarkTheme = isDarkTheme,
                                themeMode = themeMode,
                                onToggleTheme = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    studentViewModel.toggleThemeQuickly()
                                }
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                        }

                        // Horizontal Navigation Chips (All 10 Tabs with Rich Emojis)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            AppTab.values().forEach { tab ->
                                val isSelected = selectedTab == tab
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        studentViewModel.selectTab(tab)
                                    },
                                    label = {
                                        Text(
                                            text = "${tab.iconEmoji} ${tab.title}",
                                            fontSize = 11.5.sp,
                                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium
                                        )
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = BrandIndigo600,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Tab Content decomposed into MainTabContent
                        MainTabContent(
                            selectedTab = selectedTab,
                            courses = courses,
                            attendance = attendance,
                            tasks = tasks,
                            grades = grades,
                            exams = exams,
                            profile = profile,
                            gpaFormatted = gpaFormatted,
                            currentTermGpa = currentTermGpa,
                            totalUnits = totalUnits,
                            totalCurriculumUnits = totalCurriculumUnits,
                            academicProgressState = academicProgressState,
                            curriculumMatchState = curriculumMatchState,
                            academicRisks = academicRisks,
                            weeklyWorkload = weeklyWorkload,
                            candidateSemesterPlans = candidateSemesterPlans,
                            pomodoroSeconds = pomodoroSeconds,
                            isPomodoroRunning = isPomodoroRunning,
                            gamificationProfile = gamificationProfile,
                            studentViewModel = studentViewModel,
                            context = context,
                            haptic = haptic,
                            onOpenCourseWorkspace = { course ->
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                selectedWorkspaceCourseId = course.id
                            },
                            onOpenCommandCenter = { showCommandCenter = true },
                            onOpenAddTask = { showAddTaskDialog = true },
                            onOpenAddCourse = { showAddCourseDialog = true },
                            onEditCourse = { editingCourse = it },
                            onOpenOcrImport = { showOcrImportDialog = true },
                            onOpenZeroSetup = { showOnboardingWizard = true },
                            onOpenPastSemestersDialog = { showPastSemestersDialog = true },
                            onExportPayload = { exportPayload = it },
                            onOpenAppTour = { showAppTourGuide = true }
                        )

                        // Generous bottom clearance padding to guarantee zero tile-overlap with floating dock
                        Spacer(modifier = Modifier.height(84.dp))
                    }
                }
            }

            // Interactive First-Time & On-Demand App Tour Guide
            if (showAppTourGuide) {
                FirstTimeAppTourDialog(
                    currentProfile = profile,
                    onSaveProfileEssentials = { name, studentId, targetGpa, notes ->
                        studentViewModel.updateProfile(
                            profile.copy(
                                name = name,
                                studentId = studentId,
                                declaredGpa = targetGpa,
                                notes = notes
                            )
                        )
                        Toast.makeText(context, "اطلاعات ضروری دانشجو ثبت و ذخیره شد ✅", Toast.LENGTH_SHORT).show()
                    },
                    onDismiss = { showAppTourGuide = false }
                )
            }

            // Dialogs managed by AppDialogManager
            AppDialogManager(
                context = context,
                studentViewModel = studentViewModel,
                profile = profile,
                userAccount = currentUser,
                themeMode = themeMode,
                notificationsEnabled = notificationsEnabled,
                notifications = notifications,
                courses = courses,
                attendance = attendance,
                grades = grades,
                tasks = tasks,
                exams = exams,
                curriculumCourses = curriculumCourses,
                globalSearchResults = globalSearchResults,
                searchQuery = searchQuery,
                showSettingsAndRoadmapDialog = showSettingsAndRoadmapDialog,
                onDismissSettingsDialog = { showSettingsAndRoadmapDialog = false },
                showProfileDialog = showProfileDialog,
                onDismissProfileDialog = { showProfileDialog = false },
                showPastSemestersDialog = showPastSemestersDialog,
                onDismissPastSemestersDialog = { showPastSemestersDialog = false },
                showNotifDialog = showNotifDialog,
                onDismissNotifDialog = { showNotifDialog = false },
                showApkDialog = showApkDialog,
                onDismissApkDialog = { showApkDialog = false },
                showAddCourseDialog = showAddCourseDialog,
                onDismissAddCourseDialog = { showAddCourseDialog = false },
                editingCourse = editingCourse,
                onDismissEditingCourse = { editingCourse = null },
                showAddTaskDialog = showAddTaskDialog,
                onDismissAddTaskDialog = { showAddTaskDialog = false },
                showCommandCenter = showCommandCenter,
                onDismissCommandCenter = { showCommandCenter = false },
                showCopilotDialog = showCopilotDialog,
                onDismissCopilotDialog = { showCopilotDialog = false },
                showOcrImportDialog = showOcrImportDialog,
                onDismissOcrImportDialog = { showOcrImportDialog = false },
                showAuthDialog = showAuthDialog,
                onDismissAuthDialog = { showAuthDialog = false },
                showUpgradeDialog = showUpgradeDialog,
                onDismissUpgradeDialog = { showUpgradeDialog = false },
                showBackupRestoreDialog = showBackupRestoreDialog,
                onDismissBackupRestoreDialog = { showBackupRestoreDialog = false },
                selectedWorkspaceCourseId = selectedWorkspaceCourseId,
                onDismissWorkspaceCourse = { selectedWorkspaceCourseId = null },
                exportPayload = exportPayload,
                onDismissExportPayload = { exportPayload = null },
                onOpenProfileDialog = { showProfileDialog = true },
                onOpenPastSemestersDialog = { showPastSemestersDialog = true },
                onOpenApkDialog = { showApkDialog = true },
                onOpenOnboardingWizard = { showOnboardingWizard = true },
                onOpenAuthDialog = { showAuthDialog = true },
                onOpenUpgradeDialog = { showUpgradeDialog = true },
                onOpenBackupRestoreDialog = { showBackupRestoreDialog = true },
                onSendDeviceTestNotif = onSendDeviceTestNotif,
                onSelectWorkspaceCourseId = { selectedWorkspaceCourseId = it }
            )
        }
    }
}
